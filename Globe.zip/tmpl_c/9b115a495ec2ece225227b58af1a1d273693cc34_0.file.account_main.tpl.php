<?php /* Smarty version 3.1.27, created on 2022-11-24 06:06:39
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/account_main.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1165465222637efbdfb6ed79_56468932%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b115a495ec2ece225227b58af1a1d273693cc34' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/account_main.tpl',
      1 => 1668116553,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1165465222637efbdfb6ed79_56468932',
  'variables' => 
  array (
    'ab_formated' => 0,
    'settings' => 0,
    'userinfo' => 0,
    'last_deposit' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637efbdfd88935_91680289',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637efbdfd88935_91680289')) {
function content_637efbdfd88935_91680289 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1165465222637efbdfb6ed79_56468932';
echo $_smarty_tpl->getSubTemplate ("mlogo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<div class="cabContent">
    
    
<span class="cabHeading">My Account</span>
<div class="contentItem account">
<div class="wrap">
<div class="accInfo">
<span class="backTitle">account</span>
<div class="accInfoItem affProg">
<div class="in">
<div class="img"><span class="icon-person"></span></div>
<div class="data">
<span class="title">Total Balance:</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['total']);?>
<sup>$</sup></span>
</div>
</div>
</div>
<div class="accInfoItem affLink">
<div class="in">
<div class="img"><span class="icon-link"></span></div>
<div class="data">
<span class="title">Your affilate link:</span>
<a class="copyLink">https://<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
 <span class="link-style"></span></a>


</div>
</div>
</div>
<div class="accInfoItem upline">
<div class="in">
<div class="img"><span class="icon-user3"></span></div>
<div class="data">
<span class="title">Last Withdraw:</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdrawal']);?>
<sup>$</sup></span>
</div>
</div>
</div>
</div>



<div class="accStat">
<div class="back" style="background-image: url(img/cab_chart.png)"></div>
<span class="backTitle">statistics</span>
<div class="wrap">
<div class="accStatItem">
<div class="iconLeft">
<span class="icon-up"></span>
<div class="data">
<span class="title">Active deposits</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['active_deposit']);?>
<sup>$</sup></span>
</div>
</div>
</div>
<div class="accStatItem">
<div class="iconLeft">
<span class="icon-up"></span>
<div class="data">
<span class="title">Earned toral</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['earning']);?>
<sup>$</sup></span>
</div>
</div>
</div>
<div class="accStatItem">
<div class="iconLeft">
<span class="icon-up"></span>
<div class="data">
<span class="title">total deposited</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['deposit']);?>
<sup>$</sup></span>
</div>
</div>
</div>

 

<div class="accStatItem">
<div class="iconLeft">
<span class="icon-down"></span>
<div class="data">
<span class="title">Pending withdrawals</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdraw_pending']);?>
<sup>$</sup></span>
</div>
</div>
</div>
<div class="accStatItem">
<div class="iconLeft">
<span class="icon-down"></span>
<div class="data">
<span class="title">total withdraws</span>
<span class="num"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdrawal']);?>
<sup>$</sup></span>
</div>
</div>
</div>
<div class="accStatItem">
<div class="iconLeft">
<span class="icon-down"></span>
<div class="data">
<span class="title">Last deposit </span>
<span class="num"><?php echo smarty_modifier_myescape((($tmp = @$_smarty_tpl->tpl_vars['last_deposit']->value)===null||$tmp==='' ? "n/a" : $tmp));?>
</b> &nbsp;<sup>$</sup></span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php echo '<script'; ?>
 data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"><?php echo '</script'; ?>
><?php echo '<script'; ?>
> 
    $.ajax({
    url: "?a=referals",
    context: document.body
})
    .done(function (data) {
    $('#upline').html($(data).find('#upline').html());
}); 
<?php echo '</script'; ?>
>
</div>
</div>
</div>


</div>
</div>
</div>
</div>
</div>


<?php echo '<script'; ?>
>

    $.ajax

({

        url: "?a=referals",

        context: document.body

    }

)

.done

    (

        function (
            data
        ) {
            $
                ('#upline').html

            ($(data).

                find('#upline').html

                ());

        });

<?php echo '</script'; ?>
>
    
    </div>
</div>
</div>
</div>
</div>

<button class="scroll-top tran3s">
				<i class="fa fa-angle-up" aria-hidden="true"></i>
			</button>
	<?php echo $_smarty_tpl->getSubTemplate ("mfoot.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>