<?php /* Smarty version 2.6.2, created on 2022-11-09 19:33:46
         compiled from footer_install.tpl */ ?>

              </td>
              </tr>
            </table>
            <!-- Main: END -->

              </td>
             </tr>
           </table>
		  </td>
		 </tr>
	   </table>
	 </td>
  </tr>



  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">All Rights Reserved. <a href='http://www.goldcoders.com' class="forCopyright">HYIP Manager</a></div></td>
  </tr>
</table>
</center></body>
</html>