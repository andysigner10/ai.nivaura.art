<?php /* Smarty version 3.1.27, created on 2022-11-24 06:06:39
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/mlogo.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:542340818637efbdfdc1986_71424769%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '45bc11e3214d94f3940bf6fc12e2b5af4c1cad57' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/mlogo.tpl',
      1 => 1668153102,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '542340818637efbdfdc1986_71424769',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
    'last_access' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637efbdfe542b5_89285635',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637efbdfe542b5_89285635')) {
function content_637efbdfe542b5_89285635 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '542340818637efbdfdc1986_71424769';
?>
<div style="position: fixed; bottom: 1px;  z-index:50000;margin-left:5%" align="center"><!--- margin-left:50% -->
        <a href="https://t.me/globecurrency">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Telegram_2019_Logo.svg/1200px-Telegram_2019_Logo.svg.png" style="width:50px; height:50px;border:none; border-radius:50%; z-index:70000"></a>
    </div>

<!--Start of Tawk.to Script-->
<?php echo '<script'; ?>
 type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/636df892daff0e1306d6dcbb/1ghip61ek';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
<?php echo '</script'; ?>
>
<!--End of Tawk.to Script-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
<title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>
<meta name="viewport" content="width=1200">
<meta name="format-detection" content="telephone=no">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<style> 
@font-face {
    font-family: 'icomoon';
    src: url(fonts/icomoon/fonts/icomoon.eot?rjkpmv);
    src: url(fonts/icomoon/fonts/icomoon.eot?rjkpmv#iefix) format('embedded-opentype'), url(fonts/icomoon/fonts/icomoon.ttf?rjkpmv) format('truetype'), url(fonts/icomoon/fonts/icomoon.woff?rjkpmv) format('woff'), url(fonts/icomoon/fonts/icomoon.svg?rjkpmv#icomoon) format('svg');
    font-weight: normal;
    font-style: normal;
    font-display: block
}

[class^="icon-"],
[class*=" icon-"] {
    font-family: 'icomoon' !important;
    speak: none;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale
}

.icon-up:before {
    content: "\e91f"
}

.icon-down:before {
    content: "\e920"
}

.icon-user1:before {
    content: "\e901"
}

.icon-calendar:before {
    content: "\e903"
}

.icon-clock:before {
    content: "\e906"
}

.icon-headphone:before {
    content: "\e90a"
}

.icon-person:before {
    content: "\e90b"
}

.icon-invest:before {
    content: "\e90c"
}

.icon-link:before {
    content: "\e90d"
}

.icon-logout:before {
    content: "\e910"
}

.icon-safebox:before {
    content: "\e912"
}

.icon-server:before {
    content: "\e913"
}

.icon-settings:before {
    content: "\e914"
}

.icon-shield:before {
    content: "\e915"
}

.icon-user3:before {
    content: "\e918"
}

.icon-user2:before {
    content: "\e919"
}

.icon-wallet:before {
    content: "\e91a"
}

.icon-team:before {
    content: "\e91b"
}

</style >

<link rel="stylesheet" href="css/account.css">
<link rel="stylesheet" href="css/deposit.css">
<link rel="stylesheet" href="css/settings.css">
<link rel="stylesheet" href="css/withdraw.css">
<link rel="stylesheet" href="css/referals.css">
<link rel="stylesheet" href="css/earning.css">





<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery-3.3.1.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript"> 
    $(document).ready(function () {
    var ua = detect.parse(navigator.userAgent);
    $("html").addClass(ua.device.type + " " + ua.device.family + " " + ua.os.family + " " + ua.browser.family);
    if ($(".modalsScroll").length > 0) {
        openMod();
    }
    if ($(".clock").length > 0) {
        function clockLK() {
            var date = new Date(),
                day = date.getDate(),
                month = date.getMonth(),
                monthArr = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                year = date.getFullYear(),
                hour = date.getHours(),
                min = date.getMinutes(),
                sec = date.getSeconds();
            if (day < 10) day = '0' + day;
            if (hour < 10) hour = '0' + hour;
            if (min < 10) min = '0' + min;
            if (sec < 10) sec = '0' + sec;
            document.getElementById("hours").innerHTML = hour;
            document.getElementById("minutes").innerHTML = min;
            document.getElementById("seconds").innerHTML = sec;
            document.getElementById("day").innerHTML = day + ' ' + monthArr[month];
            document.getElementById("year").innerHTML = year;
        }
        var timer;

        function clockLKStart() {
            timer = setInterval(clockLK, 1000);
            clockLK();
        }
        clockLKStart();
    }
    if ($(".langBlock").length > 0) {
        $(".langBlock").find(".head").on("click", function () {
            $(this).siblings(".list").stop().slideToggle(500)
            if ($(this).hasClass("active")) {
                $(this).removeClass("active")
            } else {
                $(this).addClass("active")
            }
        })
        $(document).mouseup(function (e) {
            if ($(".langBlock .head").hasClass("active")) {
                var langHead = $(".langBlock .head");
                if (!langHead.is(e.target) && langHead.has(e.target).length === 0) {
                    langHead.removeClass('active');
                    langHead.siblings('.list').slideUp(500)
                }
            }
        });
    }
    if ($(".copyLink").length > 0) {
        new ClipboardJS(".copyLink");
    }
    if ($('.enterNum').length > 0) {
        $('.enterNum').bind("change keyup input click", function () {
            if (this.value.match(/[^0-9]/g)) {
                this.value = this.value.replace(/[^0-9]/g, '');
            }
        });
    }
    if ($('select').length > 0) {
        $('select').map(function () {
            $(this).selectric()
        })
    }
    if ($(".setDate").length > 0) {
        $(".setDate").datepicker({
            dateFormat: "MM-dd-yy",
            monthNames: ["Jan", "Feb", "Mar", "Ap", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        })
    }
    if ($(".progressKnob input").length > 0) {
        $(".progressKnob input").map(function () {
            $(this).knob({
                bgColor: "#002219",
                fgColor: "#a2ea07",
                thickness: 0.2,
                readOnly: true,
                height: 82,
                width: 82,
                format: function (v) {
                    return 100 - v
                }
            })
        })
    }
    var dropHead = $('.dropItem > .head'),
        dropContent = $('.dropItem > .content');
    if ($('.dropItem').length > 0) {
        $('.dropItem').map(function () {
            var el = $(this)
            if (el.find(dropHead).length > 0 && el.find(dropContent).length > 0) {
                el.find(dropHead).on('click', function () {
                    var el = $(this),
                        cont = el.siblings(dropContent);
                    if (el.hasClass('active')) {
                        cont.stop().slideUp(500, function () {
                            el.removeClass('active');
                            el.parent().removeClass('active');
                        });
                    } else {
                        cont.stop().slideDown(500, function () {
                            el.addClass('active');
                            el.parent().addClass('active');
                        });
                    }
                })
            }
        })
    }
    if ($(".openMenu").length > 0) {
        $(".openMenu").on("click", function () {
            $(this).parents().siblings(".cabNav").stop().slideToggle(500)
            if ($(this).hasClass("active")) {
                $(this).removeClass("active")
            } else {
                $(this).addClass("active")
            }
        })
    }
    var ua = detect.parse(navigator.userAgent);
    $("html").addClass(ua.device.type + " " + ua.device.family + " " + ua.os.family + " " + ua.browser.family)
    if ($(".clockBl").length > 0) {
        clock()
    }
    if ($(".selectricBl").length > 0) {
        $(".selectricBl").map(function () {
            $(this).selectric()
        })
    }
    if ($(".tabs").length > 0) {
        $(".tabs").map(function () {
            $(this).tabs()
        })
    }
    if ($(".faqList").length > 0) {
        var timeOut = false;
        $(".lineQuest .quest").click(function () {
            if (timeOut) return false;
            $(this).toggleClass("open").parents('.lineQuest').toggleClass("open").find(".answer").slideToggle();
            timeOut = true;
            setTimeout(function () {
                timeOut = false;
            }, 500);
        })
    }
    if ($("header").length > 0) {
        var timeOut = false;
        $("header .menuBtn").click(function () {
            if (timeOut) return false;
            $("header .menuBtn").toggleClass("selected")
            $("body").toggleClass("hidden")
            $(".menu").slideToggle(500);
            timeOut = true;
            setTimeout(function () {
                timeOut = false;
            }, 500);
        })
    }
    if ($(".wow").length > 0) {
        new WOW().init();
    }
}) 
<?php echo '</script'; ?>
>

</head>



<body class="lk">
<div class="bodyWrap">
<div class="cabWrapper" style="background-image: url(img/cab_back.jpg)">
<div class="left">
<div class="cabLogo">
<div class="logo">
<img src="img/logo.png" alt="logo">
<a href="?a=home">main</a>
</div>
<div class="openMenu">
<span></span>
<span></span>
<span></span>
</div>
</div>
<ul class="cabNav">
<li class="active">
<div class="iconLeft">
<span class="icon-user2"></span>
<span class="data">My account</span>
</div>
<a href="?a=account">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-invest"></span>
<span class="data"><B style='font-size:17px;color:#c0ff00;'>Make Deposit</B></span>
</div>
<a href="?a=deposit">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-wallet"></span>
<span class="data"><B style='font-size:17px;color:#c0ff00;'>Withdraw</B></span>
</div>
<a href="?a=withdraw">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-safebox"></span>
<span class="data">Deposit List</span>
</div>
<a href="?a=deposit_list">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-settings"></span>
<span class="data">Settings</span>
</div>
<a href="?a=edit_account">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-calendar"></span>
<span class="data">History</span>
</div>
<a href="?a=earnings">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-team"></span>
<span class="data">Referrals</span>
</div>
<a href="?a=referals">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-team"></span>
<span class="data">Banners</span>
</div>
<a href="?a=referallinks">link</a>
</li>
<li>
<div class="iconLeft">
<span class="icon-logout"></span>
<span class="data">Logout</span>
</div>
<a href="?a=logout">link</a>
</li>
</ul>
<div class="copyright">
<p>Copyright © 2022 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
.<br> All Rights Reserved.</p>
</div>
</div>

<div class="right">
<div class="inner">
<div class="cabHead">
<div class="infoWrap">
<div class="wrap">
<ul class="userInfo">
<li>
<div class="iconLeft">
<span class="icon-user2"></span>
<div class="data">
<span>Username:</span>
<span class="name"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
</span>
</div>
</div>
</li>
<li>
<div class="iconLeft">
<span class="icon-calendar"></span>
<div class="data">
<span>Last seen:</span>
<span><?php echo smarty_modifier_myescape((($tmp = @$_smarty_tpl->tpl_vars['last_access']->value)===null||$tmp==='' ? "n/a" : $tmp));?>
&nbsp;</span>
</div>
</div>
</li>
<li>
<div class="iconLeft">
<span class="icon-server"></span>
<div class="data">
<span>Registration Date:</span>
<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['create_account_date']);?>
</span>
</div>
</div>
</li>
</ul>
<div class="cabInfo">
<div class="cabContacts">
<span>Email address:</span>
<a href="mailto:<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['userinfo']->value['email']));?>
"><span class="__cf_email__" ><?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['userinfo']->value['email']));?>
</span></a>
</div>
<div class="langBlock">
<div class="head">
<span class="icon" style="background-image: url(img/gb.png)"></span>
<span class="lang">Eng</span>
<span class="arr"></span>
</div>
<div class="list">
<div class="item">
<span class="icon" style="background-image: url(img/gb.png)"></span>
<span class="lang">Eng</span>
<a href="?a=account&language=en">lang</a>
</div>
</div>
</div>
</div>
</div>
</div>

<style>
    .textinfo
    {
    display:inline-block;
    
    background:#439a25;
    
    background:#b800d9;
    
    background:#6dd214;
    
    font-size:20px;
    
    font-weight:bold;
    
    position:relative;
    
    border-radius:2px;
    
    width:100%;
    
    padding:5px 8px;
    
    text-align:
    
    center;
    
    margin-top:10px;
    
    margin-bottom:10px
    
}
</style>

<br>



<div class="cabBalance">
<div class="wrap" id="infodata">
    
    
    
    <!---
        chart -->

</div>
</div>
</div>

<style>
.chart_box

{
    width:100%;
    
    overflow:hidden;
    
    text-align:center
}   
    .chart_box ul
{

    display:inline-block; 
    
    font-size:0;
    
    vertical-align:middle;
    
    height:40px
}   

    .chart_box ul li
    
    {   
    
    display:inline-block    
    
    }   
    
    .accbotton a i
    
    {
    
    font-family:"Inter";
    
    font-style:normal
    
    }
    
    .accbotton a
    
    {
    
    display:inline-block;
    
    font-size:16px;
    
    font-weight:bold;
    
    padding:25px;
    
    color:#fff;
    
    background:rgba(0,0,0,.1);
    
    border-radius:2px;
    
    transition:.4s ease;
    
    background:#6dd214;
    
    padding:10px 20px;
    
    box-shadow:0 2px 0 0 #013220 ,
    
    inset 0 0 2px rgba
    
    (255,255,255,.6);
    
    position:relative;
    
    z-index:2;
    
    margin-left:10px
    
    }
    
    .accbotton a:hover
    
    {
    
    display:inline-block;
    
    font-size:16px;
    
    font-weight:bold;
    
    padding:25px;
    
    color:#fff;
    
    background:rgba(0,0,0,.1);
    
    border-radius:2px;
    
    transition:.4s ease;
    
    background:#6dd214;
    
    padding:10px 20px;
    
    box-shadow:0 2px 0 0 #fff ,
    
    inset 0 0 5px rgba(255,255,255,.6);
    
    position:relative;
    
    z-index:2;
    
    margin-left:10px
    
    }
    
    </style>
</br>

<div class='chart_box'>
<ul>
<img style="padding-bottom:10px;" src="./img/btc2.png">
<li class="accbotton"><span></span><a href="?a=deposit"><i class="fa fa-money-bill">Make Deposit</i></a></li>
<li class="accbotton"><span></span><a href="?a=withdraw"><i class="fa fa-share">Withdraw</i></a></li>
<img style="margin-left:10px;padding-bottom:10px;" src="./img/btc2.png">
</ul>
</div><?php }
}
?>