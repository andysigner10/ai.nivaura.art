<?php /* Smarty version 3.1.27, created on 2022-11-21 04:24:12
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/forgot_password.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1113946840637aef5c3f27c9_63363715%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1e7647d485b269e783f2b6ccce6bdf246e36b80' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/forgot_password.tpl',
      1 => 1668056933,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1113946840637aef5c3f27c9_63363715',
  'variables' => 
  array (
    'errors' => 0,
    'found_records' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637aef5c9bb953_67846628',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637aef5c9bb953_67846628')) {
function content_637aef5c9bb953_67846628 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1113946840637aef5c3f27c9_63363715';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>




<h2 class="cap">Forgot password ?</h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bglogin.jpg)"></div>
</header>
<div class="content">


<?php echo '<script'; ?>
 language=javascript>
function checkform() {
  if (document.forgotform.email.value == '') {
    alert("Please type your username or email!");
    document.forgotform.email.focus();
    return false;
  }
  return true;
}
<?php echo '</script'; ?>
>

<div class="loginPage">
<div class="container">
<div class="wrapIn">
<div class="left">
<div class="nameLog">
<span class="iconBl icon-user1"></span>
<span class="desr">Forgot</span>
<h2 class="cap colorMobieWhite">Password</h2>
<span class="capVisible">Password</span>
</div>







<?php echo '<script'; ?>
 language=javascript>
function checkform() {
  if (document.forgotform.email.value == '') {
    alert("Please type your username or email!");
    document.forgotform.email.focus();
    return false;
  }
  return true;
}
<?php echo '</script'; ?>
>

<h3>Forgot your password:</h3><br>

<?php if ($_smarty_tpl->tpl_vars['errors']->value['turing_image']) {?>
Invalid turing image<br><br>
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['found_records']->value == 2) {?>
Your accound was found. Please check your e-mail address and follow confirm URL to reset your password.
<br><br>
<?php } else { ?>

<?php if ($_smarty_tpl->tpl_vars['found_records']->value == 0) {?>
No accounts found for provided info.
<br><br>
<?php } elseif ($_smarty_tpl->tpl_vars['found_records']->value == 1) {?>
Request was confirmed. Login and password was sent to your email address.
<br><br>
<?php }?>

<form method=post name=forgotform onsubmit="return checkform();">
<input type=hidden name=a value="forgot_password">
<input type=hidden name=action value="forgot_password">

<div class="forma">
<div class="inputLine">
<label for="">Enter Your Username or E-Mail<span class="imp">*</span>:</label>
<input type=text name='email' value="">
</div>
</div>


</tr>

<button type="submit" class="btn btnGrDark">Reset</button>
</form>

</div>
</div>
</div>
</div>


<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>
<?php }?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>