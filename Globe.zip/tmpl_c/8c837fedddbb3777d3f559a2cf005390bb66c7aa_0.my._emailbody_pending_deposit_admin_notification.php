<?php /* Smarty version 3.1.27, created on 2022-11-14 16:12:17
         compiled from "my:_emailbody_pending_deposit_admin_notification" */ ?>
<?php
/*%%SmartyHeaderCode:137679466463725ad17ae7e4_74895725%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c837fedddbb3777d3f559a2cf005390bb66c7aa' => 
    array (
      0 => 'my:_emailbody_pending_deposit_admin_notification',
      1 => 1668438737,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '137679466463725ad17ae7e4_74895725',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_63725ad17dc194_62860283',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_63725ad17dc194_62860283')) {
function content_63725ad17dc194_62860283 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '137679466463725ad17ae7e4_74895725';
?>
User #username# save deposit $#amount# of #currency# to #plan#.

#fields#<?php }
}
?>