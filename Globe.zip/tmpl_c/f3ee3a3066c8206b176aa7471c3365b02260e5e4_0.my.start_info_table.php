<?php /* Smarty version 3.1.27, created on 2022-11-27 05:51:02
         compiled from "my:start_info_table" */ ?>
<?php
/*%%SmartyHeaderCode:19481043226382ecb6e67a18_67043404%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f3ee3a3066c8206b176aa7471c3365b02260e5e4' => 
    array (
      0 => 'my:start_info_table',
      1 => 1669524662,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '19481043226382ecb6e67a18_67043404',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_6382ecb6e68d51_10366994',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_6382ecb6e68d51_10366994')) {
function content_6382ecb6e68d51_10366994 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '19481043226382ecb6e67a18_67043404';
?>
<div class="alert alert-warning"><?php }
}
?>