<?php /* Smarty version 3.1.27, created on 2022-11-24 20:46:32
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/custom/howitworks.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1295636381637fca18979436_84655260%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa5323bc017f7a5794ba1717d3ea54b91e697b6a' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/custom/howitworks.tpl',
      1 => 1668023898,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1295636381637fca18979436_84655260',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637fca189cce85_02879203',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637fca189cce85_02879203')) {
function content_637fca189cce85_02879203 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1295636381637fca18979436_84655260';
?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h2 class="cap">How it works?</h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bgwork.jpg)"></div>
</header>
<div class="content">
<div class="workPage">
<div class="container">
<div class="wrapIn">
<div class="txtLeftBlock">
<span class="capVisible">investment</span>
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap colorMobieWhite">How it works?</h2>
<b>Our mission is to make profitable investment in a promising and fast-growing cryptocurrency market understandable and accessible to a wide audience.</b>
<p>Using a unique investment strategy with the hourly reporting period, we are able to pay our investors high returns, regardless of the situation on the cryptocurrency market.</p>
<p>Below you can find our three balanced tariff plans, which imply an hourly accrual of profit up to 17% per hour!</p>
</div>
<BR>
<P style="font-size:30px;font-weight:bold;color:#4ec52a;">How to deposit or withdraw?</P>
<P style="font-size:20px;font-weight:bold;">1.Click Make Deposit</P>
<img src="img/11.jpg" alt="" style="max-width:800px;vertical-align: top;"> <br/><br/>
<P style="font-size:20px;font-weight:bold;">2.Choose Plan To Make Investment.</P>
<img src="img/2.jpg" alt="" style="max-width:800px;vertical-align: top;"><br/><br/>
<P style="font-size:20px;font-weight:bold;">3.if you deposit from cryptocurrency so just scan QR code To Pay</P>
<img src="img/3.jpg" alt="" style="max-width:800px;vertical-align: top;"><br/><br/>
<P style="font-size:20px;font-weight:bold;">4.How to make withdraw?click cashout to choose payment method and fill amount to request</P>
<img src="img/4.jpg" alt="" style="max-width:800px;vertical-align: top;"><br/><br/>
<br/><br/><br/><br/>
</div>
</div>
</div>
<div class="affilateWork">
<div class="affiliateBl">
<div class="container">
<div class="wrapIn">
<div class="txtLeftBlock">
<span class="desr">Affiliate</span>
<h2 class="cap">program</h2>
<p>For all our active Investors and not only, we have developed an excellent 3 different referral program. This bonus program is aimed at attracting an additional loyal audience for the development of our joint business.</p>
<p>Thanks to the program, the Company saves money on online advertising, and investors receive bonus rewards from each deposit of a new member invited by them.</p>
<p>By participating in our affiliate program, you can expect to make a profit of 3% of the deposit amount of your 1st plan referrals, 5% of the deposit amount of 2nd plan referrals and 10% of the deposit amount of 3rd plan referrals.</p>
</div>
<style>
    body.site .affilateWork .listLevelBl
{
    right:13px;
    bottom:90px
}
</style>
<div class="listLevelBl">
<div class="item">
<span class="pr">3%</span>
<span class="desr">for 1 Plan</span>
<div class="circle">
<span class="prCirc">3<sub>%</sub></span>
</div>
</div>
<div class="item">
<span class="pr">5%</span>
<span class="desr">for 2 Plan</span>
<div class="circle">
<span class="prCirc">5<sub>%</sub></span>
</div>
</div>
<div class="item">
<span class="pr">10%</span>
<span class="desr">for 3 Plan</span>
<div class="circle">
<span class="prCirc">10<sub>%</sub></span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="workProcess">
<div class="container">
<div class="wrapIn">
<div class="capBlock">
<span class="capVisible">process</span>
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap">How is the work process of our company?</h2>
</div>
<div class="list">
<div class="item">
<span class="iconBl icon-monitor"></span>
<span class="num">01</span>
<span class="tit">Market analysis</span>
<span class="txt">At the beginning of each hour, our team of analysts carefully analyzes the current market situation</span>
</div>
<div class="item">
<span class="iconBl icon-safebox"></span>
<span class="num">02</span>
<span class="tit">The choice of investment decisions</span>
<span class="txt">After analyzing the market, our specialists select the most profitable asset that will bring the greatest profit in the next hour.</span>
</div>
<div class="item">
<span class="iconBl icon-user1"></span>
<span class="num">03</span>
<span class="tit">Investment process</span>
<span class="txt">Over the next hour, our analysts in real time monitor all fluctuations in the cryptocurrency market</span>
</div>
<div class="item">
<span class="iconBl icon-wallet"></span>
<span class="num">04</span>
<span class="tit">Receiving a profit</span>
<span class="txt">At the end of the hour, the specialists of our company record the profit received, which is sent to payments to our investors.</span>
</div>
</div>
</div>
</div>
</div>
<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>


<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>