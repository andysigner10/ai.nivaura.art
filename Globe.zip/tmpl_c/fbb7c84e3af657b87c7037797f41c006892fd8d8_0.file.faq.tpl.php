<?php /* Smarty version 3.1.27, created on 2022-11-24 20:46:28
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/faq.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:389024510637fca144c2858_80121918%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fbb7c84e3af657b87c7037797f41c006892fd8d8' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/faq.tpl',
      1 => 1668025313,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '389024510637fca144c2858_80121918',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637fca14542625_50316640',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637fca14542625_50316640')) {
function content_637fca14542625_50316640 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '389024510637fca144c2858_80121918';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h2 class="cap">FAQ</h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bgfaq.jpg)"></div>
</header>
<div class="content">
<div class="faqPage">
<div class="container">
<div class="wrapIn">
<div class="capBlock">
<span class="capVisible">questions</span>
<span class="desr">FAQ</span>
<h2 class="cap colorMobieWhite">Frequently Asked Questions</h2>
</div>
<div class="faqList">
<div class="faqBlock">
<div class="title">
<span class="num">01</span>
<span class="tit">About the Project</span>
</div>
<div class="lineQuest "> <span class="quest "><span class="iconBl icon-faq"></span>What is <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
?</span>
<p class="answer" style="display: block;" style="display: block;"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is a team of professional analysts and players in the cryptocurrency market, which has hundreds of instruments in its assets for profit in the financial markets, including cryptocurrency. The main distinguishing feature of our company from competitors is the presence of its own unique trading strategies on cryptocurrency exchanges such as BitFinex, Poloniex, Binance, BitMex and others. Our analysts in real time analyze more than the initial 200 parameters to make a decision on the purchase or sale of a financial asset for maximum profit.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>How to make deposit and start to earn?</span>
<p class="answer" style="display: block;">Its very easy just login your account and click make deposit also choose a desire plan than choose payment processor to pay,you will able to earn hourly profit after you make deposit .</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>What payment systems cooperate with the company?</span>
<p class="answer" style="display: block;">We accept Bitcoin, Litcoin,Ethereum,Perfect Money,Dogecoin, Payeer, currently.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Is there any risk for me to participate in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
's investment plan?</span>
<p class="answer" style="display: block;">Investors do not have any risk, we have 5 years experience in the investment of experts have a sound strategy earning plan, you only need to invest and regularly take your profits.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Can I have multiple accounts?</span>
<p class="answer" style="display: block;"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 only accepts one account, multiple accounts is not allowed,it will be blocked by the system.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>How long will it take me to make a profit?</span>
<p class="answer" style="display: block;"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is an 12 hours plan, the system will generate profits after you make an investment, For example, if you invest at 1:00 am you will receive your profit at 1:00 pm only in plan 1 others plans are 24 hours</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>How long will it take to withdraw money?</span>
<p class="answer" style="display: block;">All the payments are paid Instantly,if we meet pending, Our maintainers will check and deal with your payments, you do not need to worry about it.</p>
</div>
<div class="lineQuest open"> <span class="quest open open"><span class="iconBl icon-faq"></span>What if I forget the password?</span>
<p class="answer" style="display: block;">Just click forget password on the login page and you can reset a new password.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>What are the minimum investments and minimum withdrawals?</span>
<p class="answer" style="display: block;">The minimum investment is $50, the minimum withdrawal is $ 60, the maximum withdrawal is $500,000, you can withdraw money unlimited times in a day.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Can i invest from one payment system and withdraw from another?</span>
<p class="answer" style="display: block;">No.You can only withdraw from payment system that you was make deposit.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Do you charge fee when make withdraw?</span>
<p class="answer" style="display: block;">No we dont charge any fee,fee will charge by payment system.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Do you have an affiliate program?</span>
<p class="answer" style="display: block;">Yes we have one level affiliate program,you will able to get 3%~5%~10% for different 3 plan.you can find your link on referral page.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Can i Earn from affiliate program without make any investment</span>
<p class="answer" style="display: block;">Yes,you can post your Referral Link to facebook,twitter,vk,telegram,instagram or any social media to gain your referral commission.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Can i make multi deposit?</span>
<p class="answer" style="display: block;">Yes you can deposit at any plan but you can invest different plan when first plan finished otherwise it may cause some problems.</p>
</div>
<div class="lineQuest open"> <span class="quest open"><span class="iconBl icon-faq"></span>Where can i buy bitcoin,litecoin or Ethereum?</span>
<p class="answer" style="display: block;">You will able to find on Coinbase.com, Binance.com,okex.com,www.bitfinex.com etc</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>