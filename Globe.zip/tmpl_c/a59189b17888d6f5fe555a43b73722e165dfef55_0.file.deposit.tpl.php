<?php /* Smarty version 3.1.27, created on 2022-11-22 03:10:17
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/deposit.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1554433637c2f8995ea62_35736575%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a59189b17888d6f5fe555a43b73722e165dfef55' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/deposit.tpl',
      1 => 1668500708,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1554433637c2f8995ea62_35736575',
  'variables' => 
  array (
    'fatal' => 0,
    'qplans' => 0,
    'frm' => 0,
    'errors' => 0,
    'currency_sign' => 0,
    'ps' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637c2f89cb8ef3_18798143',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637c2f89cb8ef3_18798143')) {
function content_637c2f89cb8ef3_18798143 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1554433637c2f8995ea62_35736575';
echo $_smarty_tpl->getSubTemplate ("mlogo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php echo '<script'; ?>
 data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"><?php echo '</script'; ?>
><?php echo '<script'; ?>
 language="javascript"><!--
function openCalculator(id)
{

  w = 225; h = 400;
  t = (screen.height-h-30)/2;
  l = (screen.width-w-30)/2;
  window.open('?a=calendar&type=' + id, 'calculator' + id, "top="+t+",left="+l+",width="+w+",height="+h+",resizable=1,scrollbars=0");


  
  for (i = 0; i < document.spendform.h_id.length; i++)
  {
    if (document.spendform.h_id[i].value == id)
    {
      document.spendform.h_id[i].checked = true;
    }
  }

  

}

function updateCompound() {
  var id = 0;
  var tt = document.spendform.h_id.type;
  if (tt && tt.toLowerCase() == 'hidden') {
    id = document.spendform.h_id.value;
  } else {
    for (i = 0; i < document.spendform.h_id.length; i++) {
      if (document.spendform.h_id[i].checked) {
        id = document.spendform.h_id[i].value;
      }
    }
  }

  var cpObj = document.getElementById('compound_percents');
  if (cpObj) {
    while (cpObj.options.length != 0) {
      cpObj.options[0] = null;
    }
  }

  if (cps[id] && cps[id].length > 0) {
    document.getElementById('coumpond_block').style.display = '';

    for (i in cps[id]) {
      cpObj.options[cpObj.options.length] = new Option(cps[id][i]);
    }
  } else {
    document.getElementById('coumpond_block').style.display = 'none';
  }
}
var cps = {};
--><?php echo '</script'; ?>
>






<span class="cabHeading">Make a deposit</span>
<div class="contentItem makeDeposit">
<span class="backTitle">make a deposit</span>
<div class="wrap">
   
<?php if ($_smarty_tpl->tpl_vars['fatal']->value) {?>

<?php if ($_smarty_tpl->tpl_vars['fatal']->value == 'one_per_month') {?>
You can deposit once a month only.
<?php }?>

<?php } else { ?>


<?php echo '<script'; ?>
 language="javascript"><!--
function openCalculator(id)
{

  w = 225; h = 400;
  t = (screen.height-h-30)/2;
  l = (screen.width-w-30)/2;
  window.open('?a=calendar&type=' + id, 'calculator' + id, "top="+t+",left="+l+",width="+w+",height="+h+",resizable=1,scrollbars=0");


  <?php if ($_smarty_tpl->tpl_vars['qplans']->value > 1) {?>

  for (i = 0; i < document.spendform.h_id.length; i++)
  {
    if (document.spendform.h_id[i].value == id)
    {
      document.spendform.h_id[i].checked = true;
    }
  }

  <?php }?>


}

function updateCompound() {
  var id = 0;
  var tt = document.spendform.h_id.type;
  if (tt && tt.toLowerCase() == 'hidden') {
    id = document.spendform.h_id.value;
  } else {
    for (i = 0; i < document.spendform.h_id.length; i++) {
      if (document.spendform.h_id[i].checked) {
        id = document.spendform.h_id[i].value;
      }
    }
  }

  var cpObj = document.getElementById('compound_percents');
  if (cpObj) {
    while (cpObj.options.length != 0) {
      cpObj.options[0] = null;
    }
  }

  if (cps[id] && cps[id].length > 0) {
    document.getElementById('coumpond_block').style.display = '';

    for (i in cps[id]) {
      cpObj.options[cpObj.options.length] = new Option(cps[id][i]);
    }
  } else {
    document.getElementById('coumpond_block').style.display = 'none';
  }
}
var cps = {};
--><?php echo '</script'; ?>
>


<?php if ($_smarty_tpl->tpl_vars['frm']->value['say'] == 'deposit_success') {?>
<h3 style = "color:white">The deposit has been successfully saved.</h3>
<br><br>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['frm']->value['say'] == 'deposit_saved') {?>
<h3 style = "color:white">The deposit has been saved. It will become active when the administrator checks statistics.</h3><br><br>
<?php }?>

<h3>Make a Deposit:</h3>
<br>
<?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['less_min']) {?>
Sorry, you can deposit not less than <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['errors']->value['less_min']);?>
 with selected processing<br><br>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['greater_max']) {?>
Sorry, you can deposit not greater than <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['errors']->value['greater_max']);?>
 with selected processing<br><br>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['ec_forbidden']) {?>
Sorry, deposit with selected processing is temproary forbidden.<br><br>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['errors']->value['cannot_invest_this_plan_anymore']) {?>
Sorry, you cannot invest this plan anymore<br><br>
<?php }?>
<?php }?>
<?php }?>
<form method=post name="spendform">
<input type=hidden name=a value=deposit>










<div class="row">
<div class="item">
<div class="planItem">
<input type="radio" name="h_id" id="plan1" value="1" data-days="1" data-perc="120" data-min="20" data-max="199" data-period="daily" data-name="" checked>
<label for="plan1"></label>
<div class="in">
<div class="tCell">
<div class="planPct">
<div class="pct">
    <br><br>
<span class="num">30%</span>
</div>
<span class="term">AFTER 12 HOURS</span>
</div>
</div>
<div class="tCell">
<div class="info">
<ul>
<li>STANDARD PLAN<span></span></li>
<li><span>Min: $100<br>Max: $999</span></li>
</ul>
</div>
</div>
</div>
</div>
<br>
<label class="radio" for="r1" style="text-align:center;"><img src="./img/btc.png">&nbsp;<a style="color: #c0ff00;font-weight:bold;text-align:center;" href="javascript:openCalculator('1')">Profit Calculator</a></label>

</div>

<div class="item">
<div class="planItem">
<input type="radio" name="h_id" id="plan2" value="2" data-days="2" data-perc="150" data-min="200" data-max="999" data-period="daily" data-name="">
<label for="plan2"></label>
<div class="in">
<div class="tCell">
<div class="planPct">
<div class="pct">
    <br><br>
<span class="num">50%</span>
</div>
<span class="term">AFTER 24 HOURS</span>
</div>
</div>
<div class="tCell">
<div class="info">
<ul>
<li>SILVER PLAN<span></span></li>
<li><span>Min: $1000<br> Max: $4999</span></li>
</ul>
</div>

</div>
</div>
</div>
<br>
<label class="radio" for="r1" style="text-align:center;"><img src="./img/btc.png">&nbsp;<a style="color: #c0ff00;font-weight:bold;text-align:center;" href="javascript:openCalculator('2')">Profit Calculator</a></label>
</div>
<div class="item">
<div class="planItem">
<input type="radio" name="h_id" id="plan3" value="3" data-days="2" data-perc="300" data-min="500" data-max="990000" data-period="daily" data-name="">
<label for="plan3"></label>
<div class="in">
<div class="tCell">
<div class="planPct">
<div class="pct">
    <br><br>
<span class="num">70%</span>
</div>
<span class="term">AFTER 2 DAYS</span>
</div>
</div>
<div class="tCell">
<div class="info">
<ul>
<li>DIAMOND PLAN<span></span></li>
<li><span>Min: $5000<br> Max: $9999</span></li>
</ul>
</div>
</div>

</div>
</div>
<br>
<label class="radio" for="r1" style="text-align:center;"><img src="./img/btc.png">&nbsp;<a style="color: #c0ff00;font-weight:bold;text-align:center;" href="javascript:openCalculator('3')">Profit Calculator</a></label>
</div>





<div class="item">
<div class="planItem">
<input type="radio" name="h_id" id="plan4" value="4" data-days="2" data-perc="300" data-min="500" data-max="990000" data-period="daily" data-name="">
<label for="plan4"></label>
<div class="in">
<div class="tCell">
<div class="planPct">
<div class="pct">
    <br><br>
<span class="num">85%</span>
</div>
<span class="term">AFTER 2 DAYS</span>
</div>
</div>
<div class="tCell">
<div class="info">
<ul>
<li>GOLD PLAN<span></span></li>
<li><span>Min: $10000<br> Max: $20000</span></li>
</ul>
</div>
</div>

</div>
</div>
<br>
<label class="radio" for="r1" style="text-align:center;"><img src="./img/btc.png">&nbsp;<a style="color: #c0ff00;font-weight:bold;text-align:center;" href="javascript:openCalculator('4')">Profit Calculator</a></label>
</div>
<div class="item">
<div class="planItem">
<input type="radio" name="h_id" id="plan5" value="5" data-days="2" data-perc="300" data-min="500" data-max="990000" data-period="daily" data-name="">
<label for="plan5"></label>
<div class="in">
<div class="tCell">
<div class="planPct">
<div class="pct">
    <br><br>
<span class="num">100%</span>
</div>
<span class="term">AFTER 3 DAYS</span>
</div>
</div>
<div class="tCell">
<div class="info">
<ul>

<li>PROFICIENT PLAN<span></span></li>
<li><span>Min: $20000<br> Max: UNLIMITED</span></li>
</ul>
</div>
</div>

</div>
</div>
<br>
<label class="radio" for="r1" style="text-align:center;"><img src="./img/btc.png">&nbsp;<a style="color: #c0ff00;font-weight:bold;text-align:center;" href="javascript:openCalculator('5')">Profit Calculator</a></label>
</div>
<!-- <div class="item">
<div class="planItem">
<input type="radio" name="h_id" id="plan6" value="6" data-days="2" data-perc="300" data-min="500" data-max="990000" data-period="daily" data-name="">
<label for="plan6"></label>
<div class="in">
<div class="tCell">
<div class="planPct">
<div class="pct">
    <br><br>
<span class="num">80%</span>
</div>
<span class="term">AFTER 15 DAYS</span>
</div>
</div>
<div class="tCell">
<div class="info">
<ul>
<li>EXPERT PLAN<span></span></li>
<li><span>Min: $20000<br> Max: $UNLIMITED</span></li>
</ul>
</div>
</div>
</div>
</div>
<br>
<label class="radio" for="r1" style="text-align:center;"><img src="./img/btc.png">&nbsp;<a style="color: #c0ff00;font-weight:bold;text-align:center;" href="javascript:openCalculator('6')">Profit Calculator</a></label>
</div> -->
















</div>


<div class="row">
<div class="item">
<div class="depAmount formBl">
<span class="cabTitle">Enter amount:</span>
<div class="inBlockType1">
<div class="inWrap">
<input type=text name=amount style="width: 100%;">
</div>
</div>
</div>
</div>

<!--
<tr id="coumpond_block" style="display:none">
 <td>Compounding(%):</td>
 <td align=right>
  <select name="compound" class=inpts id="compound_percents"></select>
 </td>
</tr> -->

   <div class="item">
        <div class="depPayment formBl">
            <span class="cabTitle">Payment method:</span>
            <div class="paymentSys">
                <div class="inBlockType1">
                    <div class="inWrap">
                        
<select class="selectricBl payMet1" name="type">
                        <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['p'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['p']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['name'] = 'p';
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['ps']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total']);
?>
   <?php if ($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['balance'] > 0 && $_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['status'] == 1) {?>
         <option value="account_<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['id']);?>
" >Spend funds from the Account Balance <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['name']);?>
</option>
     
   <?php }?>
<?php endfor; endif; ?>
<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['p'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['p']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['name'] = 'p';
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['ps']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total']);
?>
   <?php if ($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['status']) {?>
         <option value="process_<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['id']);?>
" <?php if ($_smarty_tpl->getVariable('smarty')->value['section']['p']['index'] == 0) {?>checked<?php }?>>Spend funds from <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['name']);?>
</option>
 
   <?php }?>
<?php endfor; endif; ?>
             </select>          

</div>
                </div>

</div>
        </div>
    </div>
</div>
<button class="btnFillType1Lg center" type="submit">Make a deposit</button>

</form>
</div>
</div>

<?php echo '<script'; ?>
 type="text/javascript"> var plans=new Array;
plans[1]=new Array;
plans[1][0]=new Array(5.0000000000, 469.0000000000, 1.73, 60);
plans[1][1]=new Array(470.0000000000, 4700.0000000000, 2.50, 60);
plans[2]=new Array;
plans[2][0]=new Array(300.0000000000, 4699.0000000000, 6.00, 40);
plans[2][1]=new Array(3000.0000000000, 47000.0000000000, 9.00, 40);
plans[3]=new Array;
plans[3][0]=new Array(3000.0000000000, 5999.0000000000, 14.00, 20);
plans[3][1]=new Array(6000.0000000000, 470000.0000000000, 17.00, 20);
function calc() {
    amount=jQuery('#calc_amount').val();
    plan=plans[$('input[name=h_id]:checked').val()];
    for(var i=0; i<plan.length; i++) {
        if((amount>=plan[i][0])&&((amount<=plan[i][1])||(plan[i][1]==0))) {
            percent=plan[i][2];
            period=plan[i][3];
        }
    }
    jQuery('#percent_total').html(percent*period);
    jQuery('#profit_total').html((parseFloat(amount*percent/100*period)).toFixed(2));
}
jQuery(document).ready(function() {
        calc(); jQuery('#calc_amount').on('change keyup', function() {
                calc();
            }
        ); jQuery('input[name=h_id]').on('change', function() {
                jQuery('#calc_amount').val(jQuery('input[name=h_id]:checked').data('min')); calc();
            }
        ); jQuery('input[name=payMet]').on('change', function() {
                jQuery('.selectric-selectricBl').hide(0); jQuery('select[name=type]').attr('name', ''); jQuery('select[data-id='+jQuery(this).attr('id')+']').attr('name', 'type'); jQuery('.selectric-'+jQuery(this).attr('id')).show(0);
            }
        ) jQuery('.selectric-payMet2').hide(0);
    }
);
<?php echo '</script'; ?>
 >



<?php echo '<script'; ?>
 language=javascript>
for (i = 0; i<document.spendform.type.length; i++) {
  if ((document.spendform.type[i].value.match(/^process_/))) {
    document.spendform.type[i].checked = true;
    break;
  }
}
updateCompound();
<?php echo '</script'; ?>
>



                   </div>
                </div>
            </div>
        </div>
    </div>





<!-- footer start-->
    <?php echo '<script'; ?>
>
        $.ajax({
            url: "?a=account",
            context: document.body
        }).done(function(data) {
            $('#infodata').html($(data).find('#infodata').html());
        });

    <?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="js/clipboard.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.selectric.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="js/detect.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="js/jquery-ui.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 type="text/javascript" src="//js.users.51.la/20647777.js"><?php echo '</script'; ?>
>
</body>

</html>
<?php echo '<script'; ?>
 data-pagespeed-no-defer>
    (function() {
        function f(b) {
            var a = window;
            if (a.addEventListener) a.addEventListener("load", b, !1);
            else if (a.attachEvent) a.attachEvent("onload", b);
            else {
                var c = a.onload;
                a.onload = function() {
                    b.call(this);
                    c && c.call(this)
                }
            }
        };
        window.pagespeed = window.pagespeed || {};
        var k = window.pagespeed;

        function l(b, a, c, g, h) {
            this.h = b;
            this.i = a;
            this.l = c;
            this.j = g;
            this.b = h;
            this.c = [];
            this.a = 0
        }
        l.prototype.f = function(b) {
            for (var a = 0; 250 > a && this.a < this.b.length; ++a, ++this.a) try {
                document.querySelector(this.b[this.a]) && this.c.push(this.b[this.a])
            } catch (c) {}
            this.a < this.b.length ? window.setTimeout(this.f.bind(this), 0, b) : b()
        };
        k.g = function(b, a, c, g, h) {
            if (document.querySelector && Function.prototype.bind) {
                var d = new l(b, a, c, g, h);
                f(function() {
                    window.setTimeout(function() {
                        d.f(function() {
                            for (var a = "oh=" + d.l + "&n=" + d.j, a = a + "&cs=", b = 0; b < d.c.length; ++b) {
                                var c = 0 < b ? "," : "",
                                    c = c + encodeURIComponent(d.c[b]);
                                if (131072 < a.length + c.length) break;
                                a += c
                            }
                            k.criticalCssBeaconData = a;
                            var b = d.h,
                                c = d.i,
                                e;
                            if (window.XMLHttpRequest) e = new XMLHttpRequest;
                            else if (window.ActiveXObject) try {
                                e = new ActiveXObject("Msxml2.XMLHTTP")
                            } catch (m) {
                                try {
                                    e = new ActiveXObject("Microsoft.XMLHTTP")
                                } catch (n) {}
                            }
                            e && (e.open("POST", b + (-1 == b.indexOf("?") ? "?" : "&") + "url=" + encodeURIComponent(c)), e.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), e.send(a))
                        })
                    }, 0)
                })
            }
        };
        k.criticalCssBeaconInit = k.g;
    })();
    pagespeed.selectors = ["*", ".accbotton a", ".accbotton a i", ".affix", ".alert", ".alert .alert-link", ".alert > p", ".alert > p + p", ".alert > ul", ".alert h4", ".alert-danger", ".alert-danger .alert-link", ".alert-danger hr", ".alert-dismissable", ".alert-dismissable .close", ".alert-dismissible", ".alert-dismissible .close", ".alert-info", ".alert-info .alert-link", ".alert-info hr", ".alert-success", ".alert-success .alert-link", ".alert-success hr", ".alert-warning", ".alert-warning .alert-link", ".alert-warning hr", ".badge", ".bg-danger", ".bg-info", ".bg-primary", ".bg-success", ".bg-warning", ".blockquote-reverse", ".blockquote-reverse .small", ".blockquote-reverse footer", ".blockquote-reverse small", ".breadcrumb", ".breadcrumb > .active", ".breadcrumb > li", ".breadcrumb > li + li", ".btn", ".btn .badge", ".btn .caret", ".btn .label", ".btn-block", ".btn-block + .btn-block", ".btn-danger", ".btn-danger .badge", ".btn-danger.active", ".btn-danger.active.focus", ".btn-danger.disabled", ".btn-danger.disabled.focus", ".btn-danger.focus", ".btn-danger[disabled]", ".btn-danger[disabled].focus", ".btn-default", ".btn-default .badge", ".btn-default.active", ".btn-default.active.focus", ".btn-default.disabled", ".btn-default.disabled.focus", ".btn-default.focus", ".btn-default[disabled]", ".btn-default[disabled].focus", ".btn-group", ".btn-group .btn + .btn", ".btn-group .btn + .btn-group", ".btn-group .btn-group + .btn", ".btn-group .btn-group + .btn-group", ".btn-group .dropdown-toggle", ".btn-group > .btn", ".btn-group > .btn + .dropdown-toggle", ".btn-group > .btn-group", ".btn-group > .btn-lg + .dropdown-toggle", ".btn-group > .btn.active", ".btn-group-justified", ".btn-group-justified > .btn", ".btn-group-justified > .btn-group", ".btn-group-justified > .btn-group .btn", ".btn-group-justified > .btn-group .dropdown-menu", ".btn-group-lg > .btn", ".btn-group-sm > .btn", ".btn-group-vertical", ".btn-group-vertical > .btn", ".btn-group-vertical > .btn + .btn", ".btn-group-vertical > .btn + .btn-group", ".btn-group-vertical > .btn-group", ".btn-group-vertical > .btn-group + .btn", ".btn-group-vertical > .btn-group + .btn-group", ".btn-group-vertical > .btn-group > .btn", ".btn-group-vertical > .btn.active", ".btn-group-xs > .btn", ".btn-group-xs > .btn .badge", ".btn-group.open .dropdown-toggle", ".btn-group.open .dropdown-toggle.btn-link", ".btn-info", ".btn-info .badge", ".btn-info.active", ".btn-info.active.focus", ".btn-info.disabled", ".btn-info.disabled.focus", ".btn-info.focus", ".btn-info[disabled]", ".btn-info[disabled].focus", ".btn-lg", ".btn-lg .caret", ".btn-link", ".btn-link.active", ".btn-link[disabled]", ".btn-primary", ".btn-primary .badge", ".btn-primary.active", ".btn-primary.active.focus", ".btn-primary.disabled", ".btn-primary.disabled.focus", ".btn-primary.focus", ".btn-primary[disabled]", ".btn-primary[disabled].focus", ".btn-sm", ".btn-success", ".btn-success .badge", ".btn-success.active", ".btn-success.active.focus", ".btn-success.disabled", ".btn-success.disabled.focus", ".btn-success.focus", ".btn-success[disabled]", ".btn-success[disabled].focus", ".btn-toolbar", ".btn-toolbar .btn", ".btn-toolbar .btn-group", ".btn-toolbar .input-group", ".btn-toolbar > .btn", ".btn-toolbar > .btn-group", ".btn-toolbar > .input-group", ".btn-warning", ".btn-warning .badge", ".btn-warning.active", ".btn-warning.active.focus", ".btn-warning.disabled", ".btn-warning.disabled.focus", ".btn-warning.focus", ".btn-warning[disabled]", ".btn-warning[disabled].focus", ".btn-xs", ".btn-xs .badge", ".btn.active", ".btn.active.focus", ".btn.disabled", ".btn.focus", ".btn[disabled]", ".caret", ".carousel", ".carousel-caption", ".carousel-caption .btn", ".carousel-control", ".carousel-control .glyphicon-chevron-left", ".carousel-control .glyphicon-chevron-right", ".carousel-control .icon-next", ".carousel-control .icon-prev", ".carousel-control.left", ".carousel-control.right", ".carousel-indicators", ".carousel-indicators .active", ".carousel-indicators li", ".carousel-inner", ".carousel-inner > .active", ".carousel-inner > .active.left", ".carousel-inner > .active.right", ".carousel-inner > .item", ".carousel-inner > .item > a > img", ".carousel-inner > .item > img", ".carousel-inner > .item.active", ".carousel-inner > .item.active.left", ".carousel-inner > .item.active.right", ".carousel-inner > .item.next", ".carousel-inner > .item.next.left", ".carousel-inner > .item.prev", ".carousel-inner > .item.prev.right", ".carousel-inner > .next", ".carousel-inner > .next.left", ".carousel-inner > .prev", ".carousel-inner > .prev.right", ".center-block", ".cfix", ".chart_box", ".chart_box ul", ".chart_box ul li", ".checkbox", ".checkbox + .checkbox", ".checkbox input[type=\"checkbox\"]", ".checkbox label", ".checkbox-inline", ".checkbox-inline + .checkbox-inline", ".checkbox-inline input[type=\"checkbox\"]", ".checkbox-inline.disabled", ".checkbox.disabled label", ".clearfix", ".close", ".col-lg-1", ".col-lg-10", ".col-lg-11", ".col-lg-12", ".col-lg-2", ".col-lg-3", ".col-lg-4", ".col-lg-5", ".col-lg-6", ".col-lg-7", ".col-lg-8", ".col-lg-9", ".col-lg-offset-0", ".col-lg-offset-1", ".col-lg-offset-10", ".col-lg-offset-11", ".col-lg-offset-12", ".col-lg-offset-2", ".col-lg-offset-3", ".col-lg-offset-4", ".col-lg-offset-5", ".col-lg-offset-6", ".col-lg-offset-7", ".col-lg-offset-8", ".col-lg-offset-9", ".col-lg-pull-0", ".col-lg-pull-1", ".col-lg-pull-10", ".col-lg-pull-11", ".col-lg-pull-12", ".col-lg-pull-2", ".col-lg-pull-3", ".col-lg-pull-4", ".col-lg-pull-5", ".col-lg-pull-6", ".col-lg-pull-7", ".col-lg-pull-8", ".col-lg-pull-9", ".col-lg-push-0", ".col-lg-push-1", ".col-lg-push-10", ".col-lg-push-11", ".col-lg-push-12", ".col-lg-push-2", ".col-lg-push-3", ".col-lg-push-4", ".col-lg-push-5", ".col-lg-push-6", ".col-lg-push-7", ".col-lg-push-8", ".col-lg-push-9", ".col-md-1", ".col-md-10", ".col-md-11", ".col-md-12", ".col-md-2", ".col-md-3", ".col-md-4", ".col-md-5", ".col-md-6", ".col-md-7", ".col-md-8", ".col-md-9", ".col-md-offset-0", ".col-md-offset-1", ".col-md-offset-10", ".col-md-offset-11", ".col-md-offset-12", ".col-md-offset-2", ".col-md-offset-3", ".col-md-offset-4", ".col-md-offset-5", ".col-md-offset-6", ".col-md-offset-7", ".col-md-offset-8", ".col-md-offset-9", ".col-md-pull-0", ".col-md-pull-1", ".col-md-pull-10", ".col-md-pull-11", ".col-md-pull-12", ".col-md-pull-2", ".col-md-pull-3", ".col-md-pull-4", ".col-md-pull-5", ".col-md-pull-6", ".col-md-pull-7", ".col-md-pull-8", ".col-md-pull-9", ".col-md-push-0", ".col-md-push-1", ".col-md-push-10", ".col-md-push-11", ".col-md-push-12", ".col-md-push-2", ".col-md-push-3", ".col-md-push-4", ".col-md-push-5", ".col-md-push-6", ".col-md-push-7", ".col-md-push-8", ".col-md-push-9", ".col-sm-1", ".col-sm-10", ".col-sm-11", ".col-sm-12", ".col-sm-2", ".col-sm-3", ".col-sm-4", ".col-sm-5", ".col-sm-6", ".col-sm-7", ".col-sm-8", ".col-sm-9", ".col-sm-offset-0", ".col-sm-offset-1", ".col-sm-offset-10", ".col-sm-offset-11", ".col-sm-offset-12", ".col-sm-offset-2", ".col-sm-offset-3", ".col-sm-offset-4", ".col-sm-offset-5", ".col-sm-offset-6", ".col-sm-offset-7", ".col-sm-offset-8", ".col-sm-offset-9", ".col-sm-pull-0", ".col-sm-pull-1", ".col-sm-pull-10", ".col-sm-pull-11", ".col-sm-pull-12", ".col-sm-pull-2", ".col-sm-pull-3", ".col-sm-pull-4", ".col-sm-pull-5", ".col-sm-pull-6", ".col-sm-pull-7", ".col-sm-pull-8", ".col-sm-pull-9", ".col-sm-push-0", ".col-sm-push-1", ".col-sm-push-10", ".col-sm-push-11", ".col-sm-push-12", ".col-sm-push-2", ".col-sm-push-3", ".col-sm-push-4", ".col-sm-push-5", ".col-sm-push-6", ".col-sm-push-7", ".col-sm-push-8", ".col-sm-push-9", ".col-xs-1", ".col-xs-10", ".col-xs-11", ".col-xs-12", ".col-xs-2", ".col-xs-3", ".col-xs-4", ".col-xs-5", ".col-xs-6", ".col-xs-7", ".col-xs-8", ".col-xs-9", ".col-xs-offset-0", ".col-xs-offset-1", ".col-xs-offset-10", ".col-xs-offset-11", ".col-xs-offset-12", ".col-xs-offset-2", ".col-xs-offset-3", ".col-xs-offset-4", ".col-xs-offset-5", ".col-xs-offset-6", ".col-xs-offset-7", ".col-xs-offset-8", ".col-xs-offset-9", ".col-xs-pull-0", ".col-xs-pull-1", ".col-xs-pull-10", ".col-xs-pull-11", ".col-xs-pull-12", ".col-xs-pull-2", ".col-xs-pull-3", ".col-xs-pull-4", ".col-xs-pull-5", ".col-xs-pull-6", ".col-xs-pull-7", ".col-xs-pull-8", ".col-xs-pull-9", ".col-xs-push-0", ".col-xs-push-1", ".col-xs-push-10", ".col-xs-push-11", ".col-xs-push-12", ".col-xs-push-2", ".col-xs-push-3", ".col-xs-push-4", ".col-xs-push-5", ".col-xs-push-6", ".col-xs-push-7", ".col-xs-push-8", ".col-xs-push-9", ".collapse", ".collapse.in", ".collapsing", ".container", ".container .jumbotron", ".container > .navbar-collapse", ".container > .navbar-header", ".container-fluid", ".container-fluid .jumbotron", ".container-fluid > .navbar-collapse", ".container-fluid > .navbar-header", ".default_table", ".default_table [type=\"button\"]", ".default_table [type=\"submit\"]", ".default_table table tr td", ".default_table table tr th", ".dl-horizontal dd", ".dl-horizontal dt", ".dropdown", ".dropdown-backdrop", ".dropdown-header", ".dropdown-menu", ".dropdown-menu .divider", ".dropdown-menu > .active > a", ".dropdown-menu > .disabled > a", ".dropdown-menu > li > a", ".dropdown-menu-left", ".dropdown-menu-right", ".dropdown-menu.pull-right", ".dropdown-toggle", ".dropup", ".dropup .btn-lg .caret", ".dropup .caret", ".dropup .dropdown-menu", ".embed-responsive", ".embed-responsive .embed-responsive-item", ".embed-responsive embed", ".embed-responsive iframe", ".embed-responsive object", ".embed-responsive video", ".embed-responsive-16by9", ".embed-responsive-4by3", ".errors li", ".fade", ".fade.in", ".form-control", ".form-control-feedback", ".form-control-static", ".form-control-static.input-lg", ".form-control-static.input-sm", ".form-control[disabled]", ".form-control[readonly]", ".form-group", ".form-group-lg .form-control", ".form-group-lg .form-control + .form-control-feedback", ".form-group-lg .form-control-static", ".form-group-lg select.form-control", ".form-group-lg select[multiple].form-control", ".form-group-lg textarea.form-control", ".form-group-sm .form-control", ".form-group-sm .form-control + .form-control-feedback", ".form-group-sm .form-control-static", ".form-group-sm select.form-control", ".form-group-sm select[multiple].form-control", ".form-group-sm textarea.form-control", ".form-horizontal .checkbox", ".form-horizontal .checkbox-inline", ".form-horizontal .control-label", ".form-horizontal .form-group", ".form-horizontal .form-group-lg .control-label", ".form-horizontal .form-group-sm .control-label", ".form-horizontal .has-feedback .form-control-feedback", ".form-horizontal .radio", ".form-horizontal .radio-inline", ".form-inline .checkbox", ".form-inline .checkbox input[type=\"checkbox\"]", ".form-inline .checkbox label", ".form-inline .control-label", ".form-inline .form-control", ".form-inline .form-control-static", ".form-inline .form-group", ".form-inline .has-feedback .form-control-feedback", ".form-inline .input-group", ".form-inline .input-group .form-control", ".form-inline .input-group .input-group-addon", ".form-inline .input-group .input-group-btn", ".form-inline .input-group > .form-control", ".form-inline .radio", ".form-inline .radio input[type=\"radio\"]", ".form-inline .radio label", ".glyphicon", ".glyphicon-adjust", ".glyphicon-alert", ".glyphicon-align-center", ".glyphicon-align-justify", ".glyphicon-align-left", ".glyphicon-align-right", ".glyphicon-apple", ".glyphicon-arrow-down", ".glyphicon-arrow-left", ".glyphicon-arrow-right", ".glyphicon-arrow-up", ".glyphicon-asterisk", ".glyphicon-baby-formula", ".glyphicon-backward", ".glyphicon-ban-circle", ".glyphicon-barcode", ".glyphicon-bed", ".glyphicon-bell", ".glyphicon-bishop", ".glyphicon-bitcoin", ".glyphicon-blackboard", ".glyphicon-bold", ".glyphicon-book", ".glyphicon-bookmark", ".glyphicon-briefcase", ".glyphicon-btc", ".glyphicon-bullhorn", ".glyphicon-calendar", ".glyphicon-camera", ".glyphicon-cd", ".glyphicon-certificate", ".glyphicon-check", ".glyphicon-chevron-down", ".glyphicon-chevron-left", ".glyphicon-chevron-right", ".glyphicon-chevron-up", ".glyphicon-circle-arrow-down", ".glyphicon-circle-arrow-left", ".glyphicon-circle-arrow-right", ".glyphicon-circle-arrow-up", ".glyphicon-cloud", ".glyphicon-cloud-download", ".glyphicon-cloud-upload", ".glyphicon-cog", ".glyphicon-collapse-down", ".glyphicon-collapse-up", ".glyphicon-comment", ".glyphicon-compressed", ".glyphicon-console", ".glyphicon-copy", ".glyphicon-copyright-mark", ".glyphicon-credit-card", ".glyphicon-cutlery", ".glyphicon-dashboard", ".glyphicon-download", ".glyphicon-download-alt", ".glyphicon-duplicate", ".glyphicon-earphone", ".glyphicon-edit", ".glyphicon-education", ".glyphicon-eject", ".glyphicon-envelope", ".glyphicon-equalizer", ".glyphicon-erase", ".glyphicon-eur", ".glyphicon-euro", ".glyphicon-exclamation-sign", ".glyphicon-expand", ".glyphicon-export", ".glyphicon-eye-close", ".glyphicon-eye-open", ".glyphicon-facetime-video", ".glyphicon-fast-backward", ".glyphicon-fast-forward", ".glyphicon-file", ".glyphicon-film", ".glyphicon-filter", ".glyphicon-fire", ".glyphicon-flag", ".glyphicon-flash", ".glyphicon-floppy-disk", ".glyphicon-floppy-open", ".glyphicon-floppy-remove", ".glyphicon-floppy-save", ".glyphicon-floppy-saved", ".glyphicon-folder-close", ".glyphicon-folder-open", ".glyphicon-font", ".glyphicon-forward", ".glyphicon-fullscreen", ".glyphicon-gbp", ".glyphicon-gift", ".glyphicon-glass", ".glyphicon-globe", ".glyphicon-grain", ".glyphicon-hand-down", ".glyphicon-hand-left", ".glyphicon-hand-right", ".glyphicon-hand-up", ".glyphicon-hd-video", ".glyphicon-hdd", ".glyphicon-header", ".glyphicon-headphones", ".glyphicon-heart", ".glyphicon-heart-empty", ".glyphicon-home", ".glyphicon-hourglass", ".glyphicon-ice-lolly", ".glyphicon-ice-lolly-tasted", ".glyphicon-import", ".glyphicon-inbox", ".glyphicon-indent-left", ".glyphicon-indent-right", ".glyphicon-info-sign", ".glyphicon-italic", ".glyphicon-jpy", ".glyphicon-king", ".glyphicon-knight", ".glyphicon-lamp", ".glyphicon-leaf", ".glyphicon-level-up", ".glyphicon-link", ".glyphicon-list", ".glyphicon-list-alt", ".glyphicon-lock", ".glyphicon-log-in", ".glyphicon-log-out", ".glyphicon-magnet", ".glyphicon-map-marker", ".glyphicon-menu-down", ".glyphicon-menu-hamburger", ".glyphicon-menu-left", ".glyphicon-menu-right", ".glyphicon-menu-up", ".glyphicon-minus", ".glyphicon-minus-sign", ".glyphicon-modal-window", ".glyphicon-move", ".glyphicon-music", ".glyphicon-new-window", ".glyphicon-object-align-bottom", ".glyphicon-object-align-horizontal", ".glyphicon-object-align-left", ".glyphicon-object-align-right", ".glyphicon-object-align-top", ".glyphicon-object-align-vertical", ".glyphicon-off", ".glyphicon-oil", ".glyphicon-ok", ".glyphicon-ok-circle", ".glyphicon-ok-sign", ".glyphicon-open", ".glyphicon-open-file", ".glyphicon-option-horizontal", ".glyphicon-option-vertical", ".glyphicon-paperclip", ".glyphicon-paste", ".glyphicon-pause", ".glyphicon-pawn", ".glyphicon-pencil", ".glyphicon-phone", ".glyphicon-phone-alt", ".glyphicon-picture", ".glyphicon-piggy-bank", ".glyphicon-plane", ".glyphicon-play", ".glyphicon-play-circle", ".glyphicon-plus", ".glyphicon-plus-sign", ".glyphicon-print", ".glyphicon-pushpin", ".glyphicon-qrcode", ".glyphicon-queen", ".glyphicon-question-sign", ".glyphicon-random", ".glyphicon-record", ".glyphicon-refresh", ".glyphicon-registration-mark", ".glyphicon-remove", ".glyphicon-remove-circle", ".glyphicon-remove-sign", ".glyphicon-repeat", ".glyphicon-resize-full", ".glyphicon-resize-horizontal", ".glyphicon-resize-small", ".glyphicon-resize-vertical", ".glyphicon-retweet", ".glyphicon-road", ".glyphicon-rub", ".glyphicon-ruble", ".glyphicon-save", ".glyphicon-save-file", ".glyphicon-saved", ".glyphicon-scale", ".glyphicon-scissors", ".glyphicon-screenshot", ".glyphicon-sd-video", ".glyphicon-search", ".glyphicon-send", ".glyphicon-share", ".glyphicon-share-alt", ".glyphicon-shopping-cart", ".glyphicon-signal", ".glyphicon-sort", ".glyphicon-sort-by-alphabet", ".glyphicon-sort-by-alphabet-alt", ".glyphicon-sort-by-attributes", ".glyphicon-sort-by-attributes-alt", ".glyphicon-sort-by-order", ".glyphicon-sort-by-order-alt", ".glyphicon-sound-5-1", ".glyphicon-sound-6-1", ".glyphicon-sound-7-1", ".glyphicon-sound-dolby", ".glyphicon-sound-stereo", ".glyphicon-star", ".glyphicon-star-empty", ".glyphicon-stats", ".glyphicon-step-backward", ".glyphicon-step-forward", ".glyphicon-stop", ".glyphicon-subscript", ".glyphicon-subtitles", ".glyphicon-sunglasses", ".glyphicon-superscript", ".glyphicon-tag", ".glyphicon-tags", ".glyphicon-tasks", ".glyphicon-tent", ".glyphicon-text-background", ".glyphicon-text-color", ".glyphicon-text-height", ".glyphicon-text-size", ".glyphicon-text-width", ".glyphicon-th", ".glyphicon-th-large", ".glyphicon-th-list", ".glyphicon-thumbs-down", ".glyphicon-thumbs-up", ".glyphicon-time", ".glyphicon-tint", ".glyphicon-tower", ".glyphicon-transfer", ".glyphicon-trash", ".glyphicon-tree-conifer", ".glyphicon-tree-deciduous", ".glyphicon-triangle-bottom", ".glyphicon-triangle-left", ".glyphicon-triangle-right", ".glyphicon-triangle-top", ".glyphicon-unchecked", ".glyphicon-upload", ".glyphicon-usd", ".glyphicon-user", ".glyphicon-volume-down", ".glyphicon-volume-off", ".glyphicon-volume-up", ".glyphicon-warning-sign", ".glyphicon-wrench", ".glyphicon-xbt", ".glyphicon-yen", ".glyphicon-zoom-in", ".glyphicon-zoom-out", ".h1", ".h1 .small", ".h1 small", ".h2", ".h2 .small", ".h2 small", ".h3", ".h3 .small", ".h3 small", ".h4", ".h4 .small", ".h4 small", ".h5", ".h5 .small", ".h5 small", ".h6", ".h6 .small", ".h6 small", ".has-error .checkbox", ".has-error .checkbox-inline", ".has-error .control-label", ".has-error .form-control", ".has-error .form-control-feedback", ".has-error .help-block", ".has-error .input-group-addon", ".has-error .radio", ".has-error .radio-inline", ".has-error.checkbox label", ".has-error.checkbox-inline label", ".has-error.radio label", ".has-error.radio-inline label", ".has-feedback", ".has-feedback .form-control", ".has-success .checkbox", ".has-success .checkbox-inline", ".has-success .control-label", ".has-success .form-control", ".has-success .form-control-feedback", ".has-success .help-block", ".has-success .input-group-addon", ".has-success .radio", ".has-success .radio-inline", ".has-success.checkbox label", ".has-success.checkbox-inline label", ".has-success.radio label", ".has-success.radio-inline label", ".has-warning .checkbox", ".has-warning .checkbox-inline", ".has-warning .control-label", ".has-warning .form-control", ".has-warning .form-control-feedback", ".has-warning .help-block", ".has-warning .input-group-addon", ".has-warning .radio", ".has-warning .radio-inline", ".has-warning.checkbox label", ".has-warning.checkbox-inline label", ".has-warning.radio label", ".has-warning.radio-inline label", ".help-block", ".hidden", ".hidden-lg", ".hidden-md", ".hidden-sm", ".hidden-xs", ".hide", ".hvr-shrink", ".icon-add", ".icon-calendar", ".icon-cards", ".icon-check", ".icon-clock", ".icon-coins", ".icon-down", ".icon-email", ".icon-faq", ".icon-headphone", ".icon-invest", ".icon-less", ".icon-link", ".icon-location", ".icon-lock", ".icon-logout", ".icon-monitor", ".icon-next", ".icon-person", ".icon-phone", ".icon-prev", ".icon-safebox", ".icon-server", ".icon-settings", ".icon-shield", ".icon-soc1", ".icon-soc2", ".icon-soc3", ".icon-team", ".icon-timer", ".icon-trophy", ".icon-up", ".icon-user1", ".icon-user2", ".icon-user3", ".icon-wallet", ".img-circle", ".img-responsive", ".img-rounded", ".img-thumbnail", ".initialism", ".input-group", ".input-group .form-control", ".input-group-addon", ".input-group-addon input[type=\"checkbox\"]", ".input-group-addon input[type=\"radio\"]", ".input-group-addon.input-lg", ".input-group-addon.input-sm", ".input-group-btn", ".input-group-btn > .btn", ".input-group-btn > .btn + .btn", ".input-group-btn > .btn-group", ".input-group-lg + .form-control-feedback", ".input-group-lg > .form-control", ".input-group-lg > .input-group-addon", ".input-group-lg > .input-group-btn > .btn", ".input-group-lg input[type=\"date\"]", ".input-group-lg input[type=\"datetime-local\"]", ".input-group-lg input[type=\"month\"]", ".input-group-lg input[type=\"time\"]", ".input-group-sm + .form-control-feedback", ".input-group-sm > .form-control", ".input-group-sm > .input-group-addon", ".input-group-sm > .input-group-btn > .btn", ".input-group-sm input[type=\"date\"]", ".input-group-sm input[type=\"datetime-local\"]", ".input-group-sm input[type=\"month\"]", ".input-group-sm input[type=\"time\"]", ".input-group[class*=\"col-\"]", ".input-lg", ".input-lg + .form-control-feedback", ".input-sm", ".input-sm + .form-control-feedback", ".invisible", ".jumbotron", ".jumbotron .container", ".jumbotron .h1", ".jumbotron > hr", ".jumbotron h1", ".jumbotron p", ".label", ".label-danger", ".label-danger[href]", ".label-default", ".label-default[href]", ".label-info", ".label-info[href]", ".label-primary", ".label-primary[href]", ".label-success", ".label-success[href]", ".label-warning", ".label-warning[href]", ".lead", ".list-group", ".list-group + .panel-footer", ".list-group-item", ".list-group-item > .badge", ".list-group-item > .badge + .badge", ".list-group-item-danger", ".list-group-item-heading", ".list-group-item-info", ".list-group-item-success", ".list-group-item-text", ".list-group-item-warning", ".list-group-item.active", ".list-group-item.active .list-group-item-heading", ".list-group-item.active .list-group-item-heading > .small", ".list-group-item.active .list-group-item-heading > small", ".list-group-item.active .list-group-item-text", ".list-group-item.active > .badge", ".list-group-item.disabled", ".list-group-item.disabled .list-group-item-heading", ".list-group-item.disabled .list-group-item-text", ".list-inline", ".list-inline > li", ".list-unstyled", ".mark", ".media", ".media > .pull-left", ".media > .pull-right", ".media-body", ".media-bottom", ".media-heading", ".media-left", ".media-list", ".media-middle", ".media-object", ".media-object.img-thumbnail", ".media-right", ".menu22", ".menu22 li a", ".modal", ".modal-backdrop", ".modal-backdrop.fade", ".modal-backdrop.in", ".modal-body", ".modal-content", ".modal-dialog", ".modal-footer", ".modal-footer .btn + .btn", ".modal-footer .btn-block + .btn-block", ".modal-footer .btn-group .btn + .btn", ".modal-header", ".modal-header .close", ".modal-lg", ".modal-open", ".modal-open .modal", ".modal-scrollbar-measure", ".modal-sm", ".modal-title", ".modal.fade .modal-dialog", ".modal.in .modal-dialog", ".nav", ".nav .nav-divider", ".nav .open > a", ".nav > li", ".nav > li > a", ".nav > li > a > img", ".nav > li.disabled > a", ".nav-justified", ".nav-justified > .dropdown .dropdown-menu", ".nav-justified > li", ".nav-justified > li > a", ".nav-pills > .active > a > .badge", ".nav-pills > li", ".nav-pills > li + li", ".nav-pills > li > a", ".nav-pills > li > a > .badge", ".nav-pills > li.active > a", ".nav-stacked > li", ".nav-stacked > li + li", ".nav-tabs", ".nav-tabs .dropdown-menu", ".nav-tabs > li", ".nav-tabs > li > a", ".nav-tabs > li.active > a", ".nav-tabs-justified", ".nav-tabs-justified > .active > a", ".nav-tabs-justified > li > a", ".nav-tabs.nav-justified", ".nav-tabs.nav-justified > .active > a", ".nav-tabs.nav-justified > .dropdown .dropdown-menu", ".nav-tabs.nav-justified > li", ".nav-tabs.nav-justified > li > a", ".navbar", ".navbar > .container .navbar-brand", ".navbar > .container-fluid .navbar-brand", ".navbar-brand", ".navbar-brand > img", ".navbar-btn", ".navbar-btn.btn-sm", ".navbar-btn.btn-xs", ".navbar-collapse", ".navbar-collapse.collapse", ".navbar-collapse.in", ".navbar-default", ".navbar-default .btn-link", ".navbar-default .btn-link[disabled]", ".navbar-default .navbar-brand", ".navbar-default .navbar-collapse", ".navbar-default .navbar-form", ".navbar-default .navbar-link", ".navbar-default .navbar-nav .open .dropdown-menu > .active > a", ".navbar-default .navbar-nav .open .dropdown-menu > .disabled > a", ".navbar-default .navbar-nav .open .dropdown-menu > li > a", ".navbar-default .navbar-nav > .active > a", ".navbar-default .navbar-nav > .disabled > a", ".navbar-default .navbar-nav > .open > a", ".navbar-default .navbar-nav > li > a", ".navbar-default .navbar-text", ".navbar-default .navbar-toggle", ".navbar-default .navbar-toggle .icon-bar", ".navbar-fixed-bottom", ".navbar-fixed-bottom .dropdown .caret", ".navbar-fixed-bottom .dropdown .dropdown-menu", ".navbar-fixed-bottom .navbar-collapse", ".navbar-fixed-bottom .navbar-nav > li > .dropdown-menu", ".navbar-fixed-top", ".navbar-fixed-top .navbar-collapse", ".navbar-form", ".navbar-form .checkbox", ".navbar-form .checkbox input[type=\"checkbox\"]", ".navbar-form .checkbox label", ".navbar-form .control-label", ".navbar-form .form-control", ".navbar-form .form-control-static", ".navbar-form .form-group", ".navbar-form .has-feedback .form-control-feedback", ".navbar-form .input-group", ".navbar-form .input-group .form-control", ".navbar-form .input-group .input-group-addon", ".navbar-form .input-group .input-group-btn", ".navbar-form .input-group > .form-control", ".navbar-form .radio", ".navbar-form .radio input[type=\"radio\"]", ".navbar-form .radio label", ".navbar-header", ".navbar-inverse", ".navbar-inverse .btn-link", ".navbar-inverse .btn-link[disabled]", ".navbar-inverse .navbar-brand", ".navbar-inverse .navbar-collapse", ".navbar-inverse .navbar-form", ".navbar-inverse .navbar-link", ".navbar-inverse .navbar-nav .open .dropdown-menu .divider", ".navbar-inverse .navbar-nav .open .dropdown-menu > .active > a", ".navbar-inverse .navbar-nav .open .dropdown-menu > .disabled > a", ".navbar-inverse .navbar-nav .open .dropdown-menu > .dropdown-header", ".navbar-inverse .navbar-nav .open .dropdown-menu > li > a", ".navbar-inverse .navbar-nav > .active > a", ".navbar-inverse .navbar-nav > .disabled > a", ".navbar-inverse .navbar-nav > .open > a", ".navbar-inverse .navbar-nav > li > a", ".navbar-inverse .navbar-text", ".navbar-inverse .navbar-toggle", ".navbar-inverse .navbar-toggle .icon-bar", ".navbar-left", ".navbar-nav", ".navbar-nav .open .dropdown-menu", ".navbar-nav .open .dropdown-menu .dropdown-header", ".navbar-nav .open .dropdown-menu > li > a", ".navbar-nav > li", ".navbar-nav > li > .dropdown-menu", ".navbar-nav > li > a", ".navbar-right", ".navbar-right .dropdown-menu", ".navbar-right .dropdown-menu-left", ".navbar-static-top", ".navbar-static-top .navbar-collapse", ".navbar-text", ".navbar-toggle", ".navbar-toggle .icon-bar", ".navbar-toggle .icon-bar + .icon-bar", ".open > .dropdown-menu", ".open > .dropdown-toggle.btn-danger", ".open > .dropdown-toggle.btn-danger.focus", ".open > .dropdown-toggle.btn-default", ".open > .dropdown-toggle.btn-default.focus", ".open > .dropdown-toggle.btn-info", ".open > .dropdown-toggle.btn-info.focus", ".open > .dropdown-toggle.btn-primary", ".open > .dropdown-toggle.btn-primary.focus", ".open > .dropdown-toggle.btn-success", ".open > .dropdown-toggle.btn-success.focus", ".open > .dropdown-toggle.btn-warning", ".open > .dropdown-toggle.btn-warning.focus", ".open > a", ".page-header", ".pager", ".pager .disabled > a", ".pager .disabled > span", ".pager .next > a", ".pager .next > span", ".pager .previous > a", ".pager .previous > span", ".pager li", ".pager li > a", ".pager li > span", ".pagination", ".pagination > .active > a", ".pagination > .active > span", ".pagination > .disabled > a", ".pagination > .disabled > span", ".pagination > li", ".pagination > li > a", ".pagination > li > span", ".pagination li", ".pagination-lg > li > a", ".pagination-lg > li > span", ".pagination-sm > li > a", ".pagination-sm > li > span", ".panel", ".panel > .list-group", ".panel > .list-group .list-group-item", ".panel > .panel-body + .table", ".panel > .panel-body + .table-responsive", ".panel > .panel-collapse > .list-group", ".panel > .panel-collapse > .list-group .list-group-item", ".panel > .panel-collapse > .table", ".panel > .panel-collapse > .table caption", ".panel > .panel-heading + .panel-collapse > .list-group .list-group-item", ".panel > .table", ".panel > .table + .panel-body", ".panel > .table > tbody > tr", ".panel > .table > tbody > tr td", ".panel > .table > tbody > tr th", ".panel > .table > tfoot > tr", ".panel > .table > tfoot > tr td", ".panel > .table > tfoot > tr th", ".panel > .table > thead > tr", ".panel > .table > thead > tr td", ".panel > .table > thead > tr th", ".panel > .table caption", ".panel > .table-bordered", ".panel > .table-bordered > tbody > tr > td", ".panel > .table-bordered > tbody > tr > th", ".panel > .table-bordered > tfoot > tr > td", ".panel > .table-bordered > tfoot > tr > th", ".panel > .table-bordered > thead > tr > td", ".panel > .table-bordered > thead > tr > th", ".panel > .table-responsive", ".panel > .table-responsive + .panel-body", ".panel > .table-responsive > .table", ".panel > .table-responsive > .table > tbody > tr", ".panel > .table-responsive > .table > tbody > tr td", ".panel > .table-responsive > .table > tbody > tr th", ".panel > .table-responsive > .table > tfoot > tr", ".panel > .table-responsive > .table > tfoot > tr td", ".panel > .table-responsive > .table > tfoot > tr th", ".panel > .table-responsive > .table > thead > tr", ".panel > .table-responsive > .table > thead > tr td", ".panel > .table-responsive > .table > thead > tr th", ".panel > .table-responsive > .table caption", ".panel > .table-responsive > .table-bordered", ".panel > .table-responsive > .table-bordered > tbody > tr > td", ".panel > .table-responsive > .table-bordered > tbody > tr > th", ".panel > .table-responsive > .table-bordered > tfoot > tr > td", ".panel > .table-responsive > .table-bordered > tfoot > tr > th", ".panel > .table-responsive > .table-bordered > thead > tr > td", ".panel > .table-responsive > .table-bordered > thead > tr > th", ".panel-body", ".panel-danger", ".panel-danger > .panel-footer + .panel-collapse > .panel-body", ".panel-danger > .panel-heading", ".panel-danger > .panel-heading + .panel-collapse > .panel-body", ".panel-danger > .panel-heading .badge", ".panel-default", ".panel-default > .panel-footer + .panel-collapse > .panel-body", ".panel-default > .panel-heading", ".panel-default > .panel-heading + .panel-collapse > .panel-body", ".panel-default > .panel-heading .badge", ".panel-footer", ".panel-group", ".panel-group .panel", ".panel-group .panel + .panel", ".panel-group .panel-footer", ".panel-group .panel-footer + .panel-collapse .panel-body", ".panel-group .panel-heading", ".panel-group .panel-heading + .panel-collapse > .list-group", ".panel-group .panel-heading + .panel-collapse > .panel-body", ".panel-heading", ".panel-heading + .list-group .list-group-item", ".panel-heading > .dropdown .dropdown-toggle", ".panel-info", ".panel-info > .panel-footer + .panel-collapse > .panel-body", ".panel-info > .panel-heading", ".panel-info > .panel-heading + .panel-collapse > .panel-body", ".panel-info > .panel-heading .badge", ".panel-primary", ".panel-primary > .panel-footer + .panel-collapse > .panel-body", ".panel-primary > .panel-heading", ".panel-primary > .panel-heading + .panel-collapse > .panel-body", ".panel-primary > .panel-heading .badge", ".panel-success", ".panel-success > .panel-footer + .panel-collapse > .panel-body", ".panel-success > .panel-heading", ".panel-success > .panel-heading + .panel-collapse > .panel-body", ".panel-success > .panel-heading .badge", ".panel-title", ".panel-title > .small", ".panel-title > .small > a", ".panel-title > a", ".panel-title > small", ".panel-title > small > a", ".panel-warning", ".panel-warning > .panel-footer + .panel-collapse > .panel-body", ".panel-warning > .panel-heading", ".panel-warning > .panel-heading + .panel-collapse > .panel-body", ".panel-warning > .panel-heading .badge", ".popover", ".popover > .arrow", ".popover-content", ".popover-title", ".popover.bottom", ".popover.bottom > .arrow", ".popover.left", ".popover.left > .arrow", ".popover.right", ".popover.right > .arrow", ".popover.top", ".popover.top > .arrow", ".pre-scrollable", ".progress", ".progress-bar", ".progress-bar-danger", ".progress-bar-info", ".progress-bar-striped", ".progress-bar-success", ".progress-bar-warning", ".progress-bar.active", ".progress-striped .progress-bar", ".progress-striped .progress-bar-danger", ".progress-striped .progress-bar-info", ".progress-striped .progress-bar-success", ".progress-striped .progress-bar-warning", ".progress.active .progress-bar", ".pull-left", ".pull-right", ".pull-right > .dropdown-menu", ".radio", ".radio + .radio", ".radio input[type=\"radio\"]", ".radio label", ".radio-inline", ".radio-inline + .radio-inline", ".radio-inline input[type=\"radio\"]", ".radio-inline.disabled", ".radio.disabled label", ".row", ".selectric", ".selectric .button", ".selectric .label", ".selectric-above .selectric-items", ".selectric-disabled", ".selectric-focus .selectric", ".selectric-hide-select", ".selectric-hide-select select", ".selectric-hide-select.selectric-is-native", ".selectric-hide-select.selectric-is-native select", ".selectric-hover .selectric", ".selectric-hover .selectric .button", ".selectric-input", ".selectric-items", ".selectric-items .disabled", ".selectric-items .selectric-group .selectric-group-label", ".selectric-items .selectric-group li", ".selectric-items .selectric-group.disabled li", ".selectric-items .selectric-scroll", ".selectric-items li", ".selectric-items li.highlighted", ".selectric-items li.selected", ".selectric-items ul", ".selectric-open", ".selectric-open .selectric", ".selectric-open .selectric-items", ".selectric-responsive", ".selectric-temp-show", ".selectric-wrapper", ".show", ".small", ".sr-only", ".sr-only-focusable", ".tab-content > .active", ".tab-content > .tab-pane", ".table", ".table .table", ".table > caption + thead > tr > td", ".table > caption + thead > tr > th", ".table > colgroup + thead > tr > td", ".table > colgroup + thead > tr > th", ".table > tbody + tbody", ".table > tbody > tr > td", ".table > tbody > tr > td.active", ".table > tbody > tr > td.danger", ".table > tbody > tr > td.info", ".table > tbody > tr > td.success", ".table > tbody > tr > td.warning", ".table > tbody > tr > th", ".table > tbody > tr > th.active", ".table > tbody > tr > th.danger", ".table > tbody > tr > th.info", ".table > tbody > tr > th.success", ".table > tbody > tr > th.warning", ".table > tbody > tr.active > td", ".table > tbody > tr.active > th", ".table > tbody > tr.danger > td", ".table > tbody > tr.danger > th", ".table > tbody > tr.info > td", ".table > tbody > tr.info > th", ".table > tbody > tr.success > td", ".table > tbody > tr.success > th", ".table > tbody > tr.warning > td", ".table > tbody > tr.warning > th", ".table > tfoot > tr > td", ".table > tfoot > tr > td.active", ".table > tfoot > tr > td.danger", ".table > tfoot > tr > td.info", ".table > tfoot > tr > td.success", ".table > tfoot > tr > td.warning", ".table > tfoot > tr > th", ".table > tfoot > tr > th.active", ".table > tfoot > tr > th.danger", ".table > tfoot > tr > th.info", ".table > tfoot > tr > th.success", ".table > tfoot > tr > th.warning", ".table > tfoot > tr.active > td", ".table > tfoot > tr.active > th", ".table > tfoot > tr.danger > td", ".table > tfoot > tr.danger > th", ".table > tfoot > tr.info > td", ".table > tfoot > tr.info > th", ".table > tfoot > tr.success > td", ".table > tfoot > tr.success > th", ".table > tfoot > tr.warning > td", ".table > tfoot > tr.warning > th", ".table > thead > tr > td", ".table > thead > tr > td.active", ".table > thead > tr > td.danger", ".table > thead > tr > td.info", ".table > thead > tr > td.success", ".table > thead > tr > td.warning", ".table > thead > tr > th", ".table > thead > tr > th.active", ".table > thead > tr > th.danger", ".table > thead > tr > th.info", ".table > thead > tr > th.success", ".table > thead > tr > th.warning", ".table > thead > tr.active > td", ".table > thead > tr.active > th", ".table > thead > tr.danger > td", ".table > thead > tr.danger > th", ".table > thead > tr.info > td", ".table > thead > tr.info > th", ".table > thead > tr.success > td", ".table > thead > tr.success > th", ".table > thead > tr.warning > td", ".table > thead > tr.warning > th", ".table-bordered", ".table-bordered > tbody > tr > td", ".table-bordered > tbody > tr > th", ".table-bordered > tfoot > tr > td", ".table-bordered > tfoot > tr > th", ".table-bordered > thead > tr > td", ".table-bordered > thead > tr > th", ".table-condensed > tbody > tr > td", ".table-condensed > tbody > tr > th", ".table-condensed > tfoot > tr > td", ".table-condensed > tfoot > tr > th", ".table-condensed > thead > tr > td", ".table-condensed > thead > tr > th", ".table-hover > tbody > tr", ".table-hover > tbody > tr > .active", ".table-hover > tbody > tr > .danger", ".table-hover > tbody > tr > .info", ".table-hover > tbody > tr > .success", ".table-hover > tbody > tr > .warning", ".table-hover > tbody > tr > td.active", ".table-hover > tbody > tr > td.danger", ".table-hover > tbody > tr > td.info", ".table-hover > tbody > tr > td.success", ".table-hover > tbody > tr > td.warning", ".table-hover > tbody > tr > th.active", ".table-hover > tbody > tr > th.danger", ".table-hover > tbody > tr > th.info", ".table-hover > tbody > tr > th.success", ".table-hover > tbody > tr > th.warning", ".table-hover > tbody > tr.active > td", ".table-hover > tbody > tr.active > th", ".table-hover > tbody > tr.danger > td", ".table-hover > tbody > tr.danger > th", ".table-hover > tbody > tr.info > td", ".table-hover > tbody > tr.info > th", ".table-hover > tbody > tr.success > td", ".table-hover > tbody > tr.success > th", ".table-hover > tbody > tr.warning > td", ".table-hover > tbody > tr.warning > th", ".table-responsive", ".table-responsive > .table", ".table-responsive > .table > tbody > tr > td", ".table-responsive > .table > tbody > tr > th", ".table-responsive > .table > tfoot > tr > td", ".table-responsive > .table > tfoot > tr > th", ".table-responsive > .table > thead > tr > td", ".table-responsive > .table > thead > tr > th", ".table-responsive > .table-bordered", ".table-responsive > .table-bordered > tbody > tr > td", ".table-responsive > .table-bordered > tbody > tr > th", ".table-responsive > .table-bordered > tfoot > tr > td", ".table-responsive > .table-bordered > tfoot > tr > th", ".table-responsive > .table-bordered > thead > tr > td", ".table-responsive > .table-bordered > thead > tr > th", ".text-capitalize", ".text-center", ".text-danger", ".text-hide", ".text-info", ".text-justify", ".text-left", ".text-lowercase", ".text-muted", ".text-nowrap", ".text-primary", ".text-right", ".text-success", ".text-uppercase", ".text-warning", ".textinfo", ".thumbnail", ".thumbnail .caption", ".thumbnail > img", ".thumbnail a > img", ".tooltip", ".tooltip-arrow", ".tooltip-inner", ".tooltip.bottom", ".tooltip.bottom .tooltip-arrow", ".tooltip.bottom-left .tooltip-arrow", ".tooltip.bottom-right .tooltip-arrow", ".tooltip.in", ".tooltip.left", ".tooltip.left .tooltip-arrow", ".tooltip.right", ".tooltip.right .tooltip-arrow", ".tooltip.top", ".tooltip.top .tooltip-arrow", ".tooltip.top-left .tooltip-arrow", ".tooltip.top-right .tooltip-arrow", ".visible-lg", ".visible-lg-block", ".visible-lg-inline", ".visible-lg-inline-block", ".visible-md", ".visible-md-block", ".visible-md-inline", ".visible-md-inline-block", ".visible-print", ".visible-print-block", ".visible-print-inline", ".visible-print-inline-block", ".visible-sm", ".visible-sm-block", ".visible-sm-inline", ".visible-sm-inline-block", ".visible-xs", ".visible-xs-block", ".visible-xs-inline", ".visible-xs-inline-block", ".well", ".well blockquote", ".well-lg", ".well-sm", "[class*=\" icon-\"]", "[class^=\"icon-\"]", "[data-toggle=\"buttons\"] > .btn input[type=\"checkbox\"]", "[data-toggle=\"buttons\"] > .btn input[type=\"radio\"]", "[data-toggle=\"buttons\"] > .btn-group > .btn input[type=\"checkbox\"]", "[data-toggle=\"buttons\"] > .btn-group > .btn input[type=\"radio\"]", "[hidden]", "[role=\"button\"]", "a", "a.badge", "a.bg-danger", "a.bg-info", "a.bg-primary", "a.bg-success", "a.bg-warning", "a.btn.disabled", "a.label", "a.list-group-item", "a.list-group-item .list-group-item-heading", "a.list-group-item-danger", "a.list-group-item-danger .list-group-item-heading", "a.list-group-item-danger.active", "a.list-group-item-info", "a.list-group-item-info .list-group-item-heading", "a.list-group-item-info.active", "a.list-group-item-success", "a.list-group-item-success .list-group-item-heading", "a.list-group-item-success.active", "a.list-group-item-warning", "a.list-group-item-warning .list-group-item-heading", "a.list-group-item-warning.active", "a.text-danger", "a.text-info", "a.text-primary", "a.text-success", "a.text-warning", "a.thumbnail", "a.thumbnail.active", "abbr[data-original-title]", "abbr[title]", "address", "article", "aside", "audio", "b", "blockquote", "blockquote .small", "blockquote footer", "blockquote ol", "blockquote p", "blockquote small", "blockquote ul", "blockquote.pull-right", "blockquote.pull-right .small", "blockquote.pull-right footer", "blockquote.pull-right small", "body", "body.lk", "body.lk *", "body.lk .accInfo", "body.lk .accInfo + .accStat", "body.lk .accInfo .accInfoItem + .accInfoItem", "body.lk .accInfo .backTitle", "body.lk .accInfoItem", "body.lk .accInfoItem .data", "body.lk .accInfoItem .data .num", "body.lk .accInfoItem .data .num sup", "body.lk .accInfoItem .data .title", "body.lk .accInfoItem .data .title + .num", "body.lk .accInfoItem .data .title + .username", "body.lk .accInfoItem .data .title + a", "body.lk .accInfoItem .data .username", "body.lk .accInfoItem .data .username + a", "body.lk .accInfoItem .data a", "body.lk .accInfoItem .img", "body.lk .accInfoItem .img [class*=\"icon\"]", "body.lk .accInfoItem .in", "body.lk .accStat", "body.lk .accStat .accStatItem", "body.lk .accStat .accStatItem + .accStatItem", "body.lk .accStat .back", "body.lk .accStat .backTitle", "body.lk .accStatItem .iconLeft", "body.lk .accStatItem .iconLeft .data .num", "body.lk .accStatItem .iconLeft .data .num sup", "body.lk .accStatItem .iconLeft .data .title", "body.lk .accStatItem .iconLeft [class*=\"icon\"]", "body.lk .account .wrap", "body.lk .balanceItem", "body.lk .balanceItem .iconLeft", "body.lk .balanceItem .iconLeft .data .bal", "body.lk .balanceItem .iconLeft .data .bal span", "body.lk .balanceItem .iconLeft .icon", "body.lk .balanceItem .iconLeft [class*=\"icon\"]", "body.lk .blockMod", "body.lk .bodyModal", "body.lk .bodyWrap", "body.lk .cabBalance .wrap", "body.lk .cabClock", "body.lk .cabClock .date", "body.lk .cabClock .date span", "body.lk .cabClock .time", "body.lk .cabClock .time + .date", "body.lk .cabClock .time span", "body.lk .cabContacts a", "body.lk .cabContacts span", "body.lk .cabContent", "body.lk .cabContent .backTitle", "body.lk .cabContent .cabHeading", "body.lk .cabContent .cabHeading + *", "body.lk .cabContent .cabHeading + .account", "body.lk .cabContent .cabHeading + .deposits", "body.lk .cabContent .cabHeading + .history", "body.lk .cabContent .cabHeading + .makeDeposit", "body.lk .cabContent .cabHeading + .referrals", "body.lk .cabContent .cabHeading + .settings", "body.lk .cabContent .cabHeading + .withdrawal", "body.lk .cabHead .infoWrap + .cabBalance", "body.lk .cabHead .infoWrap .wrap", "body.lk .cabHeading", "body.lk .cabInfo", "body.lk .cabInfo .cabContacts", "body.lk .cabInfo .langBlock", "body.lk .cabInfo .socList", "body.lk .cabLogo", "body.lk .cabLogo + .cabNav", "body.lk .cabLogo .logo", "body.lk .cabLogo .logo > a", "body.lk .cabLogo .logo img", "body.lk .cabLogo .openMenu", "body.lk .cabLogo .openMenu span", "body.lk .cabLogo .openMenu span + span", "body.lk .cabLogo .openMenu.active span", "body.lk .cabNav", "body.lk .cabNav + .copyright", "body.lk .cabNav li", "body.lk .cabNav li + li", "body.lk .cabNav li .iconLeft", "body.lk .cabNav li .iconLeft .data", "body.lk .cabNav li .iconLeft [class*=\"icon\"]", "body.lk .cabNav li > a", "body.lk .cabNav li.active", "body.lk .cabNav li.active .iconLeft .data", "body.lk .cabNav li.active .iconLeft [class*=\"icon\"]", "body.lk .cabTable .bal", "body.lk .cabTable .comm", "body.lk .cabTable .credit", "body.lk .cabTable .date", "body.lk .cabTable .debit", "body.lk .cabTable .pay", "body.lk .cabTable .tHead", "body.lk .cabTable .tHead + .tBody", "body.lk .cabTable .tHead .tCell", "body.lk .cabTable .tRow", "body.lk .cabTable .tRow + .tRow", "body.lk .cabTable .tRow .bal span", "body.lk .cabTable .tRow .comm span", "body.lk .cabTable .tRow .credit span", "body.lk .cabTable .tRow .date span", "body.lk .cabTable .tRow .debit span", "body.lk .cabTable .tRow .pay img", "body.lk .cabTable .tRow .tCell", "body.lk .cabTable .tRow .tCell .tLabel", "body.lk .cabTable .tRow .trans span", "body.lk .cabTable .trans", "body.lk .cabTitle", "body.lk .cabWrapper", "body.lk .cabWrapper .copyright", "body.lk .cabWrapper .copyright p", "body.lk .cabWrapper .left", "body.lk .cabWrapper .right", "body.lk .cabWrapper .right .inner", "body.lk .container", "body.lk .depAmount .cabTitle + [class*=\"inBlock\"]", "body.lk .depAmount [class*=\"inBlock\"]", "body.lk .depData", "body.lk .depData .progressBar .progress", "body.lk .depData .progressBar .progress .line", "body.lk .depData .progressBar .title", "body.lk .depData .progressBar .title + .progress", "body.lk .depData .progressBar .title span", "body.lk .depData li", "body.lk .depData li span", "body.lk .depData li span + span", "body.lk .depInfo", "body.lk .depInfo + .depData", "body.lk .depInfo .iconLeft", "body.lk .depInfo .iconLeft .num", "body.lk .depInfo .iconLeft .num.color", "body.lk .depInfo .iconLeft .title", "body.lk .depInfo .iconLeft [class*=\"icon\"]", "body.lk .depInfo img", "body.lk .depList .depositItem + .depositItem", "body.lk .depPayment .cabTitle + .paymentSys", "body.lk .depPayment .paymentSys", "body.lk .depPayment .paymentSys .checkWrap", "body.lk .depPayment .paymentSys .checkWrap li + li", "body.lk .depPayment .paymentSys .checkWrap li label", "body.lk .depPayment .paymentSys [class*=\"inBlock\"]", "body.lk .depPayment .paymentSys [class*=\"inBlock\"] + .checkWrap", "body.lk .depPayment [class*=\"inBlock\"] + .checkWrap", "body.lk .depResult", "body.lk .depResult .num", "body.lk .depResult .num sup", "body.lk .depResult .title", "body.lk .depResult .title + .num", "body.lk .depResult ul", "body.lk .depositItem", "body.lk .depositItem .depLeft", "body.lk .depositItem .depLeft + .wrap", "body.lk .depositItem .depLeft .title", "body.lk .depositItem .depPct", "body.lk .depositItem .depPct span", "body.lk .depositItem .depPct span.num", "body.lk .depositItem .progressKnob", "body.lk .depositItem .progressKnob input", "body.lk .depositItem .progressKnob span", "body.lk .depositItem .wrap", "body.lk .depositItem .wrap .col", "body.lk .depositItem .wrap .in", "body.lk .depositModal", "body.lk .depositModal .cabHeading", "body.lk .depositModal .cabHeading + .depositTable", "body.lk .depositModal .closeModal", "body.lk .depositTable", "body.lk .depositTable li", "body.lk .depositTable li + li", "body.lk .depositTable li .data", "body.lk .depositTable li .data.accr", "body.lk .depositTable li .data.accr span", "body.lk .depositTable li .data.date", "body.lk .depositTable li .data.pay img", "body.lk .depositTable li .data.pct", "body.lk .depositTable li .data.plan", "body.lk .depositTable li .data.plan span", "body.lk .depositTable li .data.state", "body.lk .depositTable li .data.sum", "body.lk .depositTable li .param", "body.lk .depositTable li > span", "body.lk .deposits", "body.lk .deposits .backTitle", "body.lk .deposits .depList + .pagination", "body.lk .deposits .pagination", "body.lk .filterBlock", "body.lk .filterBlock .date .inWrap", "body.lk .filterBlock .formWrap", "body.lk .filterBlock .option .inWrap", "body.lk .filterBlock [class*=\"btnFill\"]", "body.lk .filterBlock [class*=\"inBlock\"]", "body.lk .filterBlock [class*=\"inBlock\"] .inWrap", "body.lk .filterBlock [class*=\"inBlock\"] label", "body.lk .filterBlock [class*=\"inBlock\"] label + .inWrap", "body.lk .history", "body.lk .history .backTitle", "body.lk .history .cabTable + .pagination", "body.lk .history .filterBlock + .cabTable", "body.lk .history .pagination", "body.lk .historyTable .bal", "body.lk .historyTable .comm", "body.lk .historyTable .credit", "body.lk .historyTable .date", "body.lk .historyTable .debit", "body.lk .historyTable .pay", "body.lk .historyTable .tHead", "body.lk .historyTable .tHead + .tBody", "body.lk .historyTable .tRow", "body.lk .historyTable .tRow + .tRow", "body.lk .historyTable .tRow .tCell", "body.lk .historyTable .tRow .tCell + .tCell .tLabel", "body.lk .historyTable .tRow .tCell + .tCell > span", "body.lk .historyTable .tRow .tCell .tLabel", "body.lk .historyTable .tRow .tCell .tLabel + span", "body.lk .historyTable .tRow .tCell > span", "body.lk .historyTable .trans", "body.lk .langBlock", "body.lk .langBlock .arr", "body.lk .langBlock .head", "body.lk .langBlock .head .lang", "body.lk .langBlock .head.active .arr", "body.lk .langBlock .icon", "body.lk .langBlock .icon + .lang", "body.lk .langBlock .lang", "body.lk .langBlock .list", "body.lk .langBlock .list .item", "body.lk .langBlock .list .item + .item", "body.lk .langBlock .list .item .lang", "body.lk .langBlock .list .item > a", "body.lk .makeDeposit", "body.lk .makeDeposit .backTitle", "body.lk .makeDeposit .depResult", "body.lk .makeDeposit .formBl", "body.lk .makeDeposit .formBl .cabTitle + .paymentSys", "body.lk .makeDeposit .formBl .cabTitle + [class*=\"inBlock\"]", "body.lk .makeDeposit .row", "body.lk .makeDeposit .row + .row", "body.lk .makeDeposit .row + [class*=\"btnFill\"]", "body.lk .makeDeposit .row .item", "body.lk .makeDeposit .row .item + .item", "body.lk .makeDeposit [class*=\"btnFill\"]", "body.lk .modals", "body.lk .modals .tCell", "body.lk .modals.table", "body.lk .modalsScroll", "body.lk .modalsScroll.open", "body.lk .overlayModal", "body.lk .pagination", "body.lk .pagination .controls", "body.lk .pagination .controls + .pageNum", "body.lk .pagination .controls > a", "body.lk .pagination .controls span", "body.lk .pagination .pageNum", "body.lk .pagination .pageNum + .controls", "body.lk .pagination .pageNum li", "body.lk .pagination .pageNum li + li", "body.lk .pagination .pageNum li a", "body.lk .pagination .pageNum li.active a", "body.lk .paymentItem", "body.lk .paymentItem input", "body.lk .paymentItem input + label", "body.lk .paymentItem input + label img", "body.lk .paymentItem label", "body.lk .paymentItem label img", "body.lk .paymentsList .wrap", "body.lk .planItem", "body.lk .planItem .in", "body.lk .planItem .in .tCell", "body.lk .planItem .info", "body.lk .planItem .info .note", "body.lk .planItem .info ul + .note", "body.lk .planItem .info ul li", "body.lk .planItem .info ul li + li", "body.lk .planItem .info ul li span", "body.lk .planItem .planPct", "body.lk .planItem .planPct .pct + .term", "body.lk .planItem .planPct .pct span", "body.lk .planItem .planPct .pct span.num", "body.lk .planItem .planPct .term", "body.lk .planItem input", "body.lk .planItem label", "body.lk .radioBtn", "body.lk .radioBtn + label", "body.lk .refFilter", "body.lk .refFilter .formWrap", "body.lk .refFilter [class*=\"inBlock\"]", "body.lk .refFilter [class*=\"inBlock\"] + [class*=\"inBlock\"]", "body.lk .refFilter [class*=\"inBlock\"] .inWrap", "body.lk .refFilter [class*=\"inBlock\"] label", "body.lk .refFilter [class*=\"inBlock\"] label + .inWrap", "body.lk .refInfo", "body.lk .refInfo .iconLeft", "body.lk .refInfo .iconLeft .name", "body.lk .refInfo .iconLeft .title", "body.lk .refInfo .iconLeft [class*=\"icon\"]", "body.lk .refInfo .iconLeft a", "body.lk .refInfo ul", "body.lk .refInfo ul li", "body.lk .refItem .content", "body.lk .refItem .content p", "body.lk .refItem .content p span", "body.lk .refItem .head", "body.lk .refItem .head .iconLeft", "body.lk .refItem .head .iconLeft .data", "body.lk .refItem .head .iconLeft .data a", "body.lk .refItem .head .iconLeft .data span", "body.lk .refItem .head .iconLeft [class*=\"icon\"]", "body.lk .refItem .head .in", "body.lk .refItem .head .in .tCell", "body.lk .refItem .head .in .tCell + .tCell", "body.lk .refItem .head > .icon-add", "body.lk .refItem .head > .icon-less", "body.lk .refItem .head > [class*=\"icon\"]", "body.lk .refItem .head.active", "body.lk .refItem .head.active + .content", "body.lk .refItem .head.active .icon-add", "body.lk .refItem .head.active .icon-less", "body.lk .refList", "body.lk .refList .cabTitle + .wrap", "body.lk .refList .refItem + .refItem", "body.lk .refStat li", "body.lk .refStat li + li", "body.lk .refStat li .data", "body.lk .refStat li .param", "body.lk .refTable .date", "body.lk .refTable .ins", "body.lk .refTable .sign", "body.lk .refTable .tRow .date span", "body.lk .refTable .tRow .ins span", "body.lk .refTable .tRow .sign span", "body.lk .referrals", "body.lk .referrals .backTitle", "body.lk .referrals .refFilter + .refTable", "body.lk .referrals .refInfo + .refStat", "body.lk .referrals .row", "body.lk .referrals .row + .refList", "body.lk .referrals .row .item", "body.lk .referrals .row .item + .item", "body.lk .settings", "body.lk .settings .backTitle", "body.lk .settings .wrap", "body.lk .settings .wrap .item", "body.lk .settingsForm", "body.lk .settingsForm .cabTitle + .checkWrap", "body.lk .settingsForm .cabTitle + .formWrap", "body.lk .settingsForm .checkList + .checkList", "body.lk .settingsForm .checkList span", "body.lk .settingsForm .checkList span + ul", "body.lk .settingsForm .checkList ul li + li", "body.lk .settingsForm .formWrap [class*=\"inBlock\"] + [class*=\"inBlock\"]", "body.lk .settingsForm .in", "body.lk .settingsForm [class*=\"btnFill\"]", "body.lk .socList", "body.lk .socList li", "body.lk .socList li + li", "body.lk .socList li > a", "body.lk .socList li [class*=\"icon\"]", "body.lk .ui-datepicker", "body.lk .ui-datepicker .ui-datepicker-header", "body.lk .ui-datepicker .ui-datepicker-header .ui-datepicker-next", "body.lk .ui-datepicker .ui-datepicker-header .ui-datepicker-next .ui-icon", "body.lk .ui-datepicker .ui-datepicker-header .ui-datepicker-prev", "body.lk .ui-datepicker .ui-datepicker-header .ui-datepicker-prev .ui-icon", "body.lk .ui-datepicker .ui-datepicker-header .ui-icon", "body.lk .ui-datepicker .ui-state-default", "body.lk .ui-datepicker .ui-state-default.ui-state-active", "body.lk .ui-datepicker .ui-state-default.ui-state-highlight", "body.lk .userInfo", "body.lk .userInfo .iconLeft", "body.lk .userInfo .iconLeft .data span", "body.lk .userInfo .iconLeft .data span + span", "body.lk .userInfo .iconLeft .data span.name", "body.lk .userInfo .iconLeft [class*=\"icon\"]", "body.lk .userInfo li", "body.lk .withAmount", "body.lk .withAmount .cabTitle", "body.lk .withAmount .cabTitle + [class*=\"inBlock\"]", "body.lk .withPayment", "body.lk .withPayment .cabTitle", "body.lk .withPayment .cabTitle + .paymentsList", "body.lk .withResult", "body.lk .withResult .num", "body.lk .withResult .num sup", "body.lk .withResult .title", "body.lk .withResult .title + .num", "body.lk .withdrawal", "body.lk .withdrawal .backTitle", "body.lk .withdrawal .withPayment", "body.lk .withdrawal .withPayment + .wrap", "body.lk .withdrawal .withPayment .wrap", "body.lk .withdrawal .wrap", "body.lk .withdrawal .wrap + [class*=\"btnFill\"]", "body.lk .withdrawal .wrap .item", "body.lk .withdrawal .wrap .item + .item", "body.lk .withdrawal [class*=\"btnFill\"]", "body.lk [class*=\"btnFill\"]", "body.lk [class*=\"btnFill\"].center", "body.lk [class*=\"btnFill\"].full", "body.lk [class*=\"btnFill\"][class*=\"Lg\"]", "body.lk [class*=\"btnFill\"][class*=\"Sm\"]", "body.lk [class*=\"btnFill\"][class*=\"Type1\"]", "body.lk [class*=\"iconLeft\"]", "body.lk [class*=\"iconLeft\"] [class*=\"icon\"]", "body.lk [class*=\"inBlock\"] .inWrap input", "body.lk [class*=\"inBlock\"].line", "body.lk [class*=\"inBlock\"].line .inWrap", "body.lk [class*=\"inBlock\"].line label", "body.lk [class*=\"inBlock\"].line label + .inWrap", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .arr", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .curr", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .selectric", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .selectric .button", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .selectric .label", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .selectric-items", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap .selectric-items li", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap input", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] .inWrap.icon input", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] label", "body.lk [class*=\"inBlock\"][class*=\"Type1\"] label + .inWrap", "body.lk a", "body.lk button", "body.lk h1", "body.lk h2", "body.lk h3", "body.lk h4", "body.lk h5", "body.lk h6", "body.lk input", "body.lk p", "body.lk select", "body.lk textarea", "body.lk ul", "body.site", "body.site *", "body.site .aboutCompany", "body.site .aboutCompany .left", "body.site .aboutCompany .right", "body.site .aboutCompany .wrapIn", "body.site .aboutPage", "body.site .aboutPage .capBlock .capVisible", "body.site .aboutPage .left", "body.site .aboutPage .lineAdress", "body.site .aboutPage .lineAdress .btn", "body.site .aboutPage .lineAdress .iconBl", "body.site .aboutPage .right", "body.site .aboutPage .right .textBlock", "body.site .aboutPage .textBlock", "body.site .aboutPage .textBlock a", "body.site .aboutPage .textBlock b", "body.site .aboutPage .textBlock b + *", "body.site .aboutPage .textBlock p + p", "body.site .aboutPage .textBlock ul + *", "body.site .aboutPage .wrapIn", "body.site .affilateWork", "body.site .affilateWork .affiliateBl", "body.site .affilateWork .affiliateBl .wrapIn", "body.site .affilateWork .listLevelBl", "body.site .affilateWork .txtLeftBlock .cap + *", "body.site .affiliateBl", "body.site .affiliateBl + .operBlock", "body.site .affiliateBl .list", "body.site .affiliateBl .list .btn", "body.site .affiliateBl .list .col", "body.site .affiliateBl .list .col + .col", "body.site .affiliateBl .list .desr", "body.site .affiliateBl .list .text", "body.site .affiliateBl .list .tit", "body.site .affiliateBl .txtLeftBlock", "body.site .affiliateBl .waves", "body.site .affiliateBl .wrapIn", "body.site .backPic", "body.site .bonusPage", "body.site .bonusPage .left", "body.site .bonusPage .right", "body.site .bonusPage .txtLeftBlock", "body.site .bonusPage .txtLeftBlock .cap + *", "body.site .bonusPage .txtLeftBlock p + b", "body.site .bonusPage .txtLeftBlock p + p", "body.site .bonusPage .wrapIn", "body.site .bountyLineClick .lineClick", "body.site .bountyLineClick .lineClick .btn", "body.site .bountyLineClick .lineClick .infoMoney", "body.site .bountyLineClick .lineClick .link", "body.site .bountyLineClick .lineClick .nameLog", "body.site .bountyLineClick .lineClick .text", "body.site .bountyLineClick .lineClick .wrapIn", "body.site .bountyPage", "body.site .bountyPage .left", "body.site .bountyPage .left .capBlock .capVisible", "body.site .bountyPage .right", "body.site .bountyPage .textBlock", "body.site .bountyPage .textBlock b", "body.site .bountyPage .textBlock b + *", "body.site .bountyPage .textBlock p + p", "body.site .bountyPage .wrapIn", "body.site .btn", "body.site .btn.btnGrDark", "body.site .btn.btnGrDark2", "body.site .btn.btnGrLigh", "body.site .calcBlock", "body.site .calcBlock .btn", "body.site .calcBlock .desr", "body.site .calcBlock .forma .inputLine", "body.site .calcBlock .forma .inputLine label", "body.site .calcBlock .forma .selectric-items", "body.site .calcBlock .forma .selectric-scroll", "body.site .calcBlock .forma .selectric-scroll ul li", "body.site .calcBlock .forma .selectric-scroll ul li.highlighted", "body.site .calcBlock .forma .selectric-scroll ul li.selected", "body.site .calcBlock .forma .wrap", "body.site .calcBlock .infoTxt", "body.site .calcBlock .infoTxt ul", "body.site .calcBlock .infoTxt ul li", "body.site .calcBlock .infoTxt ul li + li", "body.site .calcBlock .infoTxt ul li .iconBl", "body.site .calcBlock .infoTxt ul li .pr", "body.site .calcBlock .infoTxt ul li .pr sub", "body.site .calcBlock .infoTxt ul li .tit", "body.site .calcBlock .title", "body.site .capBlock .cap", "body.site .capBlock .capVisible", "body.site .capBlock .desr", "body.site .captchBl", "body.site .captchBl .captch", "body.site .captchBl input", "body.site .cfix", "body.site .chekBl input", "body.site .chekBl input + label", "body.site .chekBl label", "body.site .choseBl", "body.site .choseBl .capBlock + .textBlock", "body.site .choseBl .left", "body.site .choseBl .left .picture", "body.site .choseBl .line", "body.site .choseBl .line .capVisible", "body.site .choseBl .line .textBlock", "body.site .choseBl .line .textBlock p", "body.site .choseBl .line .textBlock p + p", "body.site .choseBl .right", "body.site .choseBl .textBlock", "body.site .choseBl .textBlock ul", "body.site .choseBl .textBlock ul + *", "body.site .choseBl .textBlock ul li", "body.site .choseBl .textBlock ul li + li", "body.site .choseBl .textBlock ul li .iconBl", "body.site .choseBl .wrapIn", "body.site .colorMobieWhite", "body.site .container", "body.site .content", "body.site .curGoalBl", "body.site .curGoalBl .line", "body.site .curGoalBl .line + .line", "body.site .curGoalBl .line .capBlock", "body.site .curGoalBl .line .capBlock .capVisible", "body.site .curGoalBl .line .left", "body.site .curGoalBl .line .right", "body.site .curGoalBl .line .textBlock", "body.site .curGoalBl .line .textBlock b", "body.site .curGoalBl .line .textBlock b + b", "body.site .curGoalBl .line .textBlock b + ul", "body.site .curGoalBl .lineBot", "body.site .curGoalBl .lineBot ul", "body.site .curGoalBl .lineBot ul li", "body.site .curGoalBl .lineBot ul li + li", "body.site .curGoalBl .lineBot ul li .btn", "body.site .curGoalBl .lineBot ul li .btnGrLigh", "body.site .curGoalBl .lineBot ul li .name", "body.site .curGoalBl .list", "body.site .curGoalBl .list .item", "body.site .curGoalBl .list .item + .item", "body.site .curGoalBl .list .picture", "body.site .curGoalBl .list .picture .num", "body.site .curGoalBl .list .picture .pic", "body.site .curGoalBl .wrapIn > .picture", "body.site .curGoalLast", "body.site .curGoalLast .capBlock", "body.site .curGoalLast .capBlock .capVisible", "body.site .curGoalLast .left", "body.site .curGoalLast .lineClick", "body.site .curGoalLast .lineClick .left", "body.site .curGoalLast .lineClick .right", "body.site .curGoalLast .lineClick .right .btn", "body.site .curGoalLast .lineClick .right .text", "body.site .curGoalLast .right", "body.site .curGoalLast .right .txt", "body.site .curGoalLast .right ul", "body.site .curGoalLast .right ul li", "body.site .curGoalLast .right ul li + li", "body.site .curGoalLast .right ul li .iconBl", "body.site .curGoalLast .textBlock", "body.site .curGoalLast .textBlock .btn", "body.site .curGoalLast .textBlock b", "body.site .curGoalLast .textBlock b + .btn", "body.site .curGoalLast .textBlock b + b", "body.site .curGoalLast .textBlock b a", "body.site .curGoalLast .textBlock ul", "body.site .curGoalLast .textBlock ul + *", "body.site .curGoalLast .textBlock ul li + li", "body.site .curGoalLast .wrapIn", "body.site .editorial", "body.site .faqBlock", "body.site .faqBlock .lineQuest + .lineQuest", "body.site .faqBlock .lineQuest .answer", "body.site .faqBlock .lineQuest .iconBl", "body.site .faqBlock .lineQuest .quest", "body.site .faqBlock .lineQuest .quest.open", "body.site .faqBlock .title", "body.site .faqBlock .title + *", "body.site .faqBlock .title .num", "body.site .faqBlock .title .tit", "body.site .faqList", "body.site .faqList .faqBlock + .faqBlock", "body.site .faqPage", "body.site .faqPage .wrapIn", "body.site .followBl .tit", "body.site .followBl ul", "body.site .followBl ul li", "body.site .followBl ul li + li", "body.site .followBl ul li .num", "body.site .followBl ul li p", "body.site .footerMain", "body.site .formaCall", "body.site .formaCall .btn", "body.site .formaCall .forma", "body.site .formaCall .forma .inputLine input", "body.site .formaCall .forma .inputLine label", "body.site .formaCall .forma .inputLine textarea", "body.site .formaCall .inputLine", "body.site .grettingsMain", "body.site .grettingsMain .wrapIn", "body.site .grettingsPage", "body.site .grettingsPage .cap", "body.site .grettingsPage .listCur", "body.site .headerMainPage", "body.site .iconCircle", "body.site .infoContacts", "body.site .infoContacts + *", "body.site .infoContacts li", "body.site .infoContacts li + li", "body.site .infoContacts li .iconBl", "body.site .infoContacts li .link", "body.site .infoContacts li .linkPhone", "body.site .infoContacts li .tit", "body.site .infoContacts li p", "body.site .inputLine .selectric-wrapper .selectric", "body.site .inputLine .selectric-wrapper .selectric .button", "body.site .inputLine .selectric-wrapper .selectric .label", "body.site .inputLine input", "body.site .inputLine label", "body.site .inputLine label + *", "body.site .inputLine textarea", "body.site .invisLink", "body.site .invisLink > a", "body.site .lastOperTable", "body.site .lastOperTable .col", "body.site .lastOperTable .col + .col", "body.site .lastOperTable .col + .col .iconTop", "body.site .lastOperTable .col .cap", "body.site .lastOperTable .col .desr", "body.site .lastOperTable .col .iconTop", "body.site .lastOperTable .col ul", "body.site .lastOperTable .col ul li", "body.site .lastOperTable .col ul li .name", "body.site .lastOperTable .col ul li .picPlat", "body.site .lastOperTable .col ul li .user", "body.site .lastOperTable .col ul li .val", "body.site .lineAdress", "body.site .lineAdress .btn", "body.site .lineAdress .col", "body.site .lineAdress .col + .col", "body.site .lineAdress .col .adress", "body.site .lineAdress .col .num", "body.site .lineAdress .col .tit", "body.site .lineAdress .iconBl", "body.site .lineClick", "body.site .lineClick .btn", "body.site .lineClick .capVisible", "body.site .lineClick .left", "body.site .lineClick .link", "body.site .lineClick .nameLog", "body.site .lineClick .nameLog + .btn", "body.site .lineClick .right", "body.site .lineClick .text", "body.site .lineClick .text br", "body.site .lineClick .wrapIn", "body.site .lineSteps", "body.site .lineSteps .col", "body.site .lineSteps .col + .col", "body.site .lineSteps .list", "body.site .lineSteps .num", "body.site .lineSteps .text", "body.site .lineSteps .tit", "body.site .lineSteps .txtLeftBlock", "body.site .lineTop", "body.site .lineTop .logo img", "body.site .lineTop .wrapIn", "body.site .lineTopInfo .clockBl", "body.site .lineTopInfo .clockBl #date", "body.site .lineTopInfo .clockBl #time", "body.site .lineTopInfo .clockBl #time .dot", "body.site .lineTopInfo .langBl", "body.site .lineTopInfo .langBl .lang", "body.site .lineTopInfo .langBl .pic", "body.site .lineTopInfo .langBl ul", "body.site .lineTopInfo .langBl ul li a", "body.site .lineTopInfo .socialBl", "body.site .lineTopInfo .wrapIn", "body.site .linkLog", "body.site .linkLog .btn", "body.site .listCur", "body.site .listCur .item", "body.site .listCur .item + .item", "body.site .listCur .item .iconCircle", "body.site .listCur .item .val", "body.site .listCur .item .valPr", "body.site .listDep", "body.site .listDep .circle", "body.site .listDep .circle .hours", "body.site .listDep .circle .prVal", "body.site .listDep .circle .txt", "body.site .listDep .desr", "body.site .listDep .item", "body.site .listDep .item + .item", "body.site .listDep .item .pr", "body.site .listDep ul", "body.site .listDep ul li .tit", "body.site .listDep ul li .val", "body.site .listLevelBl", "body.site .listLevelBl .item", "body.site .listLevelBl .item .circle", "body.site .listLevelBl .item .circle .prCirc", "body.site .listLevelBl .item .circle .prCirc sub", "body.site .listLevelBl .item .desr", "body.site .listLevelBl .item .pr", "body.site .listNews", "body.site .listNews .item", "body.site .listNews .item + .item", "body.site .listNews .item .picture", "body.site .listNews .item .picture .pic", "body.site .listNews .item .text", "body.site .listNews .item .text .btn", "body.site .listNews .item .text .date", "body.site .listNews .item .text .iconBl", "body.site .listNews .item .text .name", "body.site .listNews .item .text p", "body.site .loginPage", "body.site .loginPage .btn", "body.site .loginPage .forma .chekBl", "body.site .loginPage .forma .chekBl label", "body.site .loginPage .forma .chekBl label a", "body.site .loginPage .forma .inputLine", "body.site .loginPage .forma .inputLine .button", "body.site .loginPage .forma .inputLine .iconBl", "body.site .loginPage .forma .inputLine .selectric", "body.site .loginPage .forma .inputLine .selectric .label", "body.site .loginPage .forma .inputLine input", "body.site .loginPage .forma .inputLine label", "body.site .loginPage .forma .inputLine label + *", "body.site .loginPage .forma .link", "body.site .loginPage .left", "body.site .loginPage .left .forma", "body.site .loginPage .left .forma .inputLine", "body.site .loginPage .right", "body.site .loginPage .wrapIn", "body.site .logo", "body.site .mapBl", "body.site .menu", "body.site .menu ul", "body.site .menu ul li", "body.site .menu ul li a", "body.site .menu ul li a.active", "body.site .menuBtn", "body.site .menuBtn span", "body.site .menuBtn span + span", "body.site .nameLog", "body.site .nameLog + *", "body.site .nameLog .cap", "body.site .nameLog .capVisible", "body.site .nameLog .desr", "body.site .nameLog .iconBl", "body.site .newsPage", "body.site .operBlock", "body.site .operBlock .left", "body.site .operBlock .left .capVisible", "body.site .operBlock .right", "body.site .operBlock .right .capVisible", "body.site .operBlock .wrapIn", "body.site .pagination", "body.site .pagination ul", "body.site .pagination ul li + li", "body.site .pagination ul li a", "body.site .pagination ul li a.active", "body.site .pagination ul li a.next", "body.site .pagination ul li a.prev", "body.site .parallax > use", "body.site .partAboutBl .btn", "body.site .partAboutBl .capBlock + *", "body.site .partAboutBl .iconBl", "body.site .partAboutBl .list", "body.site .partAboutBl .list .item", "body.site .partAboutBl .tit", "body.site .partAboutBl .txt", "body.site .partBl", "body.site .partBl ul", "body.site .partBl ul li", "body.site .pictureMoney", "body.site .pictureMoney .capVisible", "body.site .pictureMoney .pic", "body.site .pictureMoney .val", "body.site .plLineBlock", "body.site .plLineBlock ul", "body.site .plLineBlock ul li", "body.site .plLineBlock ul li + li", "body.site .rulesList", "body.site .rulesList .lineRules + .lineRules", "body.site .rulesList .lineRules .name", "body.site .rulesList .lineRules .num", "body.site .rulesList .lineRules .top", "body.site .rulesList .lineRules .top + *", "body.site .rulesList .lineRules p", "body.site .rulesList .lineRules p + p", "body.site .rulesPage", "body.site .rulesPage .textBlock", "body.site .rulesPage .textBlock b", "body.site .rulesPage .textBlock b + p", "body.site .rulesPage .textBlock p", "body.site .rulesPage .wrapIn", "body.site .socialBl ul", "body.site .socialBl ul li + li", "body.site .socialBl ul li .iconBl", "body.site .socialBl ul li a", "body.site .socialBl ul li a .iconBl", "body.site .statMiniBl", "body.site .statMiniBl .back", "body.site .statMiniBl .capVisible", "body.site .statMiniBl ul", "body.site .statMiniBl ul li", "body.site .statMiniBl ul li + li", "body.site .statMiniBl ul li .iconBl", "body.site .statMiniBl ul li .tit", "body.site .statMiniBl ul li .val", "body.site .statMiniBl ul li .val sub", "body.site .supportPage", "body.site .supportPage .capBlock", "body.site .supportPage .left", "body.site .supportPage .left .capVisible", "body.site .supportPage .left .socialBl", "body.site .supportPage .left .socialBl ul li + li", "body.site .supportPage .left .socialBl ul li a", "body.site .supportPage .right", "body.site .supportPage .right .capVisible", "body.site .supportPage .wrapIn", "body.site .tabsForm", "body.site .tabsForm .btn", "body.site .tabsForm .inputLine input", "body.site .tabsForm .left", "body.site .tabsForm .left ul", "body.site .tabsForm .left ul li", "body.site .tabsForm .left ul li + li", "body.site .tabsForm .left ul li .iconBl", "body.site .tabsForm .left ul li .tit", "body.site .tabsForm .left ul li .val", "body.site .tabsForm .left ul li .val sub", "body.site .tabsForm .right", "body.site .tabsForm .textBlock", "body.site .tabsForm .textBlock b + *", "body.site .tabsForm .textBlock ul + *", "body.site .tabsForm .title", "body.site .tabsForm .title + *", "body.site .tabsForm .title + .textBlock", "body.site .textBlock ul li", "body.site .textBlock ul li + li", "body.site .textGretting", "body.site .textGretting .btn", "body.site .textGretting .cap", "body.site .textGretting .cap br", "body.site .textGretting p", "body.site .textGretting p br", "body.site .txtBonusRight .list + *", "body.site .txtBonusRight .list li", "body.site .txtBonusRight .list li + li", "body.site .txtBonusRight .list li .num", "body.site .txtBonusRight .list li a", "body.site .txtBonusRight .textBlock", "body.site .txtBonusRight .textBlock ul li", "body.site .txtBonusRight .textBlock ul li + li", "body.site .txtBonusRight .textBlock ul li a", "body.site .txtBonusRight .title", "body.site .txtBonusRight .title + *", "body.site .txtLeftBlock", "body.site .txtLeftBlock .btn", "body.site .txtLeftBlock .cap", "body.site .txtLeftBlock .cap + *", "body.site .txtLeftBlock .capVisible", "body.site .txtLeftBlock .desr", "body.site .txtLeftBlock .desr + *", "body.site .txtLeftBlock b", "body.site .txtLeftBlock b + p", "body.site .txtLeftBlock p", "body.site .userSays", "body.site .userSays .item", "body.site .userSays .item .pic", "body.site .userSays .item .picture", "body.site .userSays .item .txt", "body.site .userSays .item .txt .date", "body.site .userSays .item .txt .name", "body.site .userSays .item .txt p", "body.site .whyBl", "body.site .whyBl .left", "body.site .whyBl .left .item", "body.site .whyBl .left .item .iconBl", "body.site .whyBl .left .item .text", "body.site .whyBl .left .item .tit", "body.site .whyBl .left .list", "body.site .whyBl .left .picture", "body.site .whyBl .right", "body.site .whyBl .wrapIn", "body.site .workPage", "body.site .workPage .tabs", "body.site .workPage .tabs .listLink", "body.site .workPage .tabs .listLink .circle", "body.site .workPage .tabs .listLink .circle .hours", "body.site .workPage .tabs .listLink .circle .prVal", "body.site .workPage .tabs .listLink .circle .txt", "body.site .workPage .tabs .listLink .desr", "body.site .workPage .tabs .listLink > li", "body.site .workPage .tabs .listLink > li > a", "body.site .workPage .tabs .listLink > li.ui-tabs-active", "body.site .workPage .tabs .listLink > li.ui-tabs-active .tit", "body.site .workPage .tabs .listLink ul", "body.site .workPage .tabs .listLink ul li", "body.site .workPage .tabs .listLink ul li .tit", "body.site .workPage .tabs .listLink ul li .val", "body.site .workPage .tabs .tabs-body", "body.site .workPage .txtLeftBlock", "body.site .workPage .txtLeftBlock .capVisible", "body.site .workProcess", "body.site .workProcess .capBlock .capVisible", "body.site .workProcess .list", "body.site .workProcess .list .item", "body.site .workProcess .list .item .iconBl", "body.site .workProcess .list .item .num", "body.site .workProcess .list .item .tit", "body.site .workProcess .list .item .txt", "body.site .wrapper", "body.site a", "body.site button", "body.site footer", "body.site footer .col", "body.site footer .copyTxt", "body.site footer .logo", "body.site footer .menuFot", "body.site footer .menuFot ul", "body.site footer .menuFot ul li", "body.site footer .menuFot ul li a", "body.site footer .menuFot ul li a.active", "body.site footer .socialBl", "body.site footer .socialBl ul", "body.site footer .socialBl ul li", "body.site footer .socialBl ul li + li", "body.site footer .socialBl ul li .iconBl", "body.site footer .socialBl ul li .txt", "body.site footer .socialBl ul li a", "body.site footer .textLine", "body.site footer .tit", "body.site footer .wrapIn", "body.site h1", "body.site h2", "body.site h3", "body.site h4", "body.site h5", "body.site h6", "body.site header", "body.site input", "body.site label .imp", "body.site mar.lineClick .right", "body.site ol", "body.site p", "body.site textarea", "body.site ul", "body.site.hidden", "button", "button.close", "button.list-group-item", "button.list-group-item .list-group-item-heading", "button.list-group-item-danger", "button.list-group-item-danger .list-group-item-heading", "button.list-group-item-danger.active", "button.list-group-item-info", "button.list-group-item-info .list-group-item-heading", "button.list-group-item-info.active", "button.list-group-item-success", "button.list-group-item-success .list-group-item-heading", "button.list-group-item-success.active", "button.list-group-item-warning", "button.list-group-item-warning .list-group-item-heading", "button.list-group-item-warning.active", "button[disabled]", "canvas", "caption", "code", "dd", "details", "dfn", "dl", "dt", "fieldset", "fieldset[disabled] .btn", "fieldset[disabled] .btn-danger", "fieldset[disabled] .btn-danger.focus", "fieldset[disabled] .btn-default", "fieldset[disabled] .btn-default.focus", "fieldset[disabled] .btn-info", "fieldset[disabled] .btn-info.focus", "fieldset[disabled] .btn-link", "fieldset[disabled] .btn-primary", "fieldset[disabled] .btn-primary.focus", "fieldset[disabled] .btn-success", "fieldset[disabled] .btn-success.focus", "fieldset[disabled] .btn-warning", "fieldset[disabled] .btn-warning.focus", "fieldset[disabled] .checkbox label", "fieldset[disabled] .checkbox-inline", "fieldset[disabled] .form-control", "fieldset[disabled] .navbar-default .btn-link", "fieldset[disabled] .navbar-inverse .btn-link", "fieldset[disabled] .radio label", "fieldset[disabled] .radio-inline", "fieldset[disabled] a.btn", "fieldset[disabled] input[type=\"checkbox\"]", "fieldset[disabled] input[type=\"radio\"]", "figcaption", "figure", "footer", "h1", "h1 .small", "h1 small", "h2", "h2 .small", "h2 small", "h3", "h3 .small", "h3 small", "h4", "h4 .small", "h4 small", "h5", "h5 .small", "h5 small", "h6", "h6 .small", "h6 small", "header", "hgroup", "hr", "html", "html input[disabled]", "html input[type=\"button\"]", "img", "input", "input[type=\"button\"].btn-block", "input[type=\"checkbox\"]", "input[type=\"checkbox\"].disabled", "input[type=\"checkbox\"][disabled]", "input[type=\"date\"].form-control", "input[type=\"date\"].input-lg", "input[type=\"date\"].input-sm", "input[type=\"datetime-local\"].form-control", "input[type=\"datetime-local\"].input-lg", "input[type=\"datetime-local\"].input-sm", "input[type=\"file\"]", "input[type=\"month\"].form-control", "input[type=\"month\"].input-lg", "input[type=\"month\"].input-sm", "input[type=\"number\"]", "input[type=\"radio\"]", "input[type=\"radio\"].disabled", "input[type=\"radio\"][disabled]", "input[type=\"range\"]", "input[type=\"reset\"]", "input[type=\"reset\"].btn-block", "input[type=\"search\"]", "input[type=\"submit\"]", "input[type=\"submit\"].btn-block", "input[type=\"time\"].form-control", "input[type=\"time\"].input-lg", "input[type=\"time\"].input-sm", "kbd", "kbd kbd", "label", "legend", "main", "mark", "menu", "nav", "ol", "ol ol", "ol ul", "optgroup", "output", "p", "pre", "pre code", "progress", "samp", "section", "select", "select.input-group-lg > .form-control", "select.input-group-lg > .input-group-addon", "select.input-group-lg > .input-group-btn > .btn", "select.input-group-sm > .form-control", "select.input-group-sm > .input-group-addon", "select.input-group-sm > .input-group-btn > .btn", "select.input-lg", "select.input-sm", "select[multiple]", "select[multiple].input-group-lg > .form-control", "select[multiple].input-group-lg > .input-group-addon", "select[multiple].input-group-lg > .input-group-btn > .btn", "select[multiple].input-group-sm > .form-control", "select[multiple].input-group-sm > .input-group-addon", "select[multiple].input-group-sm > .input-group-btn > .btn", "select[multiple].input-lg", "select[multiple].input-sm", "select[size]", "small", "strong", "sub", "summary", "sup", "table", "table col[class*=\"col-\"]", "table td[class*=\"col-\"]", "table th[class*=\"col-\"]", "table.visible-lg", "table.visible-md", "table.visible-sm", "table.visible-xs", "tbody.collapse.in", "td", "td.visible-lg", "td.visible-md", "td.visible-sm", "td.visible-xs", "template", "textarea", "textarea.form-control", "textarea.input-group-lg > .form-control", "textarea.input-group-lg > .input-group-addon", "textarea.input-group-lg > .input-group-btn > .btn", "textarea.input-group-sm > .form-control", "textarea.input-group-sm > .input-group-addon", "textarea.input-group-sm > .input-group-btn > .btn", "textarea.input-lg", "textarea.input-sm", "th", "th.visible-lg", "th.visible-md", "th.visible-sm", "th.visible-xs", "tr.collapse.in", "tr.visible-lg", "tr.visible-md", "tr.visible-sm", "tr.visible-xs", "ul", "ul ol", "ul ul", "video"];
    pagespeed.criticalCssBeaconInit('/ngx_pagespeed_beacon', 'https://hourceo.com/?a=deposit', 'C6YhyxH8vd', 'RI4Ow64vACg', pagespeed.selectors);

<?php echo '</script'; ?>
><noscript class="psa_add_styles">
    <link rel="stylesheet" type="text/css" href="fonts/icomoon/style.css" />
    <link rel="stylesheet" type="text/css" href="css/selectric.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <style>
        body.site .listCur .item {
            background-color: #223e31;
            border: dashed 1px #223e31
        }

        body.site .textGretting {
            padding: 40px 0 0;
            text-align: right;
            width: 100%
        }

        body.site .textGretting p {
            margin-top: 10px
        }

        body.lk .cabNav li+li {
            margin-top: 10px
        }

        .hvr-shrink {
            display: inline-block;
            vertical-align: middle;
            -webkit-transform: perspective(1px) translateZ(0);
            transform: perspective(1px) translateZ(0);
            box-shadow: 0 0 1px rgba(0, 0, 0, 0);
            -webkit-transition-duration: .3s;
            transition-duration: .3s;
            -webkit-transition-property: transform;
            transition-property: transform;
            float: left
        }

        .menu22 {
            background-color: rgba(0, 0, 0, .45);
            -webkit-border-radius: 50px;
            -moz-border-radius: 50px;
            -ms-border-radius: 50px;
            border-radius: 50px;
            width: 100%;
            max-width: 808px;
            position: relative;
            left: 5px
        }

        .menu22 li a {
            font-size: 15px;
            font-weight: bold;
            color: #fff
        }

        .menu22 li a:hover {
            font-size: 15px;
            font-weight: bold;
            color: #fff;
            background-color: rgba(0, 0, 0, .33)
        }

        body.site .btn.btnGrLigh {
            color: #001811;
            background-color: #a2ea07;
            font-weight: bold;
            box-shadow: 0 2px 0 0 #fff, inset 0 0 2px rgba(255, 255, 255, .6)
        }

        body.site .btn.btnGrLigh:hover {
            color: #001811;
            background-color: #a2ea07;
            font-weight: bold;
            box-shadow: 0 2px 0 0 #013220, inset 0 0 2px rgba(255, 255, 255, .6)
        }

    </style>
    <style>
        .textinfo {
            display: inline-block;
            background: #439a25;
            background: #b800d9;
            background: #6dd214;
            font-size: 20px;
            font-weight: bold;
            position: relative;
            border-radius: 2px;
            width: 100%;
            padding: 5px 8px;
            text-align: center;
            margin-top: 10px;
            margin-bottom: 10px
        }

    </style>
    <style>
        .textinfo {
            display: inline-block;
            background: #439a25;
            background: #b800d9;
            background: #6dd214;
            font-size: 20px;
            font-weight: bold;
            position: relative;
            border-radius: 2px;
            width: 100%;
            padding: 5px 8px;
            text-align: center;
            margin-top: 10px;
            margin-bottom: 10px
        }

    </style>
    <style>
        .chart_box {
            width: 100%;
            overflow: hidden;
            text-align: center
        }

        .chart_box ul {
            display: inline-block;
            font-size: 0;
            vertical-align: middle;
            height: 40px
        }

        .chart_box ul li {
            display: inline-block
        }

        .accbotton a i {
            font-family: "Inter";
            font-style: normal
        }

        .accbotton a {
            display: inline-block;
            font-size: 16px;
            font-weight: bold;
            padding: 25px;
            color: #fff;
            background: rgba(0, 0, 0, .1);
            border-radius: 2px;
            transition: .4s ease;
            background: #6dd214;
            padding: 10px 20px;
            box-shadow: 0 2px 0 0 #013220, inset 0 0 2px rgba(255, 255, 255, .6);
            position: relative;
            z-index: 2;
            margin-left: 10px
        }

        .accbotton a:hover {
            display: inline-block;
            font-size: 16px;
            font-weight: bold;
            padding: 25px;
            color: #fff;
            background: rgba(0, 0, 0, .1);
            border-radius: 2px;
            transition: .4s ease;
            background: #6dd214;
            padding: 10px 20px;
            box-shadow: 0 2px 0 0 #fff, inset 0 0 5px rgba(255, 255, 255, .6);
            position: relative;
            z-index: 2;
            margin-left: 10px
        }

    </style>
</noscript>
<?php echo '<script'; ?>
 data-pagespeed-no-defer>
    (function() {
        function b() {
            var a = window,
                c = e;
            if (a.addEventListener) a.addEventListener("load", c, !1);
            else if (a.attachEvent) a.attachEvent("onload", c);
            else {
                var d = a.onload;
                a.onload = function() {
                    c.call(this);
                    d && d.call(this)
                }
            }
        };
        var f = !1;

        function e() {
            if (!f) {
                f = !0;
                for (var a = document.getElementsByClassName("psa_add_styles"), c = 0, d; d = a[c]; ++c)
                    if ("NOSCRIPT" == d.nodeName) {
                        var k = document.createElement("div");
                        k.innerHTML = d.textContent;
                        document.body.appendChild(k)
                    }
            }
        }

        function g() {
            var a = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || null;
            a ? a(function() {
                window.setTimeout(e, 0)
            }) : b()
        }
        var h = ["pagespeed", "CriticalCssLoader", "Run"],
            l = this;
        h[0] in l || !l.execScript || l.execScript("var " + h[0]);
        for (var m; h.length && (m = h.shift());) h.length || void 0 === g ? l[m] ? l = l[m] : l = l[m] = {} : l[m] = g;
    })();
    pagespeed.CriticalCssLoader.Run();

<?php echo '</script'; ?>
>
<?php }
}
?>