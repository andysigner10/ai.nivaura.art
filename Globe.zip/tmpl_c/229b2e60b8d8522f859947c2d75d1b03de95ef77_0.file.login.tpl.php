<?php /* Smarty version 3.1.27, created on 2022-11-28 03:49:36
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1270419756638421c0286362_14484521%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '229b2e60b8d8522f859947c2d75d1b03de95ef77' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/login.tpl',
      1 => 1668056735,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1270419756638421c0286362_14484521',
  'variables' => 
  array (
    'frm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_638421c0389852_65927162',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_638421c0389852_65927162')) {
function content_638421c0389852_65927162 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1270419756638421c0286362_14484521';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>







<h2 class="cap">Sign in</h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bglogin.jpg)"></div>
</header>
<div class="content">

<div class="loginPage">
<div class="container">
<div class="wrapIn">
<div class="left">
<div class="nameLog">
<span class="iconBl icon-lock"></span>
<span class="desr">login</span>
<h2 class="cap">Sign in</h2>
<span class="capVisible">Sign in</span>
</div>




<?php echo '<script'; ?>
 language=javascript>
function checkform() {
  if (document.mainform.username.value=='') {
    alert("Please type your username!");
    document.mainform.username.focus();
    return false;
  }
  if (document.mainform.password.value=='') {
    alert("Please type your password!");
    document.mainform.password.focus();
    return false;
  }
  return true;
}
<?php echo '</script'; ?>
>


<?php if ($_smarty_tpl->tpl_vars['frm']->value['say'] == 'invalid_login') {?>
<h3>Login error:</h3><br><br>

Your login or password or turing image code is wrong. Please check this information.
<?php }?>
<h3>Login:</h3>
<br>
<form method=post name=mainform onsubmit="return checkform()">
<input type=hidden name=a value='do_login'>
<input type=hidden name=follow value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['follow']);?>
'>
<input type=hidden name=follow_id value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['follow_id']);?>
'>

<div class="forma">
<div class="inputLine">
<label for="">LOGIN<span class="imp">*</span>:</label>
<input type=text name=username value=''>
</div>

<div class="inputLine">
<label for="">PASSWORD<span class="imp">*</span>:</label>
<input type=password name=password value=''>
</div>






<a href="?a=forgot_password" class="link">Forgot password?</a>
</div>
<button type="submit" class="btn btnGrDark">Login</button>

</form>
</div>
</div>
</div>
</div>

<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>