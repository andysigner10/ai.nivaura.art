<?php /* Smarty version 3.1.27, created on 2022-11-27 05:51:02
         compiled from "my:hightcharts" */ ?>
<?php
/*%%SmartyHeaderCode:3955616326382ecb6e3c881_98712296%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1722fe02dab74db983b6d5cf3b1add82ab5891cf' => 
    array (
      0 => 'my:hightcharts',
      1 => 1669524662,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '3955616326382ecb6e3c881_98712296',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_6382ecb6e3e0c5_60269842',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_6382ecb6e3e0c5_60269842')) {
function content_6382ecb6e3e0c5_60269842 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '3955616326382ecb6e3c881_98712296';
?>
 <?php }
}
?>