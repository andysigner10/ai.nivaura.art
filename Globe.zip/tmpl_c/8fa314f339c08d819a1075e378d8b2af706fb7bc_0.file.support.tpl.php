<?php /* Smarty version 3.1.27, created on 2022-11-24 20:46:20
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/support.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1759773804637fca0cbbaff2_54332566%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8fa314f339c08d819a1075e378d8b2af706fb7bc' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/support.tpl',
      1 => 1668026345,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1759773804637fca0cbbaff2_54332566',
  'variables' => 
  array (
    'say' => 0,
    'userinfo' => 0,
    'settings' => 0,
    'errors' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637fca0cce7d96_31844740',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637fca0cce7d96_31844740')) {
function content_637fca0cce7d96_31844740 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1759773804637fca0cbbaff2_54332566';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php if ($_smarty_tpl->tpl_vars['say']->value == 'send') {?>
Message has been successfully sent. We will back to you in next 24 hours. Thank you.<br><br>
<?php } else { ?>

<?php echo '<script'; ?>
 language=javascript>
<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] == 1) {?>

function checkform() { 
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php } else { ?>

function checkform() {
  if (document.mainform.name.value == '') {
    alert("Please type your full name!");
    document.mainform.name.focus();
    return false;
  }
  if (document.mainform.email.value == '') {
    alert("Please enter your e-mail address!");
    document.mainform.email.focus();
    return false;
  }
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php }?>
<?php echo '</script'; ?>
>










<h2 class="cap">Support</h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bgsupport.jpg)"></div>
</header>
<div class="content">
<?php echo '<script'; ?>
 language=javascript>
    function checkform(
    )
    {
    if(document
    .mainform.name.value==''
    )
    {
    alert
    ("Please type your full name!");
    document
    .mainform.name.
    focus(
    );
    return false;
    }
    if
    (document.mainform.email.value=='')
    {
    alert("Please enter your e-mail address!"
    );
    document.mainform.email.focus();return false;
    }
    if(document.mainform.message.value=='')
    {
    alert
    ("Please type your message!");
    document.mainform.message.focus(
    );
    return false;
    }
    return true;
    }
    <?php echo '</script'; ?>
>
<div class="supportPage">
<div class="container">
<div class="wrapIn">
<div class="left">
<div class="capBlock">
<span class="capVisible">contact</span>
<span class="desr">company info</span>
<h2 class="cap colorMobieWhite">Contact Information</h2>
</div>
<ul class="infoContacts">
<li>
<span class="iconBl icon-location"></span>
<span class="tit">Our Adress:</span>
<p>5b Cuerden Way, Bamber Bridge, Preston, England, PR5 6BL</p>
</li>
<li>
<span class="iconBl icon-phone"></span>
<span class="tit">Our Phone:</span>
<a href="#" class="linkPhone">+447360519150</a>
</li>
<li>
<span class="iconBl icon-email"></span>
<span class="tit">Email address:</span>
<a href="admin@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
" class="link"><span class="__cf_email__" data-cfemail="89e8ede4e0e7c9ede8e0e5f0a4e0e7eae6e4eca7e5fded">[email&#160;protected]</span></a>
</li>
</ul>
<div class="capBlock">
<span class="desr"></span>
<h2 class="cap"></h2>
</div>
<div class="socialBl">
<ul>
</div>
</div>
<div class="right">
<div class="capBlock">
<span class="capVisible">feedback</span>
<span class="desr">feedback</span>
<h2 class="cap">Support Form</h2>
</div>


<?php echo '<script'; ?>
 data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"><?php echo '</script'; ?>
><?php echo '<script'; ?>
 language=javascript>

function checkform() {
  if (document.mainform.name.value == '') {
    alert("Please type your full name!");
    document.mainform.name.focus();
    return false;
  }
  if (document.mainform.email.value == '') {
    alert("Please enter your e-mail address!");
    document.mainform.email.focus();
    return false;
  }
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php echo '</script'; ?>
>


<form method=post name=mainform onsubmit="return checkform()">
<input type=hidden name=a value=support>
<input type=hidden name=action value=send>

 <?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
  <ul style="color:red">
   <?php if ($_smarty_tpl->tpl_vars['errors']->value['turing_image'] == 1) {?>
    <li>Invalid turing image</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value['invalid_email'] == 1) {?>
    <li>Invalid email address</li>
   <?php }?>
  </ul>
 <?php }?>

<div class="formaCall">
<div class="forma">
<div class="inputLine">

 

<label for="">your name<span class="imp">*</span>:</label>
<input type="text" name="name" value="">
</div>

 


<div class="inputLine">
<label for="">your e-mail<span class="imp">*
</span>:</label>
<input type="text" name="email" value="">
</div>

<div class="inputLine">
<label for="">message<span class="imp">*</span>:</label>
<textarea name="message" placeholder="Message"></textarea>
</div>


<div class="inputLine">


</div>
</div>
<button type="submit" class="btn btnGrDark">Send Message</button>
</div>



</form>




</div>
</div>
</div>
</div>
<div class="lineClick">
<div class="container">
<div class="wrapIn">
<div class="left">
<div class="nameLog">
<span class="iconBl icon-faq"></span>
<span class="desr">I haven’t found an answer to my question</span>
<h2 class="cap">What can I do?</h2>
</div>
<a href="#" class="btn btnGrDark">Support Center</a>
</div>
<div class="right">
<span class="text">If you have found no answer to your question, contact our online<br> assistant, or our customer support at:</span>
 <a href="admin@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
" class="link"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a> -->
</div>
<span class="capVisible">support</span>
</div>
</div>
</div>


<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>





























<?php }?>


<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>