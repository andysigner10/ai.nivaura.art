<?php /* Smarty version 3.1.27, created on 2022-11-24 06:06:34
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/after_registration.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:718109522637efbda4de5f8_44569023%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '78fe0a0cf5552e9852cba1a2aab6e6f7d7fcd3f6' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/after_registration.tpl',
      1 => 1668059542,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '718109522637efbda4de5f8_44569023',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637efbda576d81_01503392',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637efbda576d81_01503392')) {
function content_637efbda576d81_01503392 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '718109522637efbda4de5f8_44569023';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h2 class="cap"></h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bglogin.jpg)"></div>
</header>
<div class="content">
<div class="workPage">
<div class="container">
<div class="wrapIn">
<div class="txtLeftBlock">
<span class="capVisible">Registration</span>
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap colorMobieWhite">Registration</h2>
<b>Registration completed:</b>
<p>
Thank you for joining our program.<br>
You are now an official member of this program. You can login to your account to start investing with us and use all the services that are available for our members.<br/>
<br/>
<b>Important:</b> Do not provide your login and password to anyone!
</p>
</div>
</div>
</div>
</div>
<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>


<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>