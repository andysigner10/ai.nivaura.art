<?php /* Smarty version 3.1.27, created on 2022-11-11 08:32:45
         compiled from "my:_emailbody_withdraw_request_user_notification" */ ?>
<?php
/*%%SmartyHeaderCode:241713267636dfa9d74c9d4_52557436%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c9dc888fe0e1392f2ec617e0f326be507e67362b' => 
    array (
      0 => 'my:_emailbody_withdraw_request_user_notification',
      1 => 1668151965,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '241713267636dfa9d74c9d4_52557436',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_636dfa9d7775d2_30464139',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_636dfa9d7775d2_30464139')) {
function content_636dfa9d7775d2_30464139 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '241713267636dfa9d74c9d4_52557436';
?>
Hello #name#,


You have requested to withdraw $#amount#.
Request IP address is #ip#.


Thank you.
#site_name#
#site_url#<?php }
}
?>