<?php /* Smarty version 3.1.27, created on 2022-11-24 06:06:37
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2110500992637efbdda42ef7_81606940%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'af23d22f8d58d47ba7ef385ef3377d9ae66ebaf8' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/login_redirect.tpl',
      1 => 1580236560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2110500992637efbdda42ef7_81606940',
  'variables' => 
  array (
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637efbde069ab3_96289931',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637efbde069ab3_96289931')) {
function content_637efbde069ab3_96289931 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '2110500992637efbdda42ef7_81606940';
?>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="0; URL=<?php echo smarty_modifier_myescape(encurl("?a=account"));?>
">
</head>
<body>
<center>
Hello <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
. You are redirecting to your 
<a href=?a=account>account</a> now.
<body>
</html><?php }
}
?>