<?php /* Smarty version 3.1.27, created on 2022-11-12 15:24:58
         compiled from "my:_emailbody_deposit_approved_admin_notification" */ ?>
<?php
/*%%SmartyHeaderCode:1756096397636facba874761_17844938%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd1ed2d2c1577131930b0b627d45dbe7dd0fece21' => 
    array (
      0 => 'my:_emailbody_deposit_approved_admin_notification',
      1 => 1668263098,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '1756096397636facba874761_17844938',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_636facba876e96_06990241',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_636facba876e96_06990241')) {
function content_636facba876e96_06990241 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1756096397636facba874761_17844938';
?>
Deposit has been approved:

User: #username# (#name#)
Amount: $#amount# of #currency#
Plan: #plan#
Date: #deposit_date#
#fields#<?php }
}
?>