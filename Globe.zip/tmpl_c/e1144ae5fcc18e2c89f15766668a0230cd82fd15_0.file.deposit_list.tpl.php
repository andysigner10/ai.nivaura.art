<?php /* Smarty version 3.1.27, created on 2022-11-14 20:21:17
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/deposit_list.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:7388069356372952d9a1154_61788501%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e1144ae5fcc18e2c89f15766668a0230cd82fd15' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/deposit_list.tpl',
      1 => 1668123436,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7388069356372952d9a1154_61788501',
  'variables' => 
  array (
    'currency_sign' => 0,
    'total' => 0,
    'plans' => 0,
    'p' => 0,
    'o' => 0,
    'd' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_6372952daa06d8_97872590',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_6372952daa06d8_97872590')) {
function content_6372952daa06d8_97872590 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '7388069356372952d9a1154_61788501';
echo $_smarty_tpl->getSubTemplate ("mlogo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>




<div class="cabContent">
    <style>
        * {
            margin: 0;
            padding: 0
        }

        h1,
        h2,
        p,
        ul {
            margin: 0;
            padding: 0
        }

        ul {
            list-style: none
        }

        a {
            text-decoration: none !important
        }

        body {
            width: 100%;
            padding: 0;
            margin: 0;
            font-family: 'Montserrat', sans-seriff
        }

        .table-responsive {
            -webkit-box-shadow: 0 14px 20px 0 rgba(0, 0, 0, .18);
            -moz-box-shadow: 0 14px 20px 0 rgba(0, 0, 0, .18);
            box-shadow: 0 14px 20px 0 rgba(0, 0, 0, .18);
            width: 100%;
            padding: 0;
            border: none;
            margin: 0
        }

        table {
            width: 100%
        }

        table th {
            padding: 7px 15px;
            text-align: center;
            font-size: 14px;
            color: #fff;
            text-transform: capitalize;
            white-space: nowrap;
            background: none;
            font-weight: bold;
            text-align: left;
            background: #42d00d
        }

        table tbody td {
            text-align: center;
            font-size: 13px;
            color: #fff;
            font-weight: normal;
            padding: 7px 15px;
            white-space: nowrap;
            border-bottom: 1px solid rgba(0, 0, 0, .2);
            background: rgba(0, 0, 0, .1);
            text-align: left;
            background-color: rgba(0, 0, 0, .33)
        }

        input[type="email"] {
            -webkit-box-shadow: inset 0 -1px 0 0 rgba(0, 165, 63, 1);
            -moz-box-shadow: inset 0 -1px 0 0 rgba(0, 165, 63, 1);
            box-shadow: inset 0 -1px 0 0 rgba(0, 165, 63, 1);
            width: 100%;
            height: 50px;
            padding: 0 15px;
            border-radius: 0;
            border: none;
            outline: none;
            font-size: 15px;
            color: #fff;
            background: none;
            font-family: "open Sans", sans-serif;
            border-radius: 2px;
            border: #5ab91f dashed 2px
        }

        input[type="email"]:active,
        input[type="email"]:focus {}

        textarea {
            -webkit-box-shadow: inset 0 -1px 0 0 rgba(0, 165, 63, 1);
            -moz-box-shadow: inset 0 -1px 0 0 rgba(0, 165, 63, 1);
            box-shadow: inset 0 -1px 0 0 rgba(0, 165, 63, 1);
            padding: 0 15px;
            font-size: 15px;
            color: #fff;
            background: none;
            font-family: "open Sans", sans-serif;
            width: 100%;
            min-height: 150px;
            resize: none;
            border-radius: 0;
            border: none;
            outline: none
        }

        textarea:active,
        textarea:focus {}

        .tcu {
            text-align: center;
            color: #fff;
            margin-bottom: 20px
        }

        @-webkit-keyframes AnimationName {
            0% {
                background-position: 63% 0%
            }

            50% {
                background-position: 38% 100%
            }

            100% {
                background-position: 63% 0%
            }
        }

        @-moz-keyframes AnimationName {
            0% {
                background-position: 63% 0%
            }

            50% {
                background-position: 38% 100%
            }

            100% {
                background-position: 63% 0%
            }
        }

        @keyframes AnimationName {
            0% {
                background-position: 63% 0%
            }

            50% {
                background-position: 38% 100%
            }

            100% {
                background-position: 63% 0%
            }
        }

        li:empty {
            display: none !important
        }
    </style>
    <div class="row">
        <div class="col-sm-12">
            <div class="tcu">
                <h2>Total: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['total']->value);?>
</h2>
            </div>
        </div>
    </div>
  






<?php
$_from = $_smarty_tpl->tpl_vars['plans']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['p'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['p']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->_loop = true;
$foreach_p_Sav = $_smarty_tpl->tpl_vars['p'];
?>
<table cellspacing=1 cellpadding=2 border=0 width=100% class=line><tr><td class=item>
<table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?>
<tr>
 <td colspan=3 align=center><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['name']);?>
</b></td>
</tr><tr>
 <td class=inheader>Plan</td>
 <td class=inheader width=200>Deposit Amount</td>
 <td class=inheader width=100 nowrap><nobr><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['period']);?>
 Profit (%)</nobr></td>
</tr>
<?php
$_from = $_smarty_tpl->tpl_vars['p']->value['plans'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['o'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['o']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['o']->value) {
$_smarty_tpl->tpl_vars['o']->_loop = true;
$foreach_o_Sav = $_smarty_tpl->tpl_vars['o'];
?>
<tr>
 <td class=item><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['o']->value['name']);?>
</td>
 <td class=item align=right><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['o']->value['min_deposit']);?>
 <?php if ($_smarty_tpl->tpl_vars['o']->value['max_deposit'] > 0) {?>- <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['o']->value['max_deposit']);
} else { ?>and more<?php }?></td>
 <td class=item align=right><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['o']->value['percent']);?>
</td>
</tr>
<?php
$_smarty_tpl->tpl_vars['o'] = $foreach_o_Sav;
}
?>
</table>
<br>
<table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?>
<?php if (!$_smarty_tpl->tpl_vars['p']->value['deposits']) {?>
<tr>
 <td colspan=4><b>No deposits for this plan</b></td>
</tr>           
<?php } else { ?>
<tr>
 <td colspan=4 class=inheader style="text-align:left">Your deposits:</td>
</tr>
<tr>
 <td class=inheader>Date</td>
 <td class=inheader>Amount</td>
<?php if ($_smarty_tpl->tpl_vars['p']->value['use_compound']) {?>
 <td class=inheader>Compounding Percent</td>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['p']->value['withdraw_principal']) {?>
 <td class=inheader>Release</td>
<?php }?>
</tr>           
<?php
$_from = $_smarty_tpl->tpl_vars['p']->value['deposits'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['d'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['d']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['d']->value) {
$_smarty_tpl->tpl_vars['d']->_loop = true;
$foreach_d_Sav = $_smarty_tpl->tpl_vars['d'];
?>
<tr>
 <td align=center class=item><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['date']);?>
</b><br><?php if ($_smarty_tpl->tpl_vars['p']->value['q_days'] == 0) {?>Working <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['duration']);?>
 days<?php } else { ?>Expire in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['expire_in']);
}?></td>
 <td align=center class=item><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['deposit']);?>
 <img src="images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['ec']);?>
.gif" align=absmiddle hspace=1 height=17></b></td>
<?php if ($_smarty_tpl->tpl_vars['p']->value['use_compound']) {?>
 <td align=center class=item align=center><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['compound']);?>
% <a href="<?php echo smarty_modifier_myescape(encurl("?a=change_compound&deposit=".((string)$_smarty_tpl->tpl_vars['d']->value['id'])));?>
">[change]</a></td>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['p']->value['withdraw_principal']) {?>
 <td align=center class=item>
  <?php if ($_smarty_tpl->tpl_vars['d']->value['can_withdraw']) {?>
   <a href="<?php echo smarty_modifier_myescape(encurl("?a=withdraw_principal&deposit=".((string)$_smarty_tpl->tpl_vars['d']->value['id'])));?>
">[release]</a>
  <?php } else { ?>
   <?php if ($_smarty_tpl->tpl_vars['d']->value['pending_duration'] > 0) {?>
    <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['d']->value['pending_duration']);?>
 day<?php if ($_smarty_tpl->tpl_vars['d']->value['pending_duration'] > 1) {?>s<?php }?> left
   <?php } else { ?>
    not available
   <?php }?>
  <?php }?>
 </td>
<?php }?>
</tr>
<?php
$_smarty_tpl->tpl_vars['d'] = $foreach_d_Sav;
}
?>
<?php }?>
</table>
<?php if ($_smarty_tpl->tpl_vars['p']->value['total_deposit'] > 0 || $_smarty_tpl->tpl_vars['p']->value['today_profit'] > 0 || $_smarty_tpl->tpl_vars['p']->value['total_profit'] > 0) {?>
<table cellspacing=0 cellpadding=1 border=0>
<tr><td>Deposited Total:</td><td><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['total_deposit']);?>
</b></td></tr>
<tr><td>Profit Today:</td><td><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['today_profit']);?>
</b></td></tr>
<tr><td>Total Profit:</td><td><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['total_profit']);?>
</b></td></tr>
</table>
<?php }?>
<br>
</td></tr></table>
<br>
<?php
$_smarty_tpl->tpl_vars['p'] = $foreach_p_Sav;
}
?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>