<?php /* Smarty version 3.1.27, created on 2022-11-27 05:51:28
         compiled from "my:admin_footer" */ ?>
<?php
/*%%SmartyHeaderCode:15319351266382ecd090d7b9_59984444%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c2b20d3aaeacf873df3ad2515e6faace0f837811' => 
    array (
      0 => 'my:admin_footer',
      1 => 1669524688,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '15319351266382ecd090d7b9_59984444',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_6382ecd090fec4_86678794',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_6382ecd090fec4_86678794')) {
function content_6382ecd090fec4_86678794 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '15319351266382ecd090d7b9_59984444';
?>
 </td> </tr> </table> <!-- Main: END --> 
 </td> </tr> </table> </td> </tr> </table> </td> </tr> <tr> <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">Powered with HYIP Manager. <a href=http://www.goldcoders.com class="forCopyright">GoldCoders.com</a></div></td> 
 </tr> </table> </center></body> </html> <?php }
}
?>