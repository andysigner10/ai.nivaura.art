<?php /* Smarty version 3.1.27, created on 2022-11-28 03:49:41
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/custom/about.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1745078984638421c5d0cd23_01045730%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b4f1466efc6033a3b1297878740a3239b81305c8' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/custom/about.tpl',
      1 => 1668022222,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1745078984638421c5d0cd23_01045730',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_638421c5e9d206_33011835',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_638421c5e9d206_33011835')) {
function content_638421c5e9d206_33011835 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1745078984638421c5d0cd23_01045730';
?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
/?a=about by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Nov 2022 14:04:10 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta name="google-site-verification" content="hdcisEqqvZvUmTNKqyZVTLEyjVegHAkQ4CUJLfqu3RU" />
    <meta charset="utf-8">
    <title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>
<meta name="viewport" content="width=1200">
    <meta name="format-detection" content="telephone=no">
    <meta name="author" content="UNIQUE HYIP DESIGN" href="https://uniquehyips.com/">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <style>
        @font-face {
            font-family: 'icomoon';
            src: url(fonts/icomoon/fonts/icomoonda4d.eot?rjkpmv);
            src: url(fonts/icomoon/fonts/icomoonda4d.eot?rjkpmv#iefix) format('embedded-opentype'), url(fonts/icomoon/fonts/icomoonda4d.ttf?rjkpmv) format('truetype'), url(fonts/icomoon/fonts/icomoonda4d.woff?rjkpmv) format('woff'), url(fonts/icomoon/fonts/icomoonda4d.svg?rjkpmv#icomoon) format('svg');
            font-weight: normal;
            font-style: normal;
            font-display: block
        }

        [class*=" icon-"] {
            font-family: 'icomoon' !important;
            speak: none;
            font-style: normal;
            font-weight: normal;
            font-variant: normal;
            text-transform: none;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .icon-faq:before {
            content: "\e909"
        }

    </style>
    <style>
        body.lk .cabLogo .openMenu.active span:nth-child(2) {
            opacity: 0
        }

        body.lk .accStat .accStatItem:nth-child(1) {
            top: 197px;
            left: -50px
        }

        body.lk .accStat .accStatItem:nth-child(2) {
            top: 63px;
            left: 190px
        }

        body.lk .accStat .accStatItem:nth-child(3) {
            top: -54px;
            right: 40px
        }

        body.lk .accStat .accStatItem:nth-child(4) {
            bottom: 130px;
            left: 10px
        }

        body.lk .accStat .accStatItem:nth-child(5) {
            bottom: 290px;
            right: 135px
        }

        body.lk .accStat .accStatItem:nth-child(6) {
            bottom: 177px;
            right: 51px
        }

        body.lk .planItem input:checked~.in {
            background-color: #046028;
            border: 1px solid transparent
        }

        body.lk .planItem input:checked~.in::before {
            border-top: 22px solid #046028
        }

        body.lk .refItem .head .in .tCell:nth-child(2) {
            padding-right: 25px;
            text-align: center
        }

        body.site *,
        body.site :before,
        body.site :after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        body.site {
            margin: 0 auto;
            max-width: 1920px;
            min-width: 320px;
            font-family: "Inter";
            background-color: #fff
        }

        body.site ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: left
        }

        body.site p,
        body.site h2 {
            margin: 0;
            padding: 0
        }

        body.site a {
            text-decoration: none;
            -webkit-transition: all .3s;
            -moz-transition: all .3s;
            -o-transition: all .3s;
            transition: all .3s;
            outline: none
        }

        body.site :after,
        body.site :before {
            -webkit-transition: all .3s;
            -moz-transition: all .3s;
            -o-transition: all .3s;
            transition: all .3s
        }

        body.site textarea {
            outline: none;
            font-family: "Inter"
        }

        body.site .invisLink {
            position: relative;
            -webkit-transition: opacity .3s;
            -moz-transition: opacity .3s;
            -o-transition: opacity .3s;
            transition: opacity .3s
        }

        body.site .invisLink>a {
            display: block;
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            z-index: 7;
            overflow: hidden;
            text-indent: 200%;
            white-space: nowrap
        }

        body.site .container {
            width: 1400px;
            margin: 0 auto;
            position: relative
        }

        body.site .wrapper {
            position: relative;
            min-height: 100vh;
            overflow: hidden
        }

        body.site header {
            position: relative;
            z-index: 2
        }

        body.site .lineTop {
            padding: 71px 0 37px;
            position: relative;
            z-index: 2
        }

        body.site .lineTop .wrapIn {
            display: flex;
            align-items: center;
            justify-content: space-between
        }

        body.site .logo {
            cursor: pointer
        }

        body.site .logo:hover {
            opacity: .5
        }

        body.site .linkLog {
            width: 194px;
            position: relative;
            right: -5px
        }

        body.site .linkLog .btn {
            padding: 12px 10px 12px 10px;
            display: inline-block
        }

        body.site .btn {
            font-size: 18px;
            -webkit-border-radius: 2px;
            -moz-border-radius: 2px;
            -ms-border-radius: 2px;
            border-radius: 2px;
            text-align: center;
            -webkit-box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            -moz-box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            position: relative
        }

        body.site .linkLog .btn {
            font-size: 16px
        }

        body.site .btn.btnGrLigh {
            color: #001811;
            background-color: #a2ea07;
            font-weight: bold
        }

        body.site .btn.btnGrLigh:hover {
            background-color: #004f2f;
            color: #c0ff00
        }

        body.site .lineTopInfo .wrapIn {
            display: flex;
            align-items: center;
            justify-content: flex-end
        }

        body.site .lineTopInfo .clockBl {
            display: flex;
            align-items: center;
            width: 270px
        }

        body.site .lineTopInfo .clockBl #time {
            font-size: 33px;
            color: #fff;
            font-weight: 600;
            width: 169px
        }

        body.site .lineTopInfo .clockBl #date {
            color: #fff;
            font-size: 13px
        }

        body.site .lineTopInfo .langBl:hover ul {
            display: block
        }

        body.site .lineTopInfo .langBl {
            display: flex;
            align-items: center;
            position: relative;
            width: 100px
        }

        body.site .lineTopInfo .langBl:hover:before {
            -webkit-transform: rotate(180deg);
            -moz-transform: rotate(180deg);
            -o-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        body.site .lineTopInfo .langBl:before {
            content: "";
            position: absolute;
            right: 2px;
            top: 50%;
            background-image: url(img/arrow_white.png);
            width: 12px;
            height: 7px;
            margin-top: -3px
        }

        body.site .lineTopInfo .langBl .pic {
            width: 36px;
            height: 36px;
            background-position: center;
            background-repeat: no-repeat
        }

        body.site .lineTopInfo .langBl .lang {
            color: #fff;
            font-size: 17px;
            padding-left: 11px;
            width: 42px;
            white-space: nowrap
        }

        body.site .lineTopInfo .langBl ul {
            position: absolute;
            left: 0;
            top: 100%;
            width: 100%;
            padding: 0;
            -webkit-border-radius: 15px;
            -moz-border-radius: 15px;
            -ms-border-radius: 15px;
            border-radius: 15px;
            display: none;
            background-color: rgba(255, 255, 255, .21);
            text-align: center;
            z-index: 5
        }

        body.site .lineTopInfo .langBl ul:hover {
            display: block
        }

        body.site .lineTopInfo .langBl ul li a {
            display: block;
            padding: 5px 14px;
            font-size: 15px;
            color: #fff
        }

        body.site .lineTopInfo .langBl ul li a:hover {
            color: #a2ea07
        }

        body.site .listCur {
            position: absolute;
            left: 240px;
            top: 7px;
            z-index: 2
        }

        body.site .listCur .item {
            border: solid 1px #011a14;
            -webkit-border-radius: 50px;
            -moz-border-radius: 50px;
            -ms-border-radius: 50px;
            border-radius: 50px;
            width: 210px;
            padding: 5px 18px;
            flex-wrap: wrap;
            position: relative;
            padding-left: 64px
        }

        body.site .listCur .item+.item {
            margin-top: 20px;
            margin-left: 98px
        }

        body.site .listCur .item:nth-child(2) {
            margin-left: 98px
        }

        body.site .listCur .item:nth-child(3) {
            margin-left: 189px
        }

        body.site .listCur .item .iconCircle {
            width: 45px;
            height: 45px;
            position: absolute;
            left: 5px;
            top: 50%;
            margin-top: -22px
        }

        body.site .listCur .item .val {
            color: #a2ea07;
            font-size: 20px;
            display: block;
            font-weight: 700
        }

        body.site .listCur .item .valPr {
            color: #fff;
            font-size: 13px;
            font-family: "Inter BETA"
        }

        body.site .iconCircle {
            width: 46px;
            height: 46px;
            background-color: #264b41;
            background-position: center;
            background-repeat: no-repeat;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            border-radius: 50%
        }

        body.site .calcBlock .forma .inputLine:nth-child(1) {
            width: 309px
        }

        body.site .calcBlock .forma .inputLine:nth-child(2) {
            width: 181px
        }

        body.site .whyBl .left .item:nth-child(2n) {
            top: -40px
        }

        body.site .statMiniBl ul li:nth-child(1) {
            left: 45px;
            top: 292px
        }

        body.site .statMiniBl ul li:nth-child(2) {
            left: 203px;
            top: 444px
        }

        body.site .statMiniBl ul li:nth-child(3) {
            left: 282px;
            top: 213px
        }

        body.site .statMiniBl ul li:nth-child(4) {
            left: 525px;
            top: 100px
        }

        body.site .statMiniBl ul li:nth-child(5) {
            left: 525px;
            top: 350px
        }

        body.site .listLevelBl .item:nth-child(1) {
            top: -220px
        }

        body.site .listLevelBl .item:nth-child(2) {
            top: -115px
        }

        body.site .listLevelBl .item:nth-child(1)::before {
            left: -540px;
            top: 195px;
            width: 750px
        }

        body.site .listLevelBl .item:nth-child(2)::before {
            left: -404px;
            top: 135px;
            width: 592px
        }

        body.site .listLevelBl .item:nth-child(3)::before {
            width: 492px;
            left: -320px;
            top: 101px
        }

        body.site .listLevelBl .item:nth-child(1) .pr {
            left: -202px;
            top: 83px
        }

        body.site .listLevelBl .item:nth-child(2) .pr {
            left: -200px;
            top: 88px
        }

        body.site .operBlock {
            position: relative;
            z-index: 2
        }

        body.site .operBlock .wrapIn {
            display: flex;
            flex-wrap: wrap
        }

        body.site .plLineBlock {
            width: 100%;
            margin-top: 73px
        }

        body.site .plLineBlock ul {
            display: flex
        }

        body.site .plLineBlock ul li {
            width: 160px;
            height: 60px;
            background-position: center;
            background-repeat: no-repeat
        }

        body.site .plLineBlock ul li+li {
            margin-left: 16px
        }

        body.site footer {
            background-image: url(img/bgfooter.png);
            background-position: 0 0;
            background-repeat: no-repeat;
            padding: 220px 0 45px;
            margin-top: -7px;
            position: relative;
            z-index: 2
        }

        body.site footer .wrapIn {
            display: flex;
            flex-wrap: wrap
        }

        body.site footer .copyTxt {
            color: #fff;
            font-size: 13px;
            margin-top: 61px;
            line-height: 22px
        }

        body.site footer .menuFot {
            width: 463px;
            margin-left: 165px;
            position: relative;
            top: 7px
        }

        body.site footer .menuFot ul {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between
        }

        body.site footer .menuFot ul li {
            width: 50%;
            margin-bottom: 20px;
            position: relative
        }

        body.site footer .menuFot ul li a:before {
            content: "";
            position: absolute;
            left: -15px;
            top: 50%;
            background-color: #003c2c;
            width: 7px;
            height: 7px;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            border-radius: 50%;
            margin-top: -3px
        }

        body.site footer .menuFot ul li a {
            color: #fff;
            font-size: 17px;
            position: relative
        }

        body.site footer .menuFot ul li a:hover {
            color: #c0ff00
        }

        body.site footer .menuFot ul li a.active {
            color: #c0ff00
        }

        body.site footer .menuFot ul li a.active:before {
            background-color: #c0ff00
        }

        body.site .partBl {
            width: 397px;
            position: relative;
            left: -42px;
            top: 50px
        }

        body.site .partBl ul {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between
        }

        body.site .partBl ul li {
            width: 120px;
            height: 50px;
            background-position: center;
            background-repeat: no-repeat;
            margin-bottom: 10px
        }

        body.site .grettingsPage {
            position: relative;
            z-index: 2;
            padding: 113px 0
        }

        body.site .grettingsPage .cap {
            font-size: 70px;
            font-weight: 600;
            display: block;
            text-align: right;
            color: #fff;
            position: relative;
            right: -7px
        }

        body.site .backPic {
            background-repeat: no-repeat;
            position: absolute;
            left: 50%;
            top: 0;
            width: 1920px;
            height: 2586px;
            z-index: -1;
            margin-left: -960px
        }

        body.site .grettingsPage .listCur {
            top: -146px
        }

        body.site .faqPage {
            background-color: #f4f6f5;
            position: relative;
            padding-bottom: 350px;
            margin-bottom: -350px
        }

        body.site .faqPage .wrapIn {
            position: relative;
            z-index: 2
        }

        body.site .capBlock .desr {
            color: #63ba00;
            font-size: 15px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2.5px
        }

        body.site .capBlock .capVisible {
            font-size: 170px;
            font-weight: 700;
            color: #001b14;
            opacity: .05;
            position: absolute;
            right: -268px;
            top: 148px;
            z-index: -1;
            white-space: nowrap;
            min-width: 717px;
            text-align: left
        }

        body.site .capBlock .cap {
            font-size: 40px;
            color: #003c2c;
            font-weight: 400;
            display: block;
            margin-top: 6px
        }

        body.site .faqList {
            margin-top: 72px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between
        }

        body.site .faqList .faqBlock:nth-child(2) {
            margin-top: 198px
        }

        body.site .faqBlock {
            width: calc(50% - 45px)
        }

        body.site .faqBlock .title {
            position: relative;
            padding-left: 54px
        }

        body.site .faqBlock .title+* {
            margin-top: 61px
        }

        body.site .faqBlock .title .num {
            font-size: 133px;
            font-weight: 800;
            color: #ffff;
            position: absolute;
            left: -7px;
            top: -66px;
            z-index: -1;
            text-shadow: 11px 11px 21px rgba(0, 0, 0, .11);
            opacity: .5
        }

        body.site .faqBlock .title .tit {
            color: #63ba00;
            font-size: 25px;
            text-transform: uppercase;
            font-weight: 700;
            letter-spacing: .5px
        }

        body.site .faqBlock .lineQuest+.lineQuest {
            margin-top: 17px
        }

        body.site .faqBlock .lineQuest .iconBl {
            position: absolute;
            left: 10px;
            color: #5db303;
            font-size: 35px;
            top: 50%;
            margin-top: -17px
        }

        body.site .faqBlock .lineQuest .quest.open {
            background-color: #00412c;
            color: #fff
        }

        body.site .faqBlock .lineQuest .quest {
            color: #003c2c;
            font-size: 16px;
            font-weight: 800;
            display: block;
            position: relative;
            background-color: #fff;
            -webkit-box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            -moz-box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            cursor: pointer;
            -webkit-border-radius: 50px;
            -moz-border-radius: 50px;
            -ms-border-radius: 50px;
            border-radius: 50px;
            padding: 15px 0 17px 58px;
            letter-spacing: -.2px;
            display: block
        }

        body.site .faqBlock .lineQuest .answer {
            padding: 22px 15px 8px 57px;
            display: none;
            line-height: 27px
        }

        body.site .content {
            position: relative
        }

        body.site .listNews .item:nth-child(2n) {
            margin-top: 150px;
            margin-bottom: -150px
        }

        body.site .formaCall .inputLine:nth-child(3) {
            width: 100%;
            margin-top: 11px
        }

        body.site .partAboutBl .list .item:nth-child(2n) {}

        body.site .affilateWork .listLevelBl .item:nth-child(1)::before {
            left: -609px;
            top: 224px;
            width: 824px
        }

        body.site .affilateWork .listLevelBl .item:nth-child(2)::before {
            width: 692px;
            left: -487px;
            top: 172px
        }

        body.site .menuBtn.selected span:nth-child(1) {
            -webkit-transform: rotate(45deg);
            -moz-transform: rotate(45deg);
            -o-transform: rotate(45deg);
            transform: rotate(45deg);
            top: 8px
        }

        body.site .menuBtn.selected span:nth-child(2) {
            opacity: 0
        }

        body.site .menuBtn.selected span:nth-child(3) {
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-45deg);
            top: -8px
        }

        body.site .parallax>use {
            animation: move-forever 12s linear infinite
        }

        body.site .parallax>use:nth-child(1) {
            animation-delay: 1s
        }

        body.site .parallax>use:nth-child(2) {
            animation-delay: -4s;
            animation-duration: 10s
        }

        body.site .parallax>use:nth-child(3) {
            animation-delay: -8s;
            animation-duration: 7s
        }

        @keyframes move-forever {
            0% {
                transform: translate(-90px, 0%);
            }

            100% {
                transform: translate(85px, 0%);
            }
        }

        body.site .editorial {
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: -1
        }

        body.site .footerMain {
            background-image: none
        }

        @keyframes blick {
            0% {
                -webkit-transform: scale(0.3);
                -moz-transform: scale(0.3);
                -o-transform: scale(0.3);
                transform: scale(0.3);
                opacity: 0;
            }

            20% {
                opacity: 1;
            }

            80% {
                -moz-transform: scale(0.8);
                -o-transform: scale(0.8);
                transform: scale(0.8);
                opacity: 1;
            }

            100% {
                opacity: 0;
            }
        }

        @media (max-width:1890px) {
            body.lk .accStat .accStatItem:nth-child(1) {
                top: 220px;
                left: -70px
            }

            body.lk .accStat .accStatItem:nth-child(2) {
                top: 85px;
                left: 150px
            }

            body.lk .accStat .accStatItem:nth-child(3) {
                top: -45px;
                right: 45px
            }

            body.lk .accStat .accStatItem:nth-child(4) {
                bottom: 160px;
                left: -40px
            }

            body.lk .accStat .accStatItem:nth-child(5) {
                bottom: 290px;
                right: 130px
            }

            body.lk .accStat .accStatItem:nth-child(6) {
                bottom: 195px;
                right: 60px
            }
        }

        @media (max-width:767px) {
            body.lk .planItem input:checked~.in::before {
                border-top: 15px solid #046028
            }
        }

        @media (max-width:1439px) {
            body.site .container {
                width: 1200px;
                padding: 0 10px
            }

            body.site .listCur {
                left: 0
            }

            body.site footer .menuFot {
                margin-left: 65px;
                width: 410px
            }

            body.site .partBl {
                width: 295px;
                top: 0
            }

            body.site .partBl ul li {
                width: 100px;
                background-size: contain
            }

            body.site .lineTop .logo img {
                width: 150px
            }
        }

        @media (max-width:1199px) {
            body.site .container {
                width: 992px
            }

            body.site header {
                z-index: auto
            }

            body.site .lineTop {
                padding: 30px 0;
                z-index: auto
            }

            body.site .lineTop .wrapIn {
                padding-right: 75px
            }

            body.site .linkLog .btn {
                padding: 13px 0
            }

            body.site .listCur {
                display: flex;
                align-items: center;
                top: 48px
            }

            body.site .listCur .item+.item {
                margin-top: 0;
                margin-left: 15px !important
            }

            body.site .listCur .item:nth-child(2) {
                margin-left: 0
            }

            body.site .listCur .item:nth-child(3) {
                margin-left: 0
            }

            body.site .calcBlock .forma .inputLine:nth-child(1) label {
                color: #003c2c
            }

            body.site footer .wrapIn {
                justify-content: space-between
            }

            body.site footer .menuFot {
                display: none
            }

            body.site .partBl {
                left: -47px;
                margin-left: 0;
                top: 27px;
                width: 395px
            }

            body.site .grettingsPage .listCur {
                top: -78px
            }

            body.site .capBlock .capVisible {
                right: 0
            }

            body.site .faqBlock {
                width: calc(50% - 15px)
            }

            body.site .faqBlock .title .num {
                top: -73px
            }

            body.site .faqBlock .title .tit {
                font-size: 20px
            }

            body.site .faqBlock .lineQuest .quest {
                font-size: 15px
            }
        }

        @media (max-width:991px) {
            body.site .container {
                width: 768px
            }

            body.site header {
                z-index: auto
            }

            body.site .plLineBlock ul {
                flex-wrap: wrap;
                justify-content: center
            }

            body.site footer {
                background-color: #006632;
                padding: 50px 0;
                margin-top: 50px
            }

            body.site .partBl {
                width: 295px;
                left: -25px;
                top: 3px
            }

            body.site .partBl ul li {
                width: 100px
            }

            body.site .grettingsPage .cap {
                font-size: 50px;
                line-height: 60px;
                text-align: left
            }

            body.site .backPic {
                background-position: -95px 0
            }

            body.site .faqPage {
                padding: 50px 0;
                margin-bottom: 0;
                background-color: transparent;
                margin-top: 200px
            }

            body.site .faqBlock .lineQuest .answer {
                font-size: 15px;
                line-height: 20px
            }
        }

        @media (max-width:767px) {
            body.site .container {
                width: 100%
            }

            body.site .listCur {
                flex-wrap: wrap
            }

            body.site .listCur .item {
                background-color: rgba(255, 255, 255, .33);
                width: 206px
            }

            body.site .listCur .item+.item {
                margin-left: 0 !important
            }

            body.site .calcBlock .forma .inputLine:nth-child(1) {
                width: calc(50% - 20px)
            }

            body.site .calcBlock .forma .inputLine:nth-child(2) {
                width: calc(50% - 20px)
            }

            body.site .capBlock .capVisible {
                top: 20px;
                font-size: 100px;
                right: auto
            }

            body.site .faqBlock {
                width: 100%
            }
        }

        @media (max-width:639px) {
            body.site .colorMobieWhite {
                color: #fff !important
            }

            body.site .linkLog {
                width: 150px;
                top: 4px
            }

            body.site .linkLog .btn {
                font-size: 14px
            }

            body.site .lineTopInfo .wrapIn {
                flex-wrap: wrap;
                justify-content: flex-start
            }

            body.site .listCur {
                display: none
            }

            body.site .plLineBlock {
                margin-top: 30px
            }

            body.site .plLineBlock ul li {
                width: 120px;
                background-size: contain
            }

            body.site footer {
                padding: 30px 0;
                background-image: none
            }

            body.site footer .copyTxt {
                margin-top: 15px
            }

            body.site .partBl {
                width: 100%;
                left: 0;
                justify-content: center;
                margin: 15px 0
            }

            body.site .partBl ul {
                justify-content: center
            }

            body.site .partBl ul li {
                margin: 0 6px
            }

            body.site .grettingsPage {
                padding: 50px 0
            }

            body.site .grettingsPage .cap {
                font-size: 40px;
                line-height: 50px
            }

            body.site .backPic {
                background-position: -330px 0;
                top: -214px
            }

            body.site .faqPage {
                margin-top: 0;
                padding-top: 0
            }

            body.site .capBlock .cap {
                font-size: 30px;
                line-height: 40px
            }

            body.site footer .col {
                width: 100%;
                text-align: center
            }

            body.site footer .logo {
                margin: 0 auto;
                display: table
            }
        }

        @media (max-width:479px) {
            body.site .lineTop .wrapIn {
                flex-wrap: wrap
            }

            body.site .linkLog {
                top: 12px;
                right: auto;
                width: 100%
            }

            body.site .btn.btnGrLigh {
                max-width: 150px
            }

            body.site .lineTopInfo .clockBl {
                width: 100%;
                margin-bottom: 15px
            }

            body.site .calcBlock .forma .inputLine:nth-child(1) {
                width: 100%
            }

            body.site .calcBlock .forma .inputLine:nth-child(2) {
                width: 100%;
                margin-top: 16px
            }

            body.site .faqBlock .title {
                padding-left: 0
            }

            body.site .faqBlock .lineQuest .quest {
                font-size: 14px
            }

            body.site .faqBlock .lineQuest .answer {
                padding: 15px 0 0
            }

            body.site .formaCall .inputLine:nth-child(3) {
                margin-top: 15px
            }

            body.site .formaCall .inputLine:nth-child(1) {
                width: 100%
            }

            body.site .formaCall .inputLine:nth-child(2) {
                width: 100%;
                margin-top: 15px
            }
        }

    </style>
    <style>
        @font-face {
            font-family: 'Glyphicons Halflings';
            src: url(fonts/glyphicons-halflings-regular.html);
            src: url(fonts/glyphicons-halflings-regulard41d.html?#iefix) format('embedded-opentype'), url(fonts/glyphicons-halflings-regular-2.html) format('woff2'), url(fonts/glyphicons-halflings-regular-3.html) format('woff'), url(fonts/glyphicons-halflings-regular-4.html) format('truetype'), url(fonts/glyphicons-halflings-regular-5.html#glyphicons_halflingsregular) format('svg')
        }

        html {
            font-family: sans-serif;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        footer,
        header,
        section {
            display: block
        }

        audio {
            display: inline-block;
            vertical-align: baseline
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        a {
            background-color: transparent
        }

        a:active,
        a:hover {
            outline: 0
        }

        img {
            border: 0
        }

        svg:not(:root) {
            overflow: hidden
        }

        textarea {
            margin: 0;
            font: inherit;
            color: inherit
        }

        textarea {
            overflow: auto
        }

        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        :after,
        :before {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        html {
            font-size: 10px;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
        }

        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            line-height: 1.42857143;
            color: #333;
            background-color: #fff
        }

        textarea {
            font-family: inherit;
            font-size: inherit;
            line-height: inherit
        }

        a {
            color: #337ab7;
            text-decoration: none
        }

        a:focus,
        a:hover {
            color: #23527c;
            text-decoration: underline
        }

        a:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        img {
            vertical-align: middle
        }

        h2 {
            font-family: inherit;
            font-weight: 500;
            line-height: 1.1;
            color: inherit
        }

        h2 {
            margin-top: 20px;
            margin-bottom: 10px
        }

        h2 {
            font-size: 30px
        }

        p {
            margin: 0 0 10px
        }

        ul {
            margin-top: 0;
            margin-bottom: 10px
        }

        .container {
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto
        }

        @media (min-width:768px) {
            .container {
                width: 750px
            }
        }

        @media (min-width:992px) {
            .container {
                width: 970px
            }
        }

        @media (min-width:1200px) {
            .container {
                width: 1170px
            }
        }

        .table-striped>tbody>tr:nth-of-type(odd) {
            background-color: #f9f9f9
        }

        .has-feedback label~.form-control-feedback {
            top: 25px
        }

        .has-feedback label.sr-only~.form-control-feedback {
            top: 0
        }

        .btn {
            display: inline-block;
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 14px;
            font-weight: 400;
            line-height: 1.42857143;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-image: none;
            border: 1px solid transparent;
            border-radius: 4px
        }

        .btn:active:focus,
        .btn:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        .btn:focus,
        .btn:hover {
            color: #333;
            text-decoration: none
        }

        .btn:active {
            background-image: none;
            outline: 0;
            -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125)
        }

        .collapse {
            display: none
        }

        .collapse.in {
            display: block
        }

        .btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
            border-radius: 0
        }

        .btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle) {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .btn-group>.btn:last-child:not(:first-child),
        .btn-group>.dropdown-toggle:not(:first-child) {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group>.btn-group:not(:first-child):not(:last-child)>.btn {
            border-radius: 0
        }

        .btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn:not(:first-child):not(:last-child) {
            border-radius: 0
        }

        .btn-group-vertical>.btn:first-child:not(:last-child) {
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn:last-child:not(:first-child) {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
            border-bottom-right-radius: 4px;
            border-bottom-left-radius: 4px
        }

        .btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn {
            border-radius: 0
        }

        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-left-radius: 0;
            border-top-right-radius: 0
        }

        .input-group .form-control:not(:first-child):not(:last-child),
        .input-group-addon:not(:first-child):not(:last-child),
        .input-group-btn:not(:first-child):not(:last-child) {
            border-radius: 0
        }

        .input-group .form-control:first-child,
        .input-group-addon:first-child,
        .input-group-btn:first-child>.btn,
        .input-group-btn:first-child>.btn-group>.btn,
        .input-group-btn:first-child>.dropdown-toggle,
        .input-group-btn:last-child>.btn-group:not(:last-child)>.btn,
        .input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle) {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .input-group .form-control:last-child,
        .input-group-addon:last-child,
        .input-group-btn:first-child>.btn-group:not(:first-child)>.btn,
        .input-group-btn:first-child>.btn:not(:first-child),
        .input-group-btn:last-child>.btn,
        .input-group-btn:last-child>.btn-group>.btn,
        .input-group-btn:last-child>.dropdown-toggle {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .nav {
            padding-left: 0;
            margin-bottom: 0;
            list-style: none
        }

        .nav>li {
            position: relative;
            display: block
        }

        .nav>li>a {
            position: relative;
            display: block;
            padding: 10px 15px
        }

        .nav>li>a:focus,
        .nav>li>a:hover {
            text-decoration: none;
            background-color: #eee
        }

        .navbar-collapse {
            padding-right: 15px;
            padding-left: 15px;
            overflow-x: visible;
            -webkit-overflow-scrolling: touch;
            border-top: 1px solid transparent;
            -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1)
        }

        .navbar-collapse.in {
            overflow-y: auto
        }

        @media (min-width:768px) {
            .navbar-collapse {
                width: auto;
                border-top: 0;
                -webkit-box-shadow: none;
                box-shadow: none
            }

            .navbar-collapse.collapse {
                display: block !important;
                height: auto !important;
                padding-bottom: 0;
                overflow: visible !important
            }

            .navbar-collapse.in {
                overflow-y: visible
            }
        }

        .navbar-nav {
            margin: 7.5px -15px
        }

        .navbar-nav>li>a {
            padding-top: 10px;
            padding-bottom: 10px;
            line-height: 20px
        }

        @media (min-width:768px) {
            .navbar-nav {
                float: left;
                margin: 0
            }

            .navbar-nav>li {
                float: left
            }

            .navbar-nav>li>a {
                padding-top: 15px;
                padding-bottom: 15px
            }

            .navbar-right~.navbar-right {
                margin-right: 0
            }
        }

        @-webkit-keyframes progress-bar-stripes {
            from {
                background-position: 40px 0
            }

            to {
                background-position: 0 0
            }
        }

        @-o-keyframes progress-bar-stripes {
            from {
                background-position: 40px 0
            }

            to {
                background-position: 0 0
            }
        }

        @keyframes progress-bar-stripes {
            from {
                background-position: 40px 0
            }

            to {
                background-position: 0 0
            }
        }

        .container:after,
        .container:before,
        .nav:after,
        .nav:before,
        .navbar-collapse:after,
        .navbar-collapse:before {
            display: table;
            content: " "
        }

        .container:after,
        .nav:after,
        .navbar-collapse:after {
            clear: both
        }

        @-ms-viewport {
            width: device-width
        }

    </style>
    <?php echo '<script'; ?>
 type="text/javascript" src="js/jquery-3.3.1.js"><?php echo '</script'; ?>
>
    <link rel="dns-prefetch" href="http://js.users.51.la/">
</head>
<style>
    body.site .listCur .item {
        background-color: #223e31;
        border: dashed 1px #223e31
    }

    .hvr-shrink {
        display: inline-block;
        vertical-align: middle;
        -webkit-transform: perspective(1px) translateZ(0);
        transform: perspective(1px) translateZ(0);
        box-shadow: 0 0 1px rgba(0, 0, 0, 0);
        -webkit-transition-duration: .3s;
        transition-duration: .3s;
        -webkit-transition-property: transform;
        transition-property: transform;
        float: left
    }

    .menu22 {
        background-color: rgba(0, 0, 0, .45);
        -webkit-border-radius: 50px;
        -moz-border-radius: 50px;
        -ms-border-radius: 50px;
        border-radius: 50px;
        width: 100%;
        max-width: 808px;
        position: relative;
        left: 5px
    }

    .menu22 li a {
        font-size: 15px;
        font-weight: bold;
        color: #fff
    }

    .menu22 li a:hover {
        font-size: 15px;
        font-weight: bold;
        color: #fff;
        background-color: rgba(0, 0, 0, .33)
    }

    body.site .btn.btnGrLigh {
        color: #001811;
        background-color: #a2ea07;
        font-weight: bold;
        box-shadow: 0 2px 0 0 #fff, inset 0 0 2px rgba(255, 255, 255, .6)
    }

    body.site .btn.btnGrLigh:hover {
        color: #001811;
        background-color: #a2ea07;
        font-weight: bold;
        box-shadow: 0 2px 0 0 #013220, inset 0 0 2px rgba(255, 255, 255, .6)
    }

</style>



<body class='site'>
    <section class="wrapper">
        <header>
            <div class="lineTop">
                <div class="container">
                    <div class="wrapIn">
                        <div class="logo invisLink">
                            <a href="/?a=home"></a>
                            <img src="img/logo.png" alt="">
                        </div>
                        <div class="navbar-collapse bounceIn wow collapse in menu22" id="bs-example-navbar-collapse-1" aria-expanded="true">
                            <ul class="nav navbar-nav">
                                <li class="hvr-shrink"><a href="/?a=home">Home</a></li>
                                <li class="hvr-shrink"><a href="/?a=cust&amp;page=about">About us</a></li>
                                <li class="hvr-shrink"><a href="/?a=cust&amp;page=howitworks">How it works?</a></li>
                                <li class="hvr-shrink"><a href="/?a=faq" class="active">FAQ</a></li>
                                <li class="hvr-shrink"><a href="/?a=support">Support</a></li>
                            </ul>
                        </div>
                        <div class="linkLog">
                                                        <a href="indexc30b.html?a=login" class="btn btnGrLigh">Login</a>
                            <a href="indexcca3.html?a=signup" class="btn btnGrLigh">Sign Up</a>
                                                    </div>
                    </div>
                </div><br><br>
                <div style="height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:62px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px; width: 100%;"><div style="height:40px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&amp;theme=light&amp;pref_coin_id=1505&amp;invert_hover=" width="100%" height="36px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div><div style="color: #FFFFFF; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;"><a href="https://coinlib.io/" target="_blank" style="font-weight: 500; color: #FFFFFF; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by Coinlib</div></div>
            </div>
            <div class="lineTopInfo">
                <div class="container">
                    <div class="wrapIn">
                        <div class="clockBl">
                            <span id="time"></span>
                            <span id="date"></span>
                        </div>
                        <div class="langBl">
                            <div class="pic" style="background-image: url(img/gb.png);"></div>
                            <span class="lang">Eng</span>
                            <ul>
                                <li><a href="index4310.html?a=faq&amp;language=en">Eng</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grettingsPage">
                <div class="container">
                    <div class="wrapIn">
                        <div class="listCur">
                            <?php echo '<script'; ?>
 type="text/javascript">
                                jQuery.ajax({
                                    url: "https://min-api.cryptocompare.com/data/pricemulti",
                                    data: "fsyms=BTC,ETH,DASH,LTC&tsyms=USD",
                                    dataType: 'json',
                                }).done(function(data) {
                                    jQuery(".dashCoin").html('$' + data.DASH.USD);
                                    jQuery(".ethCoin").html('$' + data.ETH.USD);
                                    jQuery(".bitCoin").html('$' + data.BTC.USD);
                                    jQuery(".liteCoin").html('$' + data.LTC.USD);
                                }).fail(function() {
                                    console.log("API error");
                                });

                            <?php echo '</script'; ?>
>
                            <div class="item  wow slideInLeft">
                                <span class="iconCircle" style="background-image: url(img/pic_cur1.png);"></span>
                                <span class="bitCoin val">$20000.00</span>
                                <span class="valPr"></span>
                            </div>
                            <div class="item  wow slideInLeft">
                                <span class="iconCircle" style="background-image: url(img/pic_cur2.png);"></span>
                                <span class="ethCoin val">232.26$</span>
                                <span class="valPr"></span>
                            </div>
                            <div class="item  wow slideInLeft">
                                <span class="iconCircle" style="background-image: url(img/pic_cur3.png);"></span>
                                <span class="liteCoin val">60.93$</span>
                                <span class="valPr "></span>
                            </div>
                        </div>
<h2 class="cap">About us</h2>
</div>
</div>
</div>
<div class="backPic" style="background-image: url(img/bgabout.jpg)"></div>
</header>
<div class="content">
<div class="aboutPage">
<div class="container">
<div class="wrapIn">
<div class="left">
<div class="capBlock">
<span class="capVisible">about us</span>
<span class="desr">information about company</span>
<h2 class="cap colorMobieWhite">About The Company</h2>
</div>
<div class="textBlock">
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</b>
<p><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is a team of professional analysts and players in the cryptocurrency market, which has hundreds of instruments in its assets for profit in the financial markets, including cryptocurrency. The main distinguishing feature of our company from competitors is the presence of its own unique trading strategies on cryptocurrency exchanges such as BitFinex, Poloniex, Binance, BitMex and others. Our analysts in real time analyze more than the initial 200 parameters to make a decision on the purchase or sale of a financial asset for maximum profit.</p>
<p>The main difference between our company and competitors is the so-called hourly breakdown of trading time, that is, each new hour of trading time is a reporting one for our company and we take profit for each period of time.</p>
<p>This kind of approach to trading ensures profit in the shortest possible time.</p>
</div>
</div>
<div class="right">
<div class="lineAdress">
<div class="iconBl" style="background-image: url(img/pic_seh.jpg);"></div>
<div class="col">
<span class="tit">Company adress:</span>
<span class="adress">
5b Cuerden Way, Bamber Bridge, Preston, England, PR5 6BL</span>
</div>
<div class="col">
<span class="tit">Officially Registered:</span>
<span class="num">#12237737</span>
</div>
<style>
    .btn1{
    padding:14px 17px 17px;
    color:#c0ff00;
    background-color:#003d2c;
    font-weight:bold
}
    .btn1:hover{
    background-color:#c0ff00
}
    .cc1{
    margin-top:20px
}
</style>
<div class="col cc1">
<a href="images/certificate.png" target="_blank" class="btn1 btnGrDark">Show Certificate</a>
</div><div class="col cc1">
<a href="https://find-and-update.company-information.service.gov.uk/company/12237737" target="_blank" class="btn1 btnGrDark">United Kingdom Company </a>
</div>
</div>
<div class="textBlock">
<b>In 2019, the management of our company decided to enter the private investment market in order to maintain the short-term liquidity of our assets as part of mutually beneficial cooperation with each of our customers.</b>
<p>Within the framework of this program, our company has developed 3 balanced tariff plans, which imply hourly accrual of profit to our investors, depending on the amount of investments.</p>
<p>It is important to note that you will not need any additional knowledge and skills, all the necessary set of knowledge and tools that you may need are presented on our website. All you need to do is register your personal account, place a deposit and monitor the accrual and withdrawal of profits.</p>
</div>
</div>
</div>
</div>
</div>
<div class="choseBl">
<div class="container">
<div class="wrapIn">
<div class="left">
<div class="picture" style="background-image: url(img/pic_money1.png);"></div>
<div class="capBlock">
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap">Goals and objectives of our company</h2>
</div>
<div class="textBlock">
<b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is constantly improving its asset management methods, improving the qualifications of employees and the quality of services provided, and is constantly optimizing the activities of its departments the main objectives of the company are:</b>
<ul>
<li>
<span class="iconBl icon-check"></span>
<p>Providing a stable and high income for our investors</p>
</li>
<li>
<span class="iconBl icon-check"></span>
<p>Timely accrual of profit to each client</p>
</li>
<li>
<span class="iconBl icon-check"></span>
<p>Entering leading positions in the ranking of world trading companies</p>
</li>
<li>
<span class="iconBl icon-check"></span>
<p>Search for technological and organizational solutions for automating the trading process and better interaction between all departments of the company</p>
</li>
</ul>
<p>The main objective of our company is the continuous improvement of our business, as well as building long-term trusting relationships with our customers!</p>
</div>
</div>
<div class="right">
<div class="partAboutBl">
<div class="capBlock">
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap">Why do customers choose our company?</h2>
</div>
<div class="list">
<div class="item">
<span class="iconBl icon-clock"></span>
<span class="tit">Quick payouts</span>
<span class="txt">Our company pays all payments due to investors as soon as possible!</span>
</div>
<div class="item">
<span class="iconBl icon-wallet"></span>
<span class="tit">Deposit insurance</span>
<span class="txt">All deposits of our investors are reliably insured by our own highly specialized fund.</span>
</div>
<div class="item">
<span class="iconBl icon-headphone"></span>
<span class="tit">24 HOUR SUPPORT</span>
<span class="txt">Our highly qualified specialists are always online and ready to answer your any question at any time of the day or night.</span>
</div>
<div class="item">
<span class="iconBl icon-shield"></span>
<span class="tit">RELIABLE PROTECTION</span>
<span class="txt">We pay special attention to the safety of your data and the overall security of the site. To do this, we use the most advanced security and encryption tools.</span>
</div>
<div class="item">
<span class="iconBl icon-invest"></span>
<span class="tit">Stable profit accrual</span>
<span class="txt">All our investors can be sure that they will receive their accrual of profit on time!</span>
</div>
<div class="item">
<span class="iconBl icon-monitor"></span>
<span class="tit">Intuitive interface</span>
<span class="txt">We can proudly say that our site is accessible and understandable for everyone!</span>
</div>
</div>
<a href="#" class="btn btnGrDark">For partners</a>
</div>
</div>
<div class="line">
<div class="capBlock">
<span class="capVisible">MANAGEMENT</span>
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap">COMPANY MANAGEMENT</h2>
</div>
<div class="textBlock">
<p>Jason Rocks, the sole leader of the investment company <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
, was born in 1973 in London, in the family of a bank employee. Following the example of his father, he decided to become a financier, and in 2002 he successfully completed his studies at the economics department of Oxford University. After receiving the diploma, Jason got a job in a large trading and intermediary company, while being carried away by trading operations on the currency exchange.</p>
<p>Gradually, this experience turned into his main activity, and over the next years he went from a regular trader to the head of an analytical service at one of the country's leading trading companies.</p>
<p>Having achieved rapid professional success, Jason decided to start all over again. He successfully transferred the knowledge and experience gained on the currency exchange to an adjacent specialty, and began to study the features of conducting trade transactions on the commodity exchange.</p>
</div>
</div>
</div>
</div>
</div>
<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>