<?php /* Smarty version 3.1.27, created on 2022-11-14 19:14:45
         compiled from "my:_emailbody_bonus" */ ?>
<?php
/*%%SmartyHeaderCode:1982965029637285957a38b3_27637614%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e9facfb8e5558ba6af2671420f60cc1513da744b' => 
    array (
      0 => 'my:_emailbody_bonus',
      1 => 1668449685,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '1982965029637285957a38b3_27637614',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637285957d21c7_71408633',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637285957d21c7_71408633')) {
function content_637285957d21c7_71408633 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1982965029637285957a38b3_27637614';
?>
Hello #name#,

You received a bonus: $#amount#
You can check your statistics here:
#site_url#

Good luck.<?php }
}
?>