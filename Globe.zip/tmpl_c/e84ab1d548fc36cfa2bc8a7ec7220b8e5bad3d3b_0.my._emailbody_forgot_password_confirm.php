<?php /* Smarty version 3.1.27, created on 2022-11-10 06:09:15
         compiled from "my:_emailbody_forgot_password_confirm" */ ?>
<?php
/*%%SmartyHeaderCode:2109558158636c877bd882a5_01757375%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e84ab1d548fc36cfa2bc8a7ec7220b8e5bad3d3b' => 
    array (
      0 => 'my:_emailbody_forgot_password_confirm',
      1 => 1668056955,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '2109558158636c877bd882a5_01757375',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_636c877bdb77d8_81130028',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_636c877bdb77d8_81130028')) {
function content_636c877bdb77d8_81130028 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2109558158636c877bd882a5_01757375';
?>
Hello #name#,

Please confirm your reqest for password reset.

Copy and paste this link to your browser:
#site_url#/?a=forgot_password&action=confirm&c=#confirm_string#

Thank you.
#site_name#<?php }
}
?>