<?php /* Smarty version 3.1.27, created on 2022-11-12 15:24:58
         compiled from "my:_emailbody_deposit_approved_user_notification" */ ?>
<?php
/*%%SmartyHeaderCode:1847181922636facba5871e3_17516752%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '35983f7b6c759107d5fafdc523b2d38f02ca1ac0' => 
    array (
      0 => 'my:_emailbody_deposit_approved_user_notification',
      1 => 1668263098,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '1847181922636facba5871e3_17516752',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_636facba5b6df3_06528252',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_636facba5b6df3_06528252')) {
function content_636facba5b6df3_06528252 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1847181922636facba5871e3_17516752';
?>
Dear #name#

Your deposit has been approved:

Amount: $#amount# of #currency#
Plan: #plan#
#fields#<?php }
}
?>