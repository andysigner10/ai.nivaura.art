<?php /* Smarty version 3.1.27, created on 2022-11-24 06:06:33
         compiled from "my:_emailbody_registration" */ ?>
<?php
/*%%SmartyHeaderCode:198771568637efbd90273f9_49181192%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '349257fbad92bd38ac33c718b057c126817b92e6' => 
    array (
      0 => 'my:_emailbody_registration',
      1 => 1669266392,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '198771568637efbd90273f9_49181192',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637efbd9057249_67075134',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637efbd9057249_67075134')) {
function content_637efbd9057249_67075134 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '198771568637efbd90273f9_49181192';
?>
Hello #name#,

Thank you for registration on our site.

Your login information:

Login: #username#
Password: #password#

You can login here: #site_url#

Contact us immediately if you did not authorize this registration.

Thank you.<?php }
}
?>