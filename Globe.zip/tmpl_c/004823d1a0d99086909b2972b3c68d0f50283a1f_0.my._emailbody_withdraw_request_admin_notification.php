<?php /* Smarty version 3.1.27, created on 2022-11-11 08:32:45
         compiled from "my:_emailbody_withdraw_request_admin_notification" */ ?>
<?php
/*%%SmartyHeaderCode:324599780636dfa9da11658_34158296%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '004823d1a0d99086909b2972b3c68d0f50283a1f' => 
    array (
      0 => 'my:_emailbody_withdraw_request_admin_notification',
      1 => 1668151965,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '324599780636dfa9da11658_34158296',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_636dfa9da13912_77592092',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_636dfa9da13912_77592092')) {
function content_636dfa9da13912_77592092 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '324599780636dfa9da11658_34158296';
?>
User #username# requested to withdraw $#amount# from IP #ip#.<?php }
}
?>