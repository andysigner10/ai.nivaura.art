<?php /* Smarty version 3.1.27, created on 2022-11-14 19:15:46
         compiled from "my:editaccount_2" */ ?>
<?php
/*%%SmartyHeaderCode:1688053815637285d20cf5e7_86366960%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3343014239e3e2b8908ea06697548cf733a73735' => 
    array (
      0 => 'my:editaccount_2',
      1 => 1668449746,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '1688053815637285d20cf5e7_86366960',
  'variables' => 
  array (
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_637285d20db6f8_46185057',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_637285d20db6f8_46185057')) {
function content_637285d20db6f8_46185057 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1688053815637285d20cf5e7_86366960';
?>
 <tr> <td>E-mail address:</td> <td><input type=text name=email value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user']->value['email'], ENT_QUOTES, 'UTF-8', true);?>
" class=inpts size=30></td> </tr><?php }
}
?>