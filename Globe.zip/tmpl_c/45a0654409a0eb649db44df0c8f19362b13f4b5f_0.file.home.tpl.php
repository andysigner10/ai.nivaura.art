<?php /* Smarty version 3.1.27, created on 2022-12-06 03:10:34
         compiled from "/home2/tradec11/public_html/globecurrency-traders.com/tmpl/home.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:206942781638ea49ab20b84_50593561%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '45a0654409a0eb649db44df0c8f19362b13f4b5f' => 
    array (
      0 => '/home2/tradec11/public_html/globecurrency-traders.com/tmpl/home.tpl',
      1 => 1668500756,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '206942781638ea49ab20b84_50593561',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_638ea49b6bffa0_46156207',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_638ea49b6bffa0_46156207')) {
function content_638ea49b6bffa0_46156207 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home2/tradec11/public_html/globecurrency-traders.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '206942781638ea49ab20b84_50593561';
?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Nov 2022 14:03:59 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>
    <meta name="google-site-verification" content="jdxI5_7ClFlINu7T0J20LuW8QQMCezhzkk9Q_6LYZ-s" />
    <meta name="viewport" content="width=1200">
    <meta name="format-detection" content="telephone=no">
    <meta name="author" content="UNIQUE HYIP DESIGN" href="https://uniquehyips.com/">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    
    <style>
        @font-face {
            font-family: 'icomoon';
            src: url(fonts/icomoon/fonts/icomoonda4d.eot?rjkpmv);
            src: url(fonts/icomoon/fonts/icomoonda4d.eot?rjkpmv#iefix) format('embedded-opentype'), url(fonts/icomoon/fonts/icomoonda4d.ttf?rjkpmv) format('truetype'), url(fonts/icomoon/fonts/icomoonda4d.woff?rjkpmv) format('woff'), url(fonts/icomoon/fonts/icomoonda4d.svg?rjkpmv#icomoon) format('svg');
            font-weight: normal;
            font-style: normal;
            font-display: block
        }

        [class*=" icon-"] {
            font-family: 'icomoon' !important;
            speak: none;
            font-style: normal;
            font-weight: normal;
            font-variant: normal;
            text-transform: none;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale
        }

        .icon-user1:before {
            content: "\e901"
        }

        .icon-calendar:before {
            content: "\e903"
        }

        .icon-clock:before {
            content: "\e906"
        }

        .icon-headphone:before {
            content: "\e90a"
        }

        .icon-safebox:before {
            content: "\e912"
        }

        .icon-shield:before {
            content: "\e915"
        }

        .icon-wallet:before {
            content: "\e91a"
        }

        .icon-team:before {
            content: "\e91b"
        }
    </style>
    <style>
        body.lk .cabLogo .openMenu.active span:nth-child(2) {
            opacity: 0
        }

        body.lk .accStat .accStatItem:nth-child(1) {
            top: 197px;
            left: -50px
        }

        body.lk .accStat .accStatItem:nth-child(2) {
            top: 63px;
            left: 190px
        }

        body.lk .accStat .accStatItem:nth-child(3) {
            top: -54px;
            right: 40px
        }

        body.lk .accStat .accStatItem:nth-child(4) {
            bottom: 130px;
            left: 10px
        }

        body.lk .accStat .accStatItem:nth-child(5) {
            bottom: 290px;
            right: 135px
        }

        body.lk .accStat .accStatItem:nth-child(6) {
            bottom: 177px;
            right: 51px
        }

        body.lk .planItem input:checked~.in {
            background-color: #046028;
            border: 1px solid transparent
        }

        body.lk .planItem input:checked~.in::before {
            border-top: 22px solid #046028
        }

        body.lk .refItem .head .in .tCell:nth-child(2) {
            padding-right: 25px;
            text-align: center
        }

        body.site *,
        body.site :before,
        body.site :after {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        body.site {
            margin: 0 auto;
            max-width: 1920px;
            min-width: 320px;
            font-family: "Inter";
            background-color: #fff
        }

        body.site ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: left
        }

        body.site p,
        body.site h2 {
            margin: 0;
            padding: 0
        }

        body.site a {
            text-decoration: none;
            -webkit-transition: all .3s;
            -moz-transition: all .3s;
            -o-transition: all .3s;
            transition: all .3s;
            outline: none
        }

        body.site :after,
        body.site :before {
            -webkit-transition: all .3s;
            -moz-transition: all .3s;
            -o-transition: all .3s;
            transition: all .3s
        }

        body.site input,
        body.site textarea {
            outline: none;
            font-family: "Inter"
        }

        body.site .invisLink {
            position: relative;
            -webkit-transition: opacity .3s;
            -moz-transition: opacity .3s;
            -o-transition: opacity .3s;
            transition: opacity .3s
        }

        body.site .invisLink>a {
            display: block;
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            z-index: 7;
            overflow: hidden;
            text-indent: 200%;
            white-space: nowrap
        }

        body.site .container {
            width: 1400px;
            margin: 0 auto;
            position: relative
        }

        body.site .wrapper {
            position: relative;
            min-height: 100vh;
            overflow: hidden
        }

        body.site header {
            position: relative;
            z-index: 2
        }

        body.site .lineTop {
            padding: 71px 0 37px;
            position: relative;
            z-index: 2
        }

        body.site .lineTop .wrapIn {
            display: flex;
            align-items: center;
            justify-content: space-between
        }

        body.site .logo {
            cursor: pointer
        }

        body.site .logo:hover {
            opacity: .5
        }

        body.site .linkLog {
            width: 194px;
            position: relative;
            right: -5px
        }

        body.site .linkLog .btn {
            padding: 12px 10px 12px 10px;
            display: inline-block
        }

        body.site .btn {
            font-size: 18px;
            -webkit-border-radius: 2px;
            -moz-border-radius: 2px;
            -ms-border-radius: 2px;
            border-radius: 2px;
            text-align: center;
            -webkit-box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            -moz-box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            box-shadow: 11px 11px 11px 0 rgba(0, 0, 0, .11);
            position: relative
        }

        body.site .linkLog .btn {
            font-size: 16px
        }

        body.site .btn.btnGrLigh {
            color: #001811;
            background-color: #a2ea07;
            font-weight: bold
        }

        body.site .btn.btnGrLigh:hover {
            background-color: #004f2f;
            color: #c0ff00
        }

        body.site .btn.btnGrDark {
            color: #c0ff00;
            background-color: #003d2c
        }

        body.site .btn.btnGrDark:hover {
            color: #001811;
            background-color: #a2ea07
        }

        body.site .headerMainPage {
            z-index: auto
        }

        body.site .headerMainPage::before {
            content: "";
            position: absolute;
            left: 50%;
            top: 0;
            background-image: url(img/bgheadmain.png);
            width: 1919px;
            height: 1887px;
            z-index: 0;
            margin-left: -960px
        }

        body.site .lineTopInfo .wrapIn {
            display: flex;
            align-items: center;
            justify-content: flex-end
        }

        body.site .lineTopInfo .clockBl {
            display: flex;
            align-items: center;
            width: 270px
        }

        body.site .lineTopInfo .clockBl #time {
            font-size: 33px;
            color: #fff;
            font-weight: 600;
            width: 169px
        }

        body.site .lineTopInfo .clockBl #date {
            color: #fff;
            font-size: 13px
        }

        body.site .lineTopInfo .langBl:hover ul {
            display: block
        }

        body.site .lineTopInfo .langBl {
            display: flex;
            align-items: center;
            position: relative;
            width: 100px
        }

        body.site .lineTopInfo .langBl:hover:before {
            -webkit-transform: rotate(180deg);
            -moz-transform: rotate(180deg);
            -o-transform: rotate(180deg);
            transform: rotate(180deg)
        }

        body.site .lineTopInfo .langBl:before {
            content: "";
            position: absolute;
            right: 2px;
            top: 50%;
            background-image: url(img/arrow_white.png);
            width: 12px;
            height: 7px;
            margin-top: -3px
        }

        body.site .lineTopInfo .langBl .pic {
            width: 36px;
            height: 36px;
            background-position: center;
            background-repeat: no-repeat
        }

        body.site .lineTopInfo .langBl .lang {
            color: #fff;
            font-size: 17px;
            padding-left: 11px;
            width: 42px;
            white-space: nowrap
        }

        body.site .lineTopInfo .langBl ul {
            position: absolute;
            left: 0;
            top: 100%;
            width: 100%;
            padding: 0;
            -webkit-border-radius: 15px;
            -moz-border-radius: 15px;
            -ms-border-radius: 15px;
            border-radius: 15px;
            display: none;
            background-color: rgba(255, 255, 255, .21);
            text-align: center;
            z-index: 5
        }

        body.site .lineTopInfo .langBl ul:hover {
            display: block
        }

        body.site .lineTopInfo .langBl ul li a {
            display: block;
            padding: 5px 14px;
            font-size: 15px;
            color: #fff
        }

        body.site .lineTopInfo .langBl ul li a:hover {
            color: #a2ea07
        }

        body.site .grettingsMain {
            position: relative
        }

        body.site .grettingsMain .wrapIn {
            position: relative;
            min-height: 1057px;
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-end
        }

        body.site .textGretting {
            padding: 141px 0 0;
            text-align: right;
            width: 100%
        }

        body.site .textGretting .cap {
            color: #fff;
            font-size: 60px;
            font-weight: 600;
            display: block;
            width: 100%;
            line-height: 82px;
            position: relative;
            right: -9px
        }

        body.site .textGretting p {
            display: block;
            width: 100%;
            color: #fff;
            font-size: 20px;
            font-family: "Inter BETA";
            font-weight: 300;
            margin-top: 37px;
            position: relative;
            right: -4px;
            line-height: 31px
        }

        body.site .textGretting .btn {
            margin-top: 46px;
            display: inline-block;
            padding: 15px 40px;
            right: -5px
        }

        body.site .listCur {
            position: absolute;
            left: 240px;
            top: 7px;
            z-index: 2
        }

        body.site .listCur .item {
            border: solid 1px #011a14;
            -webkit-border-radius: 50px;
            -moz-border-radius: 50px;
            -ms-border-radius: 50px;
            border-radius: 50px;
            width: 210px;
            padding: 5px 18px;
            flex-wrap: wrap;
            position: relative;
            padding-left: 64px
        }

        body.site .listCur .item+.item {
            margin-top: 20px;
            margin-left: 98px
        }

        body.site .listCur .item:nth-child(2) {
            margin-left: 98px
        }

        body.site .listCur .item:nth-child(3) {
            margin-left: 189px
        }

        body.site .listCur .item .iconCircle {
            width: 45px;
            height: 45px;
            position: absolute;
            left: 5px;
            top: 50%;
            margin-top: -22px
        }

        body.site .listCur .item .val {
            color: #a2ea07;
            font-size: 20px;
            display: block;
            font-weight: 700
        }

        body.site .listCur .item .valPr {
            color: #fff;
            font-size: 13px;
            font-family: "Inter BETA"
        }

        body.site .iconCircle {
            width: 46px;
            height: 46px;
            background-color: #264b41;
            background-position: center;
            background-repeat: no-repeat;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            border-radius: 50%
        }

        body.site .listDep {
            position: absolute;
            left: 0;
            bottom: 303px;
            display: flex;
            z-index: 2
        }

        body.site .listDep .item {
            position: relative
        }

        body.site .listDep .item::before {
            content: "";
            position: absolute;
            left: -30px;
            top: 41px;
            width: 390px;
            height: 210px;
            background-color: #fff;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-45deg);
            -webkit-border-radius: 150px;
            -moz-border-radius: 150px;
            -ms-border-radius: 150px;
            border-radius: 150px;
            z-index: -1;
            -webkit-box-shadow: 40px 40px 33px 0 rgba(0, 0, 0, .04);
            -moz-box-shadow: 40px 40px 33px 0 rgba(0, 0, 0, .04);
            box-shadow: 40px 40px 33px 0 rgba(0, 0, 0, .04)
        }

        body.site .listDep .item .pr {
            color: #fff;
            font-size: 120px;
            position: absolute;
            left: 102px;
            top: 42px;
            font-weight: 800;
            opacity: .21
        }

        body.site .listDep .item+.item {
            margin-left: 160px
        }

        body.site .listDep .circle::before {
            content: "";
            position: absolute;
            left: -11px;
            top: 0;
            background-image: url(img/bgcircle1.png);
            background-position: center;
            background-repeat: no-repeat;
            width: 169px;
            height: 169px;
            z-index: -1
        }

        body.site .listDep .circle {
            width: 150px;
            height: 150px;
            text-align: center;
            position: relative;
            left: 157px;
            top: -3px;
            padding: 34px 0
        }

        body.site .listDep .circle .prVal {
            color: #c0ff00;
            font-size: 30px;
            font-weight: 100;
            display: block;
            line-height: 17px
        }

        body.site .listDep .circle .txt {
            font-family: "Inter BETA";
            font-weight: 300;
            color: #c0ff00;
            font-size: 30px;
            display: block
        }

        body.site .listDep .circle .hours {
            color: #fff;
            font-size: 13px;
            margin-top: 14px;
            display: block
        }

        body.site .listDep ul {
            position: relative;
            top: -2px;
            left: 41px
        }

        body.site .listDep ul li .tit {
            color: #003c2c;
            font-size: 12px;
            text-transform: uppercase;
            font-weight: 700;
            display: block
        }

        body.site .listDep ul li .val {
            color: #63ba00;
            font-size: 20px;
            font-weight: 700
        }

        body.site .listDep .desr {
            color: #8d9c98;
            font-size: 13px;
            font-weight: 500;
            position: relative;
            left: 53px;
            top: 4px
        }

        body.site .calcBlock .forma .inputLine:nth-child(1) {
            width: 309px
        }

        body.site .calcBlock .forma .inputLine:nth-child(2) {
            width: 181px
        }

        body.site .aboutCompany {
            margin-top: -201px;
            padding-bottom: 179px
        }

        body.site .aboutCompany .wrapIn {
            display: flex
        }

        body.site .aboutCompany .left {
            width: calc(50% - 120px);
            position: relative;
            z-index: 3
        }

        body.site .aboutCompany .right {
            width: calc(50% + 120px);
            padding-top: 287px
        }

        body.site .txtLeftBlock {
            font-size: 16px;
            color: #003c2c;
            position: relative
        }

        body.site .txtLeftBlock .desr {
            color: #63ba00;
            font-size: 15px;
            letter-spacing: 2.5px;
            font-weight: 700;
            display: block;
            text-transform: uppercase
        }

        body.site .txtLeftBlock .capVisible {
            font-size: 170px;
            font-weight: 700;
            color: #001b14;
            opacity: .05;
            position: absolute;
            left: 132px;
            top: -10px;
            z-index: -1
        }

        body.site .txtLeftBlock .cap {
            display: block;
            font-size: 40px;
            font-weight: 400
        }

        body.site .txtLeftBlock p {
            line-height: 27px
        }

        body.site .txtLeftBlock .btn {
            margin-top: 60px;
            padding: 14px 57px 17px;
            display: table
        }

        body.site .txtLeftBlock .cap+* {
            margin-top: 37px
        }

        body.site .txtLeftBlock .desr+* {
            margin-top: 7px
        }

        body.site .lineAdress {
            padding-left: 224px;
            display: flex;
            flex-wrap: wrap;
            position: relative;
            padding-bottom: 84px;
            z-index: 2
        }

        body.site .lineAdress .iconBl {
            width: 120px;
            height: 120px;
            background-position: center;
            background-repeat: no-repeat;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            border-radius: 50%;
            position: absolute;
            left: 77px;
            top: -24px;
            display: block;
            background-color: #fff
        }

        body.site .lineAdress .iconBl:before {
            content: "";
            position: absolute;
            left: -71px;
            top: -102px;
            width: 390px;
            height: 181px;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-48deg);
            -webkit-border-radius: 150px;
            -moz-border-radius: 150px;
            -ms-border-radius: 150px;
            border-radius: 150px;
            z-index: -1;
            -webkit-box-shadow: 0 10px 32px 0 rgba(0, 0, 0, .11);
            -moz-box-shadow: 0 10px 32px 0 rgba(0, 0, 0, .11);
            box-shadow: 0 10px 32px 0 rgba(0, 0, 0, .11)
        }

        body.site .lineAdress .col {
            position: relative;
            z-index: 2
        }

        body.site .lineAdress .col+.col {
            margin-left: 78px
        }

        body.site .lineAdress .col .tit {
            color: #003c2c;
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .4px;
            display: block
        }

        body.site .lineAdress .col .adress {
            color: #8d9c98;
            font-size: 13px;
            margin-top: 8px;
            display: block;
            line-height: 21px
        }

        body.site .lineAdress .col .num {
            color: #63ba00;
            font-size: 30px;
            font-weight: 700;
            margin-top: 10px;
            display: block;
            letter-spacing: .5px
        }

        body.site .lineSteps {
            padding-left: 122px;
            position: relative;
            z-index: 3
        }

        body.site .lineSteps .list {
            display: flex;
            margin-top: 58px;
            justify-content: space-between
        }

        body.site .lineSteps .num {
            font-size: 133px;
            font-weight: 800;
            color: #ffff;
            position: absolute;
            left: -63px;
            top: -66px;
            z-index: -1;
            text-shadow: 11px 11px 21px rgba(0, 0, 0, .11);
            opacity: .5
        }

        body.site .lineSteps .tit {
            color: #003c2c;
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            display: block
        }

        body.site .lineSteps .text {
            color: #8d9c98;
            font-size: 13px;
            font-weight: 500;
            margin-top: 6px;
            display: block;
            line-height: 20px
        }

        body.site .lineSteps .col {
            position: relative
        }

        body.site .lineSteps .col+.col {
            margin-left: 5px;
            left: 7px
        }

        body.site .whyBl {
            position: relative;
            z-index: 2
        }

        body.site .whyBl .wrapIn {
            display: flex
        }

        body.site .whyBl .left {
            position: relative;
            padding-top: 245px;
            width: calc(50% - 80px)
        }

        body.site .whyBl .right {
            width: calc(50% + 80px)
        }

        body.site .whyBl .left .picture {
            width: 1080px;
            height: 698px;
            background-position: center;
            background-repeat: no-repeat;
            position: absolute;
            left: -220px;
            top: -411px
        }

        body.site .whyBl .left .list {
            margin-top: 50px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between
        }

        body.site .whyBl .left .item {
            width: calc(50% - 31px);
            margin-bottom: 60px
        }

        body.site .whyBl .left .item:nth-child(2n) {
            top: -40px
        }

        body.site .whyBl .left .item .tit {
            color: #003c2c;
            font-size: 14px;
            text-transform: uppercase;
            font-weight: 700;
            display: block;
            margin-top: 19px;
            letter-spacing: .5px
        }

        body.site .whyBl .left .item .text {
            color: #8d9c98;
            font-size: 13px;
            font-weight: 500;
            display: block;
            margin-top: 4px;
            line-height: 23px
        }

        body.site .whyBl .left .item .iconBl {
            font-size: 50px;
            color: #63ba00
        }

        body.site .statMiniBl {
            position: relative;
            z-index: 3
        }

        body.site .statMiniBl .back {
            content: "";
            position: absolute;
            left: 130px;
            top: -187px;
            background-image: url(img/bgstatictic.png);
            width: 723px;
            height: 727px;
            background-position: center
        }

        body.site .statMiniBl .capVisible {
            font-size: 170px;
            font-weight: 700;
            color: #001b14;
            opacity: .05;
            position: absolute;
            left: 20px;
            top: 336px;
            z-index: -1
        }

        body.site .statMiniBl ul li {
            position: absolute;
            left: 0;
            top: 0;
            padding-left: 70px;
            z-index: 2
        }

        body.site .statMiniBl ul li:nth-child(1) {
            left: 45px;
            top: 292px
        }

        body.site .statMiniBl ul li:nth-child(2) {
            left: 203px;
            top: 444px
        }

        body.site .statMiniBl ul li:nth-child(3) {
            left: 282px;
            top: 213px
        }

        body.site .statMiniBl ul li:nth-child(4) {
            left: 525px;
            top: 100px
        }

        body.site .statMiniBl ul li:nth-child(5) {
            left: 525px;
            top: 350px
        }

        body.site .statMiniBl ul li .tit {
            color: #63ba00;
            font-size: 15px;
            text-transform: uppercase;
            display: block;
            font-weight: 700;
            letter-spacing: 2.8px;
            white-space: nowrap
        }

        body.site .statMiniBl ul li .val sub {
            font-size: 18px;
            vertical-align: 8px
        }

        body.site .statMiniBl ul li .val {
            color: #003c2c;
            font-size: 30px;
            display: block;
            font-weight: 700;
            margin-top: 7px
        }

        body.site .statMiniBl ul li .iconBl {
            position: absolute;
            left: 2px;
            top: 6px;
            color: #ccd4d3;
            font-size: 50px
        }

        body.site .affiliateBl {
            position: relative
        }

        body.site .affiliateBl+.operBlock {
            padding: 91px 0 0
        }

        body.site .affiliateBl::before {
            content: "";
            position: absolute;
            left: calc(50% - 961px);
            top: -259px;
            background-image: url(img/bgallifate.png);
            background-repeat: no-repeat;
            z-index: -1;
            width: 1977px;
            height: 1325px
        }

        body.site .affiliateBl .wrapIn {
            position: relative;
            padding: 95px 0 63px;
            overflow: hidden
        }

        body.site .affiliateBl .list {
            display: flex;
            width: 63%;
            justify-content: space-between;
            position: relative;
            z-index: 3
        }

        body.site .affiliateBl .list .col {
            width: calc(50% - 38px)
        }

        body.site .affiliateBl .list .col+.col {
            margin-top: 21px
        }

        body.site .affiliateBl .list .desr {
            color: #63ba00;
            font-size: 15px;
            text-transform: uppercase;
            letter-spacing: 3.7px;
            font-weight: 700
        }

        body.site .affiliateBl .list .tit {
            color: #fff;
            font-size: 40px;
            display: block;
            margin-top: 9px
        }

        body.site .affiliateBl .list .text {
            color: #fff;
            font-size: 16px;
            margin-top: 34px;
            display: block;
            line-height: 25px
        }

        body.site .affiliateBl .list .btn {
            margin-top: 36px;
            display: table;
            padding: 16px 0 15px;
            width: 207px
        }

        body.site .listLevelBl {
            position: absolute;
            right: 48px;
            bottom: 90px;
            display: flex;
            z-index: 1
        }

        body.site .listLevelBl .item {
            position: relative;
            margin-left: 26px
        }

        body.site .listLevelBl .item::before {
            background-color: #218222;
            content: "";
            position: absolute;
            left: -234px;
            top: 63px;
            width: 392px;
            height: 142px;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-45deg);
            -webkit-border-radius: 150px;
            -moz-border-radius: 150px;
            -ms-border-radius: 150px;
            border-radius: 150px;
            z-index: -1;
            -webkit-box-shadow: 40px 40px 33px 0 rgba(0, 0, 0, .04);
            -moz-box-shadow: 40px 40px 33px 0 rgba(0, 0, 0, .04);
            box-shadow: 40px 40px 33px 0 rgba(0, 0, 0, .04)
        }

        body.site .listLevelBl .item:nth-child(1) {
            top: -220px
        }

        body.site .listLevelBl .item:nth-child(2) {
            top: -115px
        }

        body.site .listLevelBl .item:nth-child(1)::before {
            left: -540px;
            top: 195px;
            width: 750px
        }

        body.site .listLevelBl .item:nth-child(2)::before {
            left: -404px;
            top: 135px;
            width: 592px
        }

        body.site .listLevelBl .item:nth-child(3)::before {
            width: 492px;
            left: -320px;
            top: 101px
        }

        body.site .listLevelBl .item .pr {
            font-size: 155px;
            color: #fff;
            font-weight: 700;
            opacity: .07;
            position: absolute;
            left: -183px;
            top: 80px;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-45deg)
        }

        body.site .listLevelBl .item:nth-child(1) .pr {
            left: -202px;
            top: 83px
        }

        body.site .listLevelBl .item:nth-child(2) .pr {
            left: -200px;
            top: 88px
        }

        body.site .listLevelBl .item .desr {
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            position: absolute;
            left: -91px;
            top: 129px;
            text-transform: uppercase;
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-45deg);
            letter-spacing: 2.5px
        }

        body.site .listLevelBl .item .circle {
            background-color: #fff;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            border-radius: 50%;
            width: 100px;
            height: 100px;
            text-align: center;
            line-height: 75px
        }

        body.site .listLevelBl .item .circle .prCirc {
            color: #003c2c;
            font-size: 59px;
            font-weight: 800
        }

        body.site .listLevelBl .item .circle .prCirc sub {
            font-size: 31px;
            vertical-align: 22px
        }

        body.site .operBlock {
            position: relative;
            z-index: 2
        }

        body.site .operBlock .wrapIn {
            display: flex;
            flex-wrap: wrap
        }

        body.site .operBlock .left {
            width: 60%
        }

        body.site .operBlock .right {
            width: 40%;
            position: relative
        }

        body.site .operBlock .right:before {
            content: "";
            position: absolute;
            right: -6px;
            bottom: -85px;
            background-image: url(img/arrow.png);
            width: 82px;
            height: 83px;
            background-position: center;
            background-repeat: no-repeat
        }

        body.site .lastOperTable {
            display: flex
        }

        body.site .operBlock .right .capVisible {
            font-size: 100px;
            font-weight: 700;
            color: #001b14;
            opacity: .05;
            position: absolute;
            right: 248px;
            bottom: 17px;
            z-index: -1;
            width: 100%;
            white-space: nowrap
        }

        body.site .operBlock .left .capVisible {
            font-size: 170px;
            font-weight: 700;
            color: #001b14;
            opacity: .05;
            position: absolute;
            left: -263px;
            top: 290px;
            z-index: -1
        }

        body.site .userSays {
            position: relative
        }

        body.site .plLineBlock {
            width: 100%;
            margin-top: 73px
        }

        body.site .plLineBlock ul {
            display: flex
        }

        body.site .plLineBlock ul li {
            width: 160px;
            height: 60px;
            background-position: center;
            background-repeat: no-repeat
        }

        body.site .plLineBlock ul li+li {
            margin-left: 16px
        }

        body.site footer {
            background-image: url(img/bgfooter.png);
            background-position: 0 0;
            background-repeat: no-repeat;
            padding: 220px 0 45px;
            margin-top: -7px;
            position: relative;
            z-index: 2
        }

        body.site footer .wrapIn {
            display: flex;
            flex-wrap: wrap
        }

        body.site footer .copyTxt {
            color: #fff;
            font-size: 13px;
            margin-top: 61px;
            line-height: 22px
        }

        body.site footer .menuFot {
            width: 463px;
            margin-left: 165px;
            position: relative;
            top: 7px
        }

        body.site footer .menuFot ul {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between
        }

        body.site footer .menuFot ul li {
            width: 50%;
            margin-bottom: 20px;
            position: relative
        }

        body.site footer .menuFot ul li a:before {
            content: "";
            position: absolute;
            left: -15px;
            top: 50%;
            background-color: #003c2c;
            width: 7px;
            height: 7px;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            -ms-border-radius: 50%;
            border-radius: 50%;
            margin-top: -3px
        }

        body.site footer .menuFot ul li a {
            color: #fff;
            font-size: 17px;
            position: relative
        }

        body.site footer .menuFot ul li a:hover {
            color: #c0ff00
        }

        body.site .partBl {
            width: 397px;
            position: relative;
            left: -42px;
            top: 50px
        }

        body.site .partBl ul {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between
        }

        body.site .partBl ul li {
            width: 120px;
            height: 50px;
            background-position: center;
            background-repeat: no-repeat;
            margin-bottom: 10px
        }

        body.site .faqList .faqBlock:nth-child(2) {
            margin-top: 198px
        }

        body.site .listNews .item:nth-child(2n) {
            margin-top: 150px;
            margin-bottom: -150px
        }

        body.site .formaCall .inputLine:nth-child(3) {
            width: 100%;
            margin-top: 11px
        }

        body.site .partAboutBl .list .item:nth-child(2n) {}

        body.site .affilateWork .listLevelBl .item:nth-child(1)::before {
            left: -609px;
            top: 224px;
            width: 824px
        }

        body.site .affilateWork .listLevelBl .item:nth-child(2)::before {
            width: 692px;
            left: -487px;
            top: 172px
        }

        body.site .menuBtn.selected span:nth-child(1) {
            -webkit-transform: rotate(45deg);
            -moz-transform: rotate(45deg);
            -o-transform: rotate(45deg);
            transform: rotate(45deg);
            top: 8px
        }

        body.site .menuBtn.selected span:nth-child(2) {
            opacity: 0
        }

        body.site .menuBtn.selected span:nth-child(3) {
            -webkit-transform: rotate(-45deg);
            -moz-transform: rotate(-45deg);
            -o-transform: rotate(-45deg);
            transform: rotate(-45deg);
            top: -8px
        }

        body.site .parallax>use {
            animation: move-forever 12s linear infinite
        }

        body.site .parallax>use:nth-child(1) {
            animation-delay: 1s
        }

        body.site .parallax>use:nth-child(2) {
            animation-delay: -4s;
            animation-duration: 10s
        }

        body.site .parallax>use:nth-child(3) {
            animation-delay: -8s;
            animation-duration: 7s
        }

        @keyframes move-forever {
            0% {
                transform: translate(-90px, 0%);
            }

            100% {
                transform: translate(85px, 0%);
            }
        }

        body.site .editorial {
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: -1
        }

        body.site .footerMain {
            background-image: none
        }

        body.site .whyBl .left .picture::after {
            content: "";
            background-image: url(img/blick.png);
            position: absolute;
            width: 984px;
            height: 486px;
            left: 0;
            top: 0;
            animation-timing-function: linear;
            animation-iteration-count: infinite;
            animation-duration: 5s;
            animation-name: blick;
            background-repeat: no-repeat
        }

        @keyframes blick {
            0% {
                -webkit-transform: scale(0.3);
                -moz-transform: scale(0.3);
                -o-transform: scale(0.3);
                transform: scale(0.3);
                opacity: 0;
            }

            20% {
                opacity: 1;
            }

            80% {
                -moz-transform: scale(0.8);
                -o-transform: scale(0.8);
                transform: scale(0.8);
                opacity: 1;
            }

            100% {
                opacity: 0;
            }
        }

        @media (max-width:1890px) {
            body.lk .accStat .accStatItem:nth-child(1) {
                top: 220px;
                left: -70px
            }

            body.lk .accStat .accStatItem:nth-child(2) {
                top: 85px;
                left: 150px
            }

            body.lk .accStat .accStatItem:nth-child(3) {
                top: -45px;
                right: 45px
            }

            body.lk .accStat .accStatItem:nth-child(4) {
                bottom: 160px;
                left: -40px
            }

            body.lk .accStat .accStatItem:nth-child(5) {
                bottom: 290px;
                right: 130px
            }

            body.lk .accStat .accStatItem:nth-child(6) {
                bottom: 195px;
                right: 60px
            }
        }

        @media (max-width:767px) {
            body.lk .planItem input:checked~.in::before {
                border-top: 15px solid #046028
            }
        }

        @media (max-width:1599px) {
            body.site .operBlock .left .capVisible {
                left: 0;
                top: 325px
            }
        }

        @media (max-width:1439px) {
            body.site .container {
                width: 1200px;
                padding: 0 10px
            }

            body.site .headerMainPage::before {
                margin-left: -960px
            }

            body.site .listCur {
                left: 0
            }

            body.site .listDep {
                left: -37px;
                bottom: 366px
            }

            body.site .whyBl .wrapIn {
                flex-wrap: wrap
            }

            body.site .whyBl .left {
                width: 100%
            }

            body.site .whyBl .right {
                width: 100%;
                min-height: 591px;
                margin-top: 90px
            }

            body.site .statMiniBl {
                width: 810px;
                display: block;
                margin: 0 auto
            }

            body.site .affiliateBl {
                margin-top: 100px
            }

            body.site .affiliateBl .wrapIn {
                padding-bottom: 40px
            }

            body.site .operBlock .right .capVisible {
                font-size: 80px
            }

            body.site .operBlock .left .capVisible {
                font-size: 100px
            }

            body.site footer .menuFot {
                margin-left: 65px;
                width: 410px
            }

            body.site .partBl {
                width: 295px;
                top: 0
            }

            body.site .partBl ul li {
                width: 100px;
                background-size: contain
            }

            body.site .lineTop .logo img {
                width: 150px
            }
        }

        @media (max-width:1199px) {
            body.site .container {
                width: 992px
            }

            body.site header {
                z-index: auto
            }

            body.site .lineTop {
                padding: 30px 0;
                z-index: auto
            }

            body.site .lineTop .wrapIn {
                padding-right: 75px
            }

            body.site .linkLog .btn {
                padding: 13px 0
            }

            body.site .textGretting .cap {
                font-size: 60px
            }

            body.site .listCur {
                display: flex;
                align-items: center;
                top: 48px
            }

            body.site .listCur .item+.item {
                margin-top: 0;
                margin-left: 15px !important
            }

            body.site .listCur .item:nth-child(2) {
                margin-left: 0
            }

            body.site .listCur .item:nth-child(3) {
                margin-left: 0
            }

            body.site .listDep {
                position: relative;
                left: -181px;
                bottom: auto;
                margin: 55px 0 0
            }

            body.site .calcBlock .forma .inputLine:nth-child(1) label {
                color: #003c2c
            }

            body.site .aboutCompany {
                margin-top: 0;
                padding-bottom: 285px
            }

            body.site .aboutCompany .wrapIn {
                flex-wrap: wrap
            }

            body.site .aboutCompany .left {
                width: 100%
            }

            body.site .aboutCompany .right {
                width: 100%;
                padding-top: 71px
            }

            body.site .txtLeftBlock p {
                font-size: 14px;
                line-height: 24px
            }

            body.site .lineSteps {
                margin-top: 50px;
                padding-left: 50px
            }

            body.site .affiliateBl .wrapIn {
                padding-bottom: 52px
            }

            body.site .affiliateBl .list .tit {
                font-size: 30px
            }

            body.site .affiliateBl .list .text {
                font-size: 15px
            }

            body.site .listLevelBl {
                bottom: 83px
            }

            body.site .operBlock .left {
                width: 100%
            }

            body.site .operBlock .right {
                width: 100%
            }

            body.site .operBlock .right:before {
                right: 0;
                bottom: 0
            }

            body.site .operBlock .right .capVisible {
                right: 0
            }

            body.site footer .wrapIn {
                justify-content: space-between
            }

            body.site footer .menuFot {
                display: none
            }

            body.site .partBl {
                left: -47px;
                margin-left: 0;
                top: 27px;
                width: 395px
            }
        }

        @media (max-width:991px) {
            body.site .container {
                width: 768px
            }

            body.site header {
                z-index: auto
            }

            body.site .textGretting .cap {
                font-size: 50px;
                line-height: 65px
            }

            body.site .listDep {
                flex-wrap: wrap;
                left: -142px
            }

            body.site .listDep .item+.item {
                margin-left: 100px
            }

            body.site .txtLeftBlock .capVisible {
                left: 0;
                top: 37px;
                font-size: 100px
            }

            body.site .statMiniBl {
                left: -36px
            }

            body.site .affiliateBl {
                background-color: #064035;
                margin-top: 0
            }

            body.site .affiliateBl::before {
                display: none
            }

            body.site .affiliateBl .wrapIn {
                padding: 58px 0
            }

            body.site .affiliateBl .list {
                flex-wrap: wrap;
                width: 100%
            }

            body.site .listLevelBl {
                position: relative;
                bottom: auto;
                right: auto;
                flex-wrap: wrap;
                margin-top: 50px;
                justify-content: center
            }

            body.site .listLevelBl .item {
                width: calc((100% / 3) - 7px);
                top: auto !important;
                margin-left: 0
            }

            body.site .listLevelBl .item::before {
                display: none
            }

            body.site .listLevelBl .item .pr {
                -webkit-transform: rotate(0deg);
                -moz-transform: rotate(0deg);
                -o-transform: rotate(0deg);
                transform: rotate(0deg);
                position: relative;
                left: auto !important;
                top: auto !important;
                font-size: 100px;
                display: block;
                text-align: center;
                opacity: .5
            }

            body.site .listLevelBl .item .desr {
                position: relative;
                left: auto;
                top: auto;
                display: block;
                text-align: center;
                -webkit-transform: rotate(0deg);
                -moz-transform: rotate(0deg);
                -o-transform: rotate(0deg);
                transform: rotate(0deg)
            }

            body.site .listLevelBl .item .circle {
                margin: 0 auto;
                margin-top: 21px
            }

            body.site .plLineBlock ul {
                flex-wrap: wrap;
                justify-content: center
            }

            body.site footer {
                background-color: #006632;
                padding: 50px 0;
                margin-top: 50px
            }

            body.site .partBl {
                width: 295px;
                left: -25px;
                top: 3px
            }

            body.site .partBl ul li {
                width: 100px
            }
        }

        @media (max-width:767px) {
            body.site .container {
                width: 100%
            }

            body.site .textGretting .cap {
                font-size: 40px;
                line-height: 50px
            }

            body.site .textGretting p {
                font-size: 18px;
                margin-top: 20px
            }

            body.site .textGretting .btn {
                margin-top: 20px
            }

            body.site .listCur {
                flex-wrap: wrap
            }

            body.site .listCur .item {
                background-color: rgba(255, 255, 255, .33);
                width: 206px
            }

            body.site .listCur .item+.item {
                margin-left: 0 !important
            }

            body.site .listDep {
                left: 0
            }

            body.site .listDep .item {
                margin-bottom: 50px
            }

            body.site .listDep .item+.item {
                margin-left: 154px
            }

            body.site .calcBlock .forma .inputLine:nth-child(1) {
                width: calc(50% - 20px)
            }

            body.site .calcBlock .forma .inputLine:nth-child(2) {
                width: calc(50% - 20px)
            }

            body.site .aboutCompany {
                margin-top: 50px
            }

            body.site .whyBl .right {
                min-height: inherit;
                margin-top: 0
            }

            body.site .statMiniBl {
                left: 0;
                width: 100%
            }

            body.site .statMiniBl .back {
                display: none
            }

            body.site .statMiniBl ul li {
                position: relative;
                left: auto !important;
                top: auto !important;
                right: auto !important;
                bottom: auto !important;
                width: 50%;
                margin-bottom: 25px
            }

            body.site .statMiniBl ul li .tit {
                font-size: 14px
            }

            body.site .statMiniBl ul li .val {
                font-size: 25px
            }

            body.site .statMiniBl ul {
                display: flex;
                flex-wrap: wrap
            }
        }

        @media (max-width:639px) {
            body.site .linkLog {
                width: 150px;
                top: 4px
            }

            body.site .linkLog .btn {
                font-size: 14px
            }

            body.site .lineTopInfo .wrapIn {
                flex-wrap: wrap;
                justify-content: flex-start
            }

            body.site .textGretting {
                padding: 50px 0;
                text-align: left
            }

            body.site .textGretting .cap {
                right: auto
            }

            body.site .listCur {
                display: none
            }

            body.site .listDep {
                margin: 0 auto;
                max-width: 320px
            }

            body.site .listDep .item {
                width: 100%;
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                margin-bottom: 0
            }

            body.site .listDep .item::before {
                -webkit-transform: rotate(0deg);
                -moz-transform: rotate(0deg);
                -o-transform: rotate(0deg);
                transform: rotate(0deg);
                left: -30px;
                top: -14px
            }

            body.site .listDep .item+.item {
                margin-left: 0;
                margin-top: 40px
            }

            body.site .listDep .circle {
                left: auto;
                top: 8px
            }

            body.site .listDep ul {
                top: auto;
                left: auto;
                margin-left: 30px
            }

            body.site .listDep .desr {
                left: auto;
                top: -25px;
                width: 100%;
                text-align: right;
                right: 30px
            }

            body.site .aboutCompany {
                padding-bottom: 50px
            }

            body.site .txtLeftBlock .capVisible {
                font-size: 100px;
                left: 0;
                top: 28px
            }

            body.site .lineAdress {
                padding-left: 190px
            }

            body.site .lineAdress .iconBl {
                left: 40px;
                top: 0
            }

            body.site .lineAdress .col {
                width: 100%
            }

            body.site .lineAdress .col+.col {
                margin-left: 0;
                margin-top: 28px
            }

            body.site .lineSteps .list {
                flex-wrap: wrap
            }

            body.site .lineSteps .col {
                width: 100%
            }

            body.site .whyBl {
                padding-bottom: 50px
            }

            body.site .whyBl .left {
                padding-top: 0
            }

            body.site .whyBl .left .picture {
                display: none
            }

            body.site .statMiniBl .capVisible {
                font-size: 100px;
                left: 0;
                bottom: 0;
                top: auto
            }

            body.site .statMiniBl ul li {
                width: 100%;
                padding: 0;
                margin-bottom: 0
            }

            body.site .statMiniBl ul li .tit {
                font-size: 14px;
                margin-top: 15px
            }

            body.site .statMiniBl ul li .val {
                font-size: 20px
            }

            body.site .statMiniBl ul li .iconBl {
                position: relative;
                left: auto;
                top: auto
            }

            body.site .affiliateBl .list .col {
                width: 100%
            }

            body.site .listLevelBl .item .pr {
                font-size: 50px
            }

            body.site .listLevelBl .item .desr {
                font-size: 13px;
                margin-top: 10px
            }

            body.site .listLevelBl .item .circle {
                margin-top: 10px;
                display: none
            }

            body.site .operBlock .right:before {
                display: none
            }

            body.site .lastOperTable {
                flex-wrap: wrap
            }

            body.site .operBlock .left .capVisible {
                top: -64px
            }

            body.site .plLineBlock {
                margin-top: 30px
            }

            body.site .plLineBlock ul li {
                width: 120px;
                background-size: contain
            }

            body.site footer {
                padding: 30px 0;
                background-image: none
            }

            body.site footer .copyTxt {
                margin-top: 15px
            }

            body.site .partBl {
                width: 100%;
                left: 0;
                justify-content: center;
                margin: 15px 0
            }

            body.site .partBl ul {
                justify-content: center
            }

            body.site .partBl ul li {
                margin: 0 6px
            }

            body.site .lineSteps .col+.col {
                margin-left: 0;
                margin-top: 65px;
                left: 0
            }

            body.site .statMiniBl ul {
                text-align: center
            }

            body.site .statMiniBl ul li+li {
                margin-top: 15px
            }

            body.site footer .col {
                width: 100%;
                text-align: center
            }

            body.site footer .logo {
                margin: 0 auto;
                display: table
            }
        }

        @media (max-width:479px) {
            body.site .lineTop .wrapIn {
                flex-wrap: wrap
            }

            body.site .linkLog {
                top: 12px;
                right: auto;
                width: 100%
            }

            body.site .btn.btnGrLigh {
                max-width: 150px
            }

            body.site .lineTopInfo .clockBl {
                width: 100%;
                margin-bottom: 15px
            }

            body.site .textGretting .cap {
                font-size: 30px;
                line-height: 40px
            }

            body.site .textGretting .cap br {
                display: none
            }

            body.site .textGretting p {
                font-size: 16px;
                line-height: 22px
            }

            body.site .calcBlock .forma .inputLine:nth-child(1) {
                width: 100%
            }

            body.site .calcBlock .forma .inputLine:nth-child(2) {
                width: 100%;
                margin-top: 16px
            }

            body.site .aboutCompany {
                padding-top: 50px
            }

            body.site .txtLeftBlock {
                font-size: 14px
            }

            body.site .txtLeftBlock .cap {
                font-size: 30px
            }

            body.site .txtLeftBlock .btn {
                margin-top: 15px
            }

            body.site .lineAdress {
                padding-left: 0;
                padding-top: 150px
            }

            body.site .lineSteps {
                padding-left: 0
            }

            body.site .lineSteps .num {
                left: -22px
            }

            body.site .whyBl .left .item {
                width: 100%;
                margin: 0;
                top: auto !important;
                margin-bottom: 20px
            }

            body.site .statMiniBl .capVisible {
                font-size: 60px
            }

            body.site .listLevelBl .item .pr {
                font-size: 30px
            }

            body.site .listLevelBl .item .desr {
                font-size: 12px
            }

            body.site .operBlock .right .capVisible {
                font-size: 50px
            }

            body.site .operBlock .left .capVisible {
                font-size: 60px
            }

            body.site .formaCall .inputLine:nth-child(3) {
                margin-top: 15px
            }

            body.site .lineSteps .txtLeftBlock {
                padding-left: 0
            }

            body.site .formaCall .inputLine:nth-child(1) {
                width: 100%
            }

            body.site .formaCall .inputLine:nth-child(2) {
                width: 100%;
                margin-top: 15px
            }
        }
    </style>
    <style>
        @font-face {
            font-family: 'Glyphicons Halflings';
            src: url(fonts/glyphicons-halflings-regular.html);
            src: url(fonts/glyphicons-halflings-regulard41d.html?#iefix) format('embedded-opentype'), url(fonts/glyphicons-halflings-regular-2.html) format('woff2'), url(fonts/glyphicons-halflings-regular-3.html) format('woff'), url(fonts/glyphicons-halflings-regular-4.html) format('truetype'), url(fonts/glyphicons-halflings-regular-5.html#glyphicons_halflingsregular) format('svg')
        }

        html {
            font-family: sans-serif;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        footer,
        header,
        section {
            display: block
        }

        audio {
            display: inline-block;
            vertical-align: baseline
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        a {
            background-color: transparent
        }

        a:active,
        a:hover {
            outline: 0
        }

        b {
            font-weight: 700
        }

        sub {
            position: relative;
            font-size: 75%;
            line-height: 0;
            vertical-align: baseline
        }

        sub {
            bottom: -.25em
        }

        img {
            border: 0
        }

        svg:not(:root) {
            overflow: hidden
        }

        input,
        textarea {
            margin: 0;
            font: inherit;
            color: inherit
        }

        input::-moz-focus-inner {
            padding: 0;
            border: 0
        }

        input {
            line-height: normal
        }

        textarea {
            overflow: auto
        }

        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        :after,
        :before {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box
        }

        html {
            font-size: 10px;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
        }

        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            line-height: 1.42857143;
            color: #333;
            background-color: #fff
        }

        input,
        textarea {
            font-family: inherit;
            font-size: inherit;
            line-height: inherit
        }

        a {
            color: #337ab7;
            text-decoration: none
        }

        a:focus,
        a:hover {
            color: #23527c;
            text-decoration: underline
        }

        a:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        img {
            vertical-align: middle
        }

        h2 {
            font-family: inherit;
            font-weight: 500;
            line-height: 1.1;
            color: inherit
        }

        h2 {
            margin-top: 20px;
            margin-bottom: 10px
        }

        h2 {
            font-size: 30px
        }

        p {
            margin: 0 0 10px
        }

        ul {
            margin-top: 0;
            margin-bottom: 10px
        }

        .container {
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto
        }

        @media (min-width:768px) {
            .container {
                width: 750px
            }
        }

        @media (min-width:992px) {
            .container {
                width: 970px
            }
        }

        @media (min-width:1200px) {
            .container {
                width: 1170px
            }
        }

        .table-striped>tbody>tr:nth-of-type(odd) {
            background-color: #f9f9f9
        }

        input[type="file"] {
            display: block
        }

        input[type="file"]:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        .has-feedback label~.form-control-feedback {
            top: 25px
        }

        .has-feedback label.sr-only~.form-control-feedback {
            top: 0
        }

        .btn {
            display: inline-block;
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 14px;
            font-weight: 400;
            line-height: 1.42857143;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-image: none;
            border: 1px solid transparent;
            border-radius: 4px
        }

        .btn:active:focus,
        .btn:focus {
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px
        }

        .btn:focus,
        .btn:hover {
            color: #333;
            text-decoration: none
        }

        .btn:active {
            background-image: none;
            outline: 0;
            -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
            box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125)
        }

        .collapse {
            display: none
        }

        .collapse.in {
            display: block
        }

        .btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle) {
            border-radius: 0
        }

        .btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle) {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .btn-group>.btn:last-child:not(:first-child),
        .btn-group>.dropdown-toggle:not(:first-child) {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group>.btn-group:not(:first-child):not(:last-child)>.btn {
            border-radius: 0
        }

        .btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn:not(:first-child):not(:last-child) {
            border-radius: 0
        }

        .btn-group-vertical>.btn:first-child:not(:last-child) {
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn:last-child:not(:first-child) {
            border-top-left-radius: 0;
            border-top-right-radius: 0;
            border-bottom-right-radius: 4px;
            border-bottom-left-radius: 4px
        }

        .btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn {
            border-radius: 0
        }

        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,
        .btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0
        }

        .btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child {
            border-top-left-radius: 0;
            border-top-right-radius: 0
        }

        .input-group .form-control:not(:first-child):not(:last-child),
        .input-group-addon:not(:first-child):not(:last-child),
        .input-group-btn:not(:first-child):not(:last-child) {
            border-radius: 0
        }

        .input-group .form-control:first-child,
        .input-group-addon:first-child,
        .input-group-btn:first-child>.btn,
        .input-group-btn:first-child>.btn-group>.btn,
        .input-group-btn:first-child>.dropdown-toggle,
        .input-group-btn:last-child>.btn-group:not(:last-child)>.btn,
        .input-group-btn:last-child>.btn:not(:last-child):not(.dropdown-toggle) {
            border-top-right-radius: 0;
            border-bottom-right-radius: 0
        }

        .input-group .form-control:last-child,
        .input-group-addon:last-child,
        .input-group-btn:first-child>.btn-group:not(:first-child)>.btn,
        .input-group-btn:first-child>.btn:not(:first-child),
        .input-group-btn:last-child>.btn,
        .input-group-btn:last-child>.btn-group>.btn,
        .input-group-btn:last-child>.dropdown-toggle {
            border-top-left-radius: 0;
            border-bottom-left-radius: 0
        }

        .nav {
            padding-left: 0;
            margin-bottom: 0;
            list-style: none
        }

        .nav>li {
            position: relative;
            display: block
        }

        .nav>li>a {
            position: relative;
            display: block;
            padding: 10px 15px
        }

        .nav>li>a:focus,
        .nav>li>a:hover {
            text-decoration: none;
            background-color: #eee
        }

        .navbar-collapse {
            padding-right: 15px;
            padding-left: 15px;
            overflow-x: visible;
            -webkit-overflow-scrolling: touch;
            border-top: 1px solid transparent;
            -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1)
        }

        .navbar-collapse.in {
            overflow-y: auto
        }

        @media (min-width:768px) {
            .navbar-collapse {
                width: auto;
                border-top: 0;
                -webkit-box-shadow: none;
                box-shadow: none
            }

            .navbar-collapse.collapse {
                display: block !important;
                height: auto !important;
                padding-bottom: 0;
                overflow: visible !important
            }

            .navbar-collapse.in {
                overflow-y: visible
            }
        }

        .navbar-nav {
            margin: 7.5px -15px
        }

        .navbar-nav>li>a {
            padding-top: 10px;
            padding-bottom: 10px;
            line-height: 20px
        }

        @media (min-width:768px) {
            .navbar-nav {
                float: left;
                margin: 0
            }

            .navbar-nav>li {
                float: left
            }

            .navbar-nav>li>a {
                padding-top: 15px;
                padding-bottom: 15px
            }

            .navbar-right~.navbar-right {
                margin-right: 0
            }
        }

        @-webkit-keyframes progress-bar-stripes {
            from {
                background-position: 40px 0
            }

            to {
                background-position: 0 0
            }
        }

        @-o-keyframes progress-bar-stripes {
            from {
                background-position: 40px 0
            }

            to {
                background-position: 0 0
            }
        }

        @keyframes progress-bar-stripes {
            from {
                background-position: 40px 0
            }

            to {
                background-position: 0 0
            }
        }

        .container:after,
        .container:before,
        .nav:after,
        .nav:before,
        .navbar-collapse:after,
        .navbar-collapse:before {
            display: table;
            content: " "
        }

        .container:after,
        .nav:after,
        .navbar-collapse:after {
            clear: both
        }

        @-ms-viewport {
            width: device-width
        }
    </style>
    
    <?php echo '<script'; ?>
 type="text/javascript" src="js/jquery-3.3.1.js"><?php echo '</script'; ?>
>
    <link rel="dns-prefetch" href="http://js.users.51.la/">
</head>
<style>
    body.site .listCur .item {
        background-color: #223e31;
        border: dashed 1px #223e31
    }

    body.site .textGretting {
        padding: 40px 0 0;
        text-align: right;
        width: 100%
    }

    body.site .textGretting p {
        margin-top: 10px
    }

    .hvr-shrink {
        display: inline-block;
        vertical-align: middle;
        -webkit-transform: perspective(1px) translateZ(0);
        transform: perspective(1px) translateZ(0);
        box-shadow: 0 0 1px rgba(0, 0, 0, 0);
        -webkit-transition-duration: .3s;
        transition-duration: .3s;
        -webkit-transition-property: transform;
        transition-property: transform;
        float: left
    }

    .menu22 {
        background-color: rgba(0, 0, 0, .45);
        -webkit-border-radius: 50px;
        -moz-border-radius: 50px;
        -ms-border-radius: 50px;
        border-radius: 50px;
        width: 100%;
        max-width: 808px;
        position: relative;
        left: 5px
    }

    .menu22 li a {
        font-size: 15px;
        font-weight: bold;
        color: #fff
    }

    .menu22 li a:hover {
        font-size: 15px;
        font-weight: bold;
        color: #fff;
        background-color: rgba(0, 0, 0, .33)
    }

    body.site .btn.btnGrLigh {
        color: #001811;
        background-color: #a2ea07;
        font-weight: bold;
        box-shadow: 0 2px 0 0 #fff, inset 0 0 2px rgba(255, 255, 255, .6)
    }

    body.site .btn.btnGrLigh:hover {
        color: #001811;
        background-color: #a2ea07;
        font-weight: bold;
        box-shadow: 0 2px 0 0 #013220, inset 0 0 2px rgba(255, 255, 255, .6)
    }
</style>
<style>
    .textinfo {
        display: inline-block;
        background: #439a25;
        background: #b800d9;
        background: #6dd214;
        font-size: 20px;
        font-weight: bold;
        position: relative;
        border-radius: 2px;
        width: 100%;
        padding: 5px 8px;
        text-align: center;
        margin-top: 10px;
        margin-bottom: 10px
    }
</style>

<body class='site'>
    <section class="wrapper">
        <header class="headerMainPage">
            <div class="lineTop">
                <div class="container">
                    <div class="wrapIn">
                        <div class="logo invisLink">
                            <a href="/?a=home"></a>
                            <img src="img/logo.png" alt="">
                        </div>
                        <div class="navbar-collapse bounceIn wow collapse in menu22" id="bs-example-navbar-collapse-1" aria-expanded="true">
                            <ul class="nav navbar-nav">
                                <li class="hvr-shrink"><a href="/?a=home">Home</a></li>
                                <li class="hvr-shrink"><a href="/?a=about">About us</a></li>
                                <li class="hvr-shrink"><a href="/?a=cust&amp;page=howitworks">How it works?</a></li>
                                <li class="hvr-shrink"><a href="/?a=faq">FAQ</a></li>
                               
                                <li class="hvr-shrink"><a href="/?a=support">Support</a></li>
                            </ul>
                        </div>
                        <div class="linkLog">
                                                        <a href="/?a=login" class="btn btnGrLigh">Login</a>
                            <a href="/?a=signup" class="btn btnGrLigh">Sign Up</a>
                                                    </div>
                    </div>
                </div><br><br>
                <div style="height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:62px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px; width: 100%;"><div style="height:40px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&amp;theme=light&amp;pref_coin_id=1505&amp;invert_hover=" width="100%" height="36px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div><div style="color: #FFFFFF; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;"><a href="https://coinlib.io/" target="_blank" style="font-weight: 500; color: #FFFFFF; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by daily income</div></div>
            </div>
            <div class="lineTopInfo">
                <div class="container">
                    <div class="wrapIn">
                        <div class="clockBl">
                            <span id="time"></span>
                            <span id="date"></span>
                        </div>
                        <div class="langBl">
                            <div class="pic" style="background-image: url(img/gb.png);"></div>
                            <span class="lang">Eng</span>
                            <ul>
                                <li><a href="index1ca2.html?a=logout&amp;language=en">Eng</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grettingsMain">
                <div class="container">
                    <div class="wrapIn">
                        <div class="listCur">
                            <?php echo '<script'; ?>
 type="text/javascript">
                                jQuery.ajax({
                                    url: "https://min-api.cryptocompare.com/data/pricemulti",
                                    data: "fsyms=BTC,ETH,DASH,LTC&tsyms=USD",
                                    dataType: 'json',
                                }).done(function(data) {
                                    jQuery(".dashCoin").html('$' + data.DASH.USD);
                                    jQuery(".ethCoin").html('$' + data.ETH.USD);
                                    jQuery(".bitCoin").html('$' + data.BTC.USD);
                                    jQuery(".liteCoin").html('$' + data.LTC.USD);
                                }).fail(function() {
                                    console.log("API error");
                                });
                            <?php echo '</script'; ?>
>
                            <style>
                                .f{
                                    width:25%;
                                    float:left;
                                   
                                }
                            </style>
                            <div style="width:100%;margin-top:-5%;">
                            <div class="item  wow slideInLeft f">
                                <span class="iconCircle" style="background-image: url(img/pic_cur1.png);"></span>
                                <span class="bitCoin val">$20000.00</span>
                                <span class="valPr"></span>
                            </div>
                            <div class="item  wow slideInLeft f">
                                <span class="iconCircle" style="background-image: url(img/pic_cur2.png);"></span>
                                <span class="ethCoin val">232.26$</span>
                                <span class="valPr"></span>
                            </div>
                            <div class="item  wow slideInLeft f">
                                <span class="iconCircle" style="background-image: url(img/pic_cur3.png);"></span>
                                <span class="liteCoin val">60.93$</span>
                                <span class="valPr "></span>
                            </div>
                            </div>
                        </div>
                        <div class="textGretting  wow slideInRight">
                            <h2 class="cap">Get Paid Hourly<br />More Than CEO<br /><span style = "font-size:50%">at <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
!</span></h2>
                            <p><B><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 hourly earnings strategies for our investors!</B></p>
                            <p><B>Start as low as $100, Pay Instantly, 5%~10% Commission</B></p>
                            <p><B style="color:#c0ff00">Guaranteed Refund At Any Time</B></p>
                            <a href="/?a=signup" class="btn btnGrLigh">Open an account</a>
                        </div>
                        
                        <style>
                            .s{
                                
                                width:20;
                            }
                        </style>
                        
                        
                        
                        
                            <div class="listDep" style = "margin-left:5%">                        
                            <div class="item  wow slideInLeft" style = "margin:1px">
                                <span class="pr">%</span>
                                <div class="circle">
                                    <br>
                                    <span class="prVal">85%</span>
                                    <!--- <span class="hours">After 7 Days</span> -->
                                </div>
                                <ul>
                                    <li>
                                        <span class="tit">Min deposit</span>
                                        <span class="val">$10000</span>
                                    </li>
                                    <li>
                                        <span class="tit">Max deposit</span>
                                        <span class="val">$19999</span>
                                    </li>
                                </ul>
                                <span class="desr">instant withdrawal<br>85% After 2 Days</span>
                            </div>
                            <div class="item  wow slideInLeft" style = "margin:1px">
                                <span class="pr">%</span>
                                <div class="circle">
                                    <br>
                                    <span class="prVal">100%</span>
                                </div>
                                <ul>
                                    <li>
                                        <span class="tit">Min deposit</span>
                                        <span class="val">$20000</span>
                                    </li>
                                    <li>
                                        <span class="tit">Max deposit</span>
                                        <span class="val">Unlimited</span>
                                    </li>
                                </ul>
                                <span class="desr">instant withdrawal<br>100% After 3 Days</span>
                            </div>
                            
                        <div class="listDep">
                            <div class="item  wow slideInLeft" style = "margin:1px">
                                <span class="pr">%</span>
                                <div class="circle">
                                    <br>
                                    <span class="prVal">30%</span>
                                    
                                </div>
                                <ul>
                                    <li>
                                        <span class="tit">Min deposit</span>
                                        <span class="val">$100</span>
                                    </li>
                                    <li>
                                        <span class="tit">Max deposit</span>
                                        <span class="val">$999</span>
                                    </li>
                                </ul>
                                <span class="desr">instant withdrawal<br>30% After 12 Hours</span>
                            </div>
                            <div class="item  wow slideInLeft" style = "margin:1px">
                                <span class="pr">%</span>
                                <div class="circle">
                                    <br>
                                    <span class="prVal">50%</span>
                                    
                                </div>
                                <ul>
                                    <li>
                                        <span class="tit">Min deposit</span>
                                        <span class="val">$1000</span>
                                    </li>
                                    <li>
                                        <span class="tit">Max deposit</span>
                                        <span class="val">$4999</span>
                                    </li>
                                </ul>
                                <span class="desr">instant withdrawal<br>50% After 24 Hours</span>
                            </div>
                            <div class="item  wow slideInLeft" style = "margin:1px">
                                <span class="pr">%</span>
                                <div class="circle">
                                    <br>
                                    <span class="prVal">70%</span>
                                    
                                </div>
                                <ul>
                                    <li>
                                        <span class="tit">Min deposit</span>
                                        <span class="val">$5000</span>
                                    </li>
                                    <li>
                                        <span class="tit">Max deposit</span>
                                        <span class="val">$9999</span>
                                    </li>
                                </ul>
                                <span class="desr">instant withdrawal<br>70% After 2 Days</span>
                            </div>
                            
                        </div>
                        
                        
                        
                        
           
                           
                          
                           
                        </div>
                        
                        
                        
                    </div>
                </div>
            </div>
        </header>
        
        <div class="aboutCompany">
            <div class="container">
                <div class="wrapIn">
                    <div class="left  wow slideInLeft">
                        <div class="txtLeftBlock">
                            <span class="capVisible">about</span>
                            <span class="desr">company info</span>
                            <h2 class="cap">About the company</h2>
                            <p><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is a team of professional analysts and players in the cryptocurrency market, which has hundreds of instruments in its assets for profit in the financial markets, including cryptocurrency. The main distinguishing feature of our company from competitors is the presence of its own unique trading strategies using an hourly reporting period.</p>
                            <p>By investing in our company, you can be sure that your capital is increasing every hour!</p>
                            <p>min deposit as low as $100 and you can earn up to 10% commission also instant payment, We have 8 professional trading experts and work 24/7 and trade 10 million investment daily.</p>
                            <a href="/?a=about" class="btn btnGrDark">More About</a>
                        </div>
                    </div>
                    
                    <div class="right  wow slideInRight">
                        <div class="lineAdress">
                            <div class="iconBl" style="background-image: url(img/pic_seh.jpg);"></div>
                            <div class="col">
                                <span class="tit">Company adress:</span>
                                <span class="adress">
                                    5b Cuerden Way, Bamber Bridge, Preston, England, PR5 6BL</span>
                            </div>
                            <div class="col">
                                <span class="tit">Officially Registered:</span>
                                <span class="num">#12237737</span>
                                <p>Company status <b>Active</b></p>
                            </div>
                            <style>
                                .btn1 {
                                    padding: 14px 17px 17px;
                                    color: #c0ff00;
                                    background-color: #003d2c;
                                    font-weight: bold
                                }

                                .btn1:hover {
                                    background-color: #c0ff00
                                }

                                .cc1 {
                                    margin-top: 20px
                                }
                            </style>
                            <div class="col cc1">
                                <a href="images/certificate.png" target="_blank" class="btn1 btnGrDark">Show Certificate</a>
                            </div>
                            <div class="col cc1">
                                <a href="https://find-and-update.company-information.service.gov.uk/company/12237737" target="_blank" class="btn1 btnGrDark">United Kingdom Company </a>
                            </div>
                        </div>
                        <div class="lineSteps">
                            <div class="txtLeftBlock">
                                <span class="desr">Only 3 easy steps</span>
                                <h2 class="cap">separate you from success!</h2>
                            </div>
                            <div class="list">
                                <div class="col">
                                    <span class="num">01</span>
                                    <span class="tit">Registration</span>
                                    <span class="text">Follow the simple registration procedure on our official website</span>
                                </div>
                                <div class="col">
                                    <span class="num">02</span>
                                    <span class="tit">Open deposit</span>
                                    <span class="text">Replenish your account and open a deposit using any tariff plan</span>
                                </div>
                                <div class="col">
                                    <span class="num">03</span>
                                    <span class="tit">Make a profit</span>
                                    <span class="text">Start making profits every hour!</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="whyBl">
            <div class="container">
                <div class="wrapIn">
                    <div class="left  wow slideInLeft">
                        <div class="picture" style="background-image: url(img/pic_money1.png);"></div>
                        <div class="txtLeftBlock">
                            <span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 </span>
                            <h2 class="cap">Why do our customers choose us?</h2>
                        </div>
                        <div class="list">
                            <div class="item">
                                <span class="iconBl icon-clock"></span>
                                <span class="tit">Quick payouts</span>
                                <span class="text">Our company pays all payments due to investors as soon as possible!</span>
                            </div>
                            <div class="item">
                                <span class="iconBl icon-wallet"></span>
                                <span class="tit">Deposit insurance</span>
                                <span class="text">All deposits of our investors are reliably insured by our own highly specialized fund.</span>
                            </div>
                            <div class="item">
                                <span class="iconBl icon-headphone"></span>
                                <span class="tit">24 HOUR SUPPORT</span>
                                <span class="text">Our highly qualified specialists are always online and ready to answer your any question at any time of the day or night.</span>
                            </div>
                            <div class="item">
                                <span class="iconBl icon-shield"></span>
                                <span class="tit">RELIABLE PROTECTION</span>
                                <span class="text">We pay special attention to the safety of your data and the overall security of the site. To do this, we use the most advanced security and encryption tools.</span>
                            </div>
                        </div>
                    </div>
                    </div>
                        </div>
                        
                        
                        
                        
                        
                        
                    </div>
                    </div>
                        </div>
                    </div>
                    
     <style>
    .table-striped>tbody>tr:nth-of-type(odd) {
    background-color: #1d1c2f;
    border: 1px solid #312f51;
     }
     .table>tbody>tr>td {
    padding: 10px;
     }
     </style>
          

   <center>      
<div class="workProcess">
<div class="container">
<div class="wrapIn">
<div class="capBlock">
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap">LATEST PAYOUTS</h2>
                                     
   
    <iframe src="https://www.btcwidget.info/widget/liveTx/%23ffffff/%23ffffff/%23ffffff/%23000000/%23ffffff/1119/300/5" width="1119" height="300" frameBorder="0" scrolling="no"></iframe>
    <iframe frameborder=0 height=400 width=100% scrolling=no src='https://muladev.online/minerstrade/deposit.php'></iframe>
    </center>
        
      
<style>
.blog-post-image {
    text-align: center;
    color: #ff9606;
    padding-top: 20px;
}
.blog-post-text h3 {
    color: unset;
}
.post-date {
    font-size: 18px;
}
</style>
                    <?php echo '<script'; ?>
 src="../widgets.coingecko.com/coingecko-coin-market-ticker-list-widget.js"><?php echo '</script'; ?>
>
<coingecko-coin-market-ticker-list-widget  coin-id="bitcoin" currency="usd" locale="en" width=""></coingecko-coin-market-ticker-list-widget>
<div style="height:560px; background-color: #1D2330; overflow:hidden; box-sizing: border-box; border: 1px solid #282E3B; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #262B38;padding:1px;padding: 0px; margin: 0px; width: 100%;"><div style="height:540px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=chart&amp;theme=dark&amp;coin_id=859&amp;pref_coin_id=1505" width="100%" height="536px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe></div><div style="color: #626B7F; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;"><a href="https://coinlib.io/" target="_blank" style="font-weight: 500; color: #626B7F; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</div></div>
</div>
</div>
<br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
                    <div class="right  wow slideInRight">
                        <div class="statMiniBl">
                            <div class="back"></div>
                            <h2 class="capVisible">statistics</h2>
                            <ul>
                                <li>
                                    <span class="iconBl icon-safebox"></span>
                                    <span class="tit">Latest deposit</span>
                                    <span class="val" id="ld1"></span>
                                </li>
                                <li>
                                    <span class="iconBl icon-wallet"></span>
                                    <span class="tit">Latest withdraw</span>
                                    <span class="val" id = "lw1"></span>
                                </li>
                                
             <?php echo '<script'; ?>
>
                        func();
                        function func(){
                               var listPlans = ['$500','$1,500','$1,000','$10,000','$2,000','$3,000','$4,000', '$600', '$700', '$2,500'];
                               
                        var plan = listPlans[Math.floor(Math.random() * listPlans.length)];
                        var planw = listPlans[Math.floor(Math.random() * listPlans.length)];
                         document.getElementById('ld1').innerHTML = plan;
                          document.getElementById('lw1').innerHTML = planw;
                        }
                        <?php echo '</script'; ?>
>
                                <li>
                                    <span class="iconBl icon-user1"></span>
                                    <span class="tit">user online</span>
                                    <span class="val"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_visitor_online_generated']+7);?>
</span>
                                </li>
                                <li>
                                    <span class="iconBl icon-calendar"></span>
                                    <span class="tit">Running Days</span>
                                    <span class="val"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</span>
                                </li>
                                <li>
                                    <span class="iconBl icon-team"></span>
                                    <span class="tit">Total registered</span>
                                    <span class="val"> <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_total_accounts_generated']+3790);?>
</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div class="workProcess">
<div class="container">
<div class="wrapIn">
<div class="capBlock">
<span class="desr"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</span>
<h2 class="cap">BITCOIN VIDEOS EXPLAINED</h2>
</div>
<div class="list">
<div class="item">
<span class="txt"><iframe width="300" height="400" src="https://www.youtube.com/embed/2X9eJF1nLiY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></span>
</div>
<div class="item">
<span class="txt"><iframe width="300" height="400" src="https://www.youtube.com/embed/XWPifXIWPwE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></span>
</div>
<div class="item">
<span class="txt"><iframe width="300" height="400" src="https://www.youtube.com/embed/BODyqM-V71E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></span>
</div>
<div class="item">
<span class="num"></span>
<span class="tit"></span>
<span class="txt"></span>
</div>
</div>
</div>
</div>
</div>
        <br>
        <div class="affiliateBl" id="ali">
            <div class="container">
                <div class="wrapIn">
                    <div class="list  wow slideInLeft">
                        <div class="col">
                            <span class="desr">Referral program</span>
                            <span class="tit">For partners</span>
                            <span class="text">Introduce your friends to the activities of our company and discover the possibilities of unlimited earnings and get 5%~10% commission!</span>
                            <a href="/?a=signup" class="btn btnGrLigh">Join Now</a>
                        </div>
                        <div class="col">
                            <span class="tit">Free Bonus</span>
                            <span class="text">Promote our brand on social networks and make a profit for every action!you will able to get free $0.05 Sign Up Bonus.Invite more friends and earn more!</span>
                            <a href="/?a=signup" class="btn btnGrLigh">Sign up</a>
                        </div>
                    </div>
                    <div class="listLevelBl  wow slideInRight">
                        <div class="item">
                            <span class="pr">3%</span>
                            <span class="desr">For 1 Plan</span>
                            <div class="circle"><span class="prCirc">3<sub>%</sub></span></div>
                        </div>
                        <div class="item">
                            <span class="pr">5%</span>
                            <span class="desr">For 2 Plan</span>
                            <div class="circle"><span class="prCirc">5<sub>%</sub></span></div>
                        </div>
                        <div class="item">
                            <span class="pr">10%</span>
                            <span class="desr">For 3 Plan</span>
                            <div class="circle"><span class="prCirc">10<sub>%</sub></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="operBlock">
            <div class="container">
                <div class="wrapIn">
                    <div class="left  wow slideInLeft">
                        <h2 class="capVisible">operations</h2>
                        <div class="lastOperTable">
                            <style>
                                .linkLog ul li {
                                    float: left;
                                    margin-left: 20px
                                }
                            </style>
                            <div class="linkLog" style='width:1000px; text-align:center;'>
                                <ul>
                            </div>
                        </div>
                    </div>
                    </div>
                   <!--- <p><a href="https://wa.me/+447360519150"><img src="img/whatsapp.jpg"  width="400" height="100"></a></p> -->
                    <div class="plLineBlock  wow fadeInUp">
                        <ul>
                            <li style="background-image: url(img/platgray3.png)"></li>
                            <li style="background-image: url(img/platgray3.png)"></li>
                            <li style="background-image: url(img/platgray3.png)"></li>
                            <li style="background-image: url(img/platgray3.png)"></li>
                            <li style="background-image: url(img/platgray3.png)"></li>
                            <li style="background-image: url(img/platgray3.png)"></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
      
<div class="operBlock">
<div class="container">
<div class="wrapIn">


<div class="plLineBlock  wow fadeInUp">
<ul>
<li style="background-image: url(img/platgray1.png)"></li>
<li style="background-image: url(img/platgray2.png)"></li>
<li style="background-image: url(img/platgray3.png)"></li>
<li style="background-image: url(img/platgray4.png)"></li>
<li style="background-image: url(img/platgray5.png)"></li>
<li style="background-image: url(img/platgray6.png)"></li>
</ul>
</div>
</div>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>